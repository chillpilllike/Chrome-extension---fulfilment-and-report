const DEFAULT_API_BASE = "http://127.0.0.1:8000";
const completionLocks = new Set();
let queueStatusInFlight = null;
let lastReleaseMissingWindowJobsAt = 0;
let releaseMissingWindowJobsInFlight = null;
const recoverSubmittedJobsInFlight = new Map();
let lastEmptyRecoverSubmittedJobAt = 0;
let startNextJobInFlight = null;
const claimNextJobInFlight = new Map();

async function getSettings() {
  const data = await chrome.storage.local.get({
    apiBase: DEFAULT_API_BASE,
    adminToken: "",
    cardLast4Preference: "",
    editExistingAddress: true,
    fulfilAvailableMixedAsin: false,
    splitMixedAsinOrders: false,
    workerId: "",
    activeJob: null,
    activeJobsByWindow: {},
    controlWindowsById: {},
    recentAmazonOrders: [],
    cachedQueueStatus: null,
    logs: [],
    logsByWindow: {},
  });
  return data;
}

async function getWorkerId() {
  const { workerId } = await chrome.storage.local.get({ workerId: "" });
  if (workerId) return workerId;
  const next = `chrome-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
  await chrome.storage.local.set({ workerId: next });
  return next;
}

function normalizeApiBase(value) {
  return String(value || DEFAULT_API_BASE).trim().replace(/\/+$/, "") || DEFAULT_API_BASE;
}

function messageWindowId(message = {}, sender = {}) {
  return Number(message.targetWindowId || sender.tab?.windowId || 0) || null;
}

async function getWindowState(windowId) {
  const state = await getSettings();
  const key = String(windowId || "");
  const windowJob = windowId ? state.activeJobsByWindow?.[key] || null : state.activeJob;
  const fallbackSubmittedJob = windowId && !windowJob && orderSubmitStarted(state.activeJob)
    ? state.activeJob
    : null;
  return {
    ...state,
    targetWindowId: windowId || null,
    activeJob: windowJob || fallbackSubmittedJob,
    logs: windowId ? state.logsByWindow?.[key] || [] : state.logs,
  };
}

async function setWindowJob(windowId, activeJob) {
  const { activeJobsByWindow } = await getSettings();
  const next = { ...(activeJobsByWindow || {}) };
  const key = String(windowId || "");
  if (windowId && activeJob) next[key] = activeJob;
  if (windowId && !activeJob) delete next[key];
  await chrome.storage.local.set({ activeJobsByWindow: next, activeJob: activeJob || Object.values(next)[0] || null });
}

async function clearStoredJobGroup(groupKey) {
  if (!groupKey) return;
  const state = await getSettings();
  const next = { ...(state.activeJobsByWindow || {}) };
  for (const [windowKey, activeJob] of Object.entries(next)) {
    if (activeJob?.job?.group_key === groupKey) delete next[windowKey];
  }
  const activeJob = state.activeJob?.job?.group_key === groupKey ? null : state.activeJob || null;
  await chrome.storage.local.set({ activeJobsByWindow: next, activeJob: activeJob || Object.values(next)[0] || null });
}

async function setControlWindow(controlWindowId, targetWindowId) {
  if (!controlWindowId) return;
  const { controlWindowsById } = await getSettings();
  const next = { ...(controlWindowsById || {}) };
  if (targetWindowId) {
    next[String(controlWindowId)] = targetWindowId;
  } else {
    delete next[String(controlWindowId)];
  }
  await chrome.storage.local.set({ controlWindowsById: next });
}

async function log(message, windowId = null) {
  const { logs, logsByWindow } = await getSettings();
  const entry = `${new Date().toLocaleTimeString()} ${message}`;
  if (!windowId) {
    await chrome.storage.local.set({ logs: [entry, ...logs].slice(0, 40) });
    return;
  }
  const key = String(windowId);
  const next = { ...(logsByWindow || {}) };
  next[key] = [entry, ...(next[key] || [])].slice(0, 40);
  await chrome.storage.local.set({ logsByWindow: next, logs: next[key] });
}

function normalizeRecentAmazonOrder(order = {}) {
  const orderId = String(order.amazon_order_id || "").trim();
  if (!/^\d{3}-\d{7}-\d{7}$/.test(orderId)) return null;
  const items = (order.items || [])
    .map((item) => ({
      asin: String(item?.asin || "").trim().toUpperCase(),
      quantity: Math.max(1, Math.round(Number(item?.quantity || 1))),
    }))
    .filter((item) => item.asin);
  const asinQuantities = {};
  for (const item of items) {
    asinQuantities[item.asin] = (asinQuantities[item.asin] || 0) + item.quantity;
  }
  for (const asin of order.asins || []) {
    const normalizedAsin = String(asin || "").trim().toUpperCase();
    if (normalizedAsin && !asinQuantities[normalizedAsin]) asinQuantities[normalizedAsin] = 1;
  }
  return {
    amazon_order_id: orderId,
    amazon_order_url: order.amazon_order_url || `https://www.amazon.com/your-orders/order-details?orderID=${encodeURIComponent(orderId)}`,
    recipient: String(order.recipient || "").replace(/\s+/g, " ").trim(),
    order_date: String(order.order_date || "").replace(/\s+/g, " ").trim(),
    status: String(order.status || "").replace(/\s+/g, " ").trim(),
    asins: Object.keys(asinQuantities),
    items,
    asin_quantities: asinQuantities,
    cancelled: order.cancelled === true,
    captured_at: Number(order.captured_at || Date.now()),
  };
}

async function rememberRecentAmazonOrders(orders = []) {
  const incoming = (orders || []).map(normalizeRecentAmazonOrder).filter(Boolean);
  if (!incoming.length) return { ok: true, remembered: 0, orders: [] };
  const { recentAmazonOrders } = await getSettings();
  const byId = new Map();
  for (const order of [...incoming, ...(recentAmazonOrders || [])]) {
    if (!order?.amazon_order_id || byId.has(order.amazon_order_id)) continue;
    byId.set(order.amazon_order_id, normalizeRecentAmazonOrder(order));
  }
  const next = [...byId.values()].filter(Boolean).sort((a, b) => Number(b.captured_at || 0) - Number(a.captured_at || 0)).slice(0, 10);
  await chrome.storage.local.set({ recentAmazonOrders: next });
  return { ok: true, remembered: incoming.length, orders: next };
}

async function lookupAmazonHistoryOrders(orders = []) {
  const normalized = (orders || []).map(normalizeRecentAmazonOrder).filter(Boolean);
  if (!normalized.length) return { ok: true, matches: {}, unmatched: [], not_found_url: "/amazon-order-history-unmatched" };
  const result = await api("/api/chrome/order-history/lookup", {
    method: "POST",
    body: JSON.stringify({ orders: normalized }),
    timeoutMs: 12000,
  });
  const { apiBase } = await getSettings();
  const base = normalizeApiBase(apiBase);
  return { app_base_url: base, ...result, not_found_url: `${base}${result.not_found_url || "/amazon-order-history-unmatched"}` };
}

async function syncAmazonHistoryOrder(order = {}) {
  const normalized = normalizeRecentAmazonOrder(order);
  if (!normalized) return { ok: false, message: "Amazon order ID is not valid." };
  const orderNames = (order.order_names || [])
    .map((name) => String(name || "").trim())
    .filter(Boolean);
  const lineIds = (order.line_ids || [])
    .map((lineId) => Number(lineId || 0))
    .filter((lineId) => Number.isFinite(lineId) && lineId > 0);
  const result = await api("/api/manual-amazon/match", {
    method: "POST",
    body: JSON.stringify({
      amazon_order_id: normalized.amazon_order_id,
      amazon_order_url: normalized.amazon_order_url,
      amazon_account_name: order.amazon_account_name || "Chrome History Matcher",
      order_names: orderNames,
      line_ids: lineIds,
      source_text: order.source_text || normalized.recipient || "",
      store_id: order.store_id || null,
      replace_existing: order.replace_existing === true,
    }),
    timeoutMs: 120000,
  });
  return result;
}

async function api(path, options = {}) {
  const { apiBase, adminToken } = await getSettings();
  const base = normalizeApiBase(apiBase);
  const requestPath = String(path || "").startsWith("/") ? path : `/${path}`;
  const { timeoutMs = 45000, ...fetchOptions } = options;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(timeoutMs || 45000));
  const response = await fetch(`${base}${requestPath}`, {
    headers: { "Content-Type": "application/json", ...(adminToken ? { "X-Admin-Token": adminToken } : {}), ...(fetchOptions.headers || {}) },
    signal: controller.signal,
    ...fetchOptions,
  }).finally(() => clearTimeout(timeout));
  if (!response.ok) {
    throw new Error((await response.text()) || response.statusText);
  }
  return response.json();
}

function connectionErrorMessage(error, base = "") {
  const raw = String(error?.message || error || "Failed to fetch");
  if (/failed to fetch|networkerror|load failed|abort/i.test(raw)) {
    return `Could not reach the local app at ${base || DEFAULT_API_BASE}. Make sure the app is running on port 8000, then click Save and Check connection again.`;
  }
  return raw;
}

async function testConnection() {
  const { apiBase, adminToken } = await getSettings();
  const base = normalizeApiBase(apiBase);
  try {
    const health = await fetch(`${base}/health`);
    if (!health.ok) {
      throw new Error(`Server health check failed: HTTP ${health.status}`);
    }
    const auth = await fetch(`${base}/api/settings/admin-access`, {
      headers: adminToken ? { "X-Admin-Token": adminToken } : {},
    });
    if (!auth.ok) {
      throw new Error((await auth.text()) || `Admin token check failed: HTTP ${auth.status}`);
    }
  } catch (error) {
    throw new Error(connectionErrorMessage(error, base));
  }
  return { ok: true, message: `Connected to ${base}. Admin token accepted.` };
}

async function getQueueStatus() {
  const workerId = await getWorkerId();
  if (queueStatusInFlight) return queueStatusInFlight;
  queueStatusInFlight = (async () => {
  try {
    const payload = await api("/api/chrome/jobs?claim=false&job_limit=12");
    const snapshot = {
      ok: true,
      jobs: payload.jobs || [],
      counts: payload.counts || [],
      workerId,
      cached_at: Date.now(),
      stale: false,
    };
    await chrome.storage.local.set({ cachedQueueStatus: snapshot });
    return snapshot;
  } catch (error) {
    const { cachedQueueStatus } = await getSettings();
    if (cachedQueueStatus?.ok) {
      return {
        ...cachedQueueStatus,
        workerId: cachedQueueStatus.workerId || workerId,
        stale: true,
        message: error.message || "Could not refresh queue; showing last loaded queue.",
      };
    }
    throw error;
  }
  })();
  try {
    return await queueStatusInFlight;
  } finally {
    queueStatusInFlight = null;
  }
}

async function getQueueJobsForActiveRefresh() {
  const payload = await api("/api/chrome/jobs?claim=false&job_limit=80");
  return payload.jobs || [];
}

async function refreshActiveJobFromQueue(windowId, force = false) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job?.group_key) return activeJob;
  if (activeJob.stage === "cleanup_after_failure") return activeJob;
  if (orderSubmitStarted(activeJob)) return activeJob;
  if (!force && Date.now() - Number(activeJob.jobRefreshedAt || 0) < 30000) return activeJob;
  try {
    const jobs = await getQueueJobsForActiveRefresh();
    const freshJob = jobs.find((job) => job.group_key === activeJob.job.group_key);
    if (!freshJob) {
      await setWindowJob(windowId, null);
      await addLog(
        `Cleared stale active job ${activeJob.job.group_key}; it is no longer queued on the server.`,
        "warn"
      );
      return null;
    }
    const { activeJob: currentJob } = await getWindowState(windowId);
    const next = { ...(currentJob || activeJob), job: freshJob, jobRefreshedAt: Date.now() };
    await setWindowJob(windowId, next);
    return next;
  } catch {
    return activeJob;
  }
}

async function openControlWindow(tab) {
  const targetWindowId = tab?.windowId || null;
  const popupUrl = chrome.runtime.getURL(`popup.html${targetWindowId ? `?targetWindowId=${targetWindowId}` : ""}`);
  const windows = await chrome.windows.getAll({ populate: true, windowTypes: ["popup", "normal"] });
  const existingTab = windows.flatMap((item) => item.tabs || []).find((tab) => tab.url === popupUrl);
  if (existingTab?.id && existingTab.windowId) {
    await setControlWindow(existingTab.windowId, targetWindowId);
    await chrome.windows.update(existingTab.windowId, { focused: true });
    await chrome.tabs.update(existingTab.id, { active: true });
    return;
  }
  const controlWindow = await chrome.windows.create({
    url: popupUrl,
    type: "popup",
    width: 430,
    height: 620,
    focused: true,
  });
  await setControlWindow(controlWindow?.id, targetWindowId);
}

function activeJobFor(job, workerId, targetWindowId) {
  return {
    job,
    itemIndex: 0,
    stage: "clear_cart",
    cartCleared: false,
    paused: false,
    promoAcknowledged: {},
    pricing: {},
    workerId,
    startedAt: Date.now(),
    targetWindowId,
  };
}

function jobWasSubmittedToAmazon(job) {
  if (job?.submitted_to_amazon) return true;
  if (["order_submitted", "reporting_complete"].includes(String(job?.amazon_status || ""))) return true;
  return (job?.items || []).some((item) => ["order_submitted", "reporting_complete"].includes(String(item.amazon_status || "")));
}

function activeJobBlocksNext(activeJob) {
  if (!activeJob?.job?.group_key) return false;
  if (activeJob.stage === "cleanup_after_failure") return false;
  return true;
}

async function blockingActiveJob(windowId = null) {
  const state = await getSettings();
  const jobs = Object.values(state.activeJobsByWindow || {}).filter(Boolean);
  if (state.activeJob) jobs.push(state.activeJob);
  const seen = new Set();
  for (const job of jobs) {
    const key = `${job?.targetWindowId || ""}:${job?.job?.group_key || ""}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (activeJobBlocksNext(job)) return job;
  }
  if (windowId) {
    const { activeJob } = await getWindowState(windowId);
    if (activeJobBlocksNext(activeJob)) return activeJob;
  }
  return null;
}

async function navigateWindowToCart(windowId) {
  if (!windowId) return;
  const tabs = await chrome.tabs.query({ windowId });
  const tab = tabs.find((item) => item.active) || tabs[0];
  if (tab?.id) {
    await chrome.tabs.update(tab.id, { url: "https://www.amazon.com/cart?ref_=sw_gtc", active: true });
  }
  await chrome.windows.update(windowId, { focused: true });
}

async function navigateWindowToOrderHistory(windowId) {
  const url = "https://www.amazon.com/gp/your-account/order-history?ref=ppx_pt2_dt_b_yo_link";
  if (!windowId) {
    const created = await chrome.windows.create({ url, type: "normal", focused: true });
    return created?.id || null;
  }
  const tabs = await chrome.tabs.query({ windowId });
  const tab = tabs.find((item) => item.active) || tabs[0];
  if (tab?.id) {
    await chrome.tabs.update(tab.id, { url, active: true });
  } else {
    await chrome.tabs.create({ windowId, url, active: true });
  }
  await chrome.windows.update(windowId, { focused: true });
  return windowId;
}

async function windowIsIncognito(windowId) {
  if (!windowId) return false;
  try {
    const windowInfo = await chrome.windows.get(windowId);
    return Boolean(windowInfo?.incognito);
  } catch {
    return false;
  }
}

async function createAmazonWorkerWindow(incognito = false) {
  const createData = {
    url: "https://www.amazon.com/cart?ref_=sw_gtc",
    type: "normal",
    focused: true,
    ...(incognito ? { incognito: true } : {}),
  };
  try {
    return await chrome.windows.create(createData);
  } catch (error) {
    await log(`Could not open new ${incognito ? "incognito " : ""}Chrome window: ${error.message}`);
    if (incognito) throw error;
  }
  const createdTab = await chrome.tabs.create({ url: "https://www.amazon.com/cart?ref_=sw_gtc", active: true });
  return createdTab.windowId ? await chrome.windows.get(createdTab.windowId) : null;
}

async function startNextJob(sourceWindowId = null) {
  if (startNextJobInFlight) return startNextJobInFlight;
  startNextJobInFlight = (async () => {
  await releaseMissingWindowJobs();
  const blocking = await blockingActiveJob(sourceWindowId);
  if (blocking) {
    if (orderSubmitStarted(blocking)) {
      await log(`Cannot start a new job; ${blocking.job.group_key} was already submitted and must be reported first.`, sourceWindowId);
      const recovered = await recoverSubmittedJobInWindow(blocking.targetWindowId || sourceWindowId);
      if (recovered?.activeJob) return recovered;
      await clearStoredJobGroup(blocking.job.group_key);
      await log(`Cleared closed submitted job ${blocking.job.group_key}; claiming the next queued order.`, sourceWindowId);
    } else {
      await log(`Cannot start a new job; ${blocking.job.group_key} is still active.`, sourceWindowId);
      return { ok: false, active_job_running: true, message: `Finish or stop ${blocking.job.group_key} before starting the next queued order.` };
    }
  }
  const workerId = await getWorkerId();
  const { splitMixedAsinOrders } = await getSettings();
  const payload = await api(`/api/chrome/jobs?worker_id=${encodeURIComponent(workerId)}&claim=true&resume_existing=true&split_mixed_asin=${splitMixedAsinOrders === true ? "true" : "false"}`);
  const job = payload.jobs?.[0];
  if (!job) {
    await log("No queued Chrome jobs found.");
    return { ok: false, message: "No queued Chrome jobs found." };
  }
  if (jobWasSubmittedToAmazon(job)) {
    await log(`Recovered submitted ${job.group_key}; looking up Amazon order ID instead of opening a new cart.`, sourceWindowId);
    return recoverSubmittedJobInWindow(sourceWindowId);
  }
  const incognito = await windowIsIncognito(sourceWindowId);
  let createdWindow;
  try {
    createdWindow = await createAmazonWorkerWindow(incognito);
  } catch (error) {
    try {
      await api(`/api/chrome/jobs/${encodeURIComponent(job.group_key)}/release`, {
        method: "POST",
        body: JSON.stringify({ worker_id: workerId }),
      });
    } catch (releaseError) {
      await log(`Could not release ${job.group_key} after window open failed: ${releaseError.message}`);
    }
    throw new Error(
      incognito
        ? "Could not open an incognito Amazon window. Check that this extension is allowed in incognito mode."
        : `Could not open Amazon cart window: ${error.message}`,
    );
  }
  const targetWindowId = createdWindow?.id || null;
  if (!targetWindowId) {
    throw new Error("Could not open Amazon cart window for the queued job.");
  }
  const activeJob = activeJobFor(job, workerId, targetWindowId);
  activeJob.incognito = incognito;
  await setWindowJob(targetWindowId, activeJob);
  await log(`Started ${job.group_key} with ${job.items.length} item(s) in ${incognito ? "incognito" : "normal"} window.`, targetWindowId);
  return { ok: true, message: `Started ${job.group_key}.`, targetWindowId };
  })();
  try {
    return await startNextJobInFlight;
  } finally {
    startNextJobInFlight = null;
  }
}

async function claimNextJobInWindow(windowId) {
  const claimKey = String(windowId || "global");
  if (claimNextJobInFlight.has(claimKey)) return claimNextJobInFlight.get(claimKey);
  const task = (async () => {
  const { activeJob: currentJob } = await getWindowState(windowId);
  if (activeJobBlocksNext(currentJob)) {
    await log(`Kept ${currentJob.job.group_key}; current job is not closed yet.`, windowId);
    return currentJob;
  }
  const blocking = await blockingActiveJob(windowId);
  if (blocking) {
    if (orderSubmitStarted(blocking)) {
      const recovered = await recoverSubmittedJobInWindow(blocking.targetWindowId || windowId);
      if (recovered?.activeJob) return recovered.activeJob;
      await clearStoredJobGroup(blocking.job.group_key);
      await log(`Cleared closed submitted job ${blocking.job.group_key}; claiming the next queued order.`, windowId);
    } else {
      await log(`Did not claim a new job because ${blocking.job.group_key} is still active.`, windowId);
      return null;
    }
  }
  const workerId = await getWorkerId();
  const { splitMixedAsinOrders } = await getSettings();
  const payload = await api(`/api/chrome/jobs?worker_id=${encodeURIComponent(workerId)}&claim=true&resume_existing=true&split_mixed_asin=${splitMixedAsinOrders === true ? "true" : "false"}`);
  const job = payload.jobs?.[0];
  if (!job) {
    await setWindowJob(windowId, null);
    await log("No more queued Chrome jobs found.", windowId);
    return null;
  }
  if (jobWasSubmittedToAmazon(job)) {
    const recovered = await recoverSubmittedJobInWindow(windowId);
    return recovered.activeJob || null;
  }
  const activeJob = activeJobFor(job, workerId, windowId);
  await setWindowJob(windowId, activeJob);
  await log(`Started next ${job.group_key} with ${job.items.length} item(s).`, windowId);
  await navigateWindowToCart(windowId);
  return activeJob;
  })();
  claimNextJobInFlight.set(claimKey, task);
  try {
    return await task;
  } finally {
    claimNextJobInFlight.delete(claimKey);
  }
}

async function recoverSubmittedJobInWindow(windowId) {
  const recoverKey = String(windowId || "global");
  if (recoverSubmittedJobsInFlight.has(recoverKey)) {
    return recoverSubmittedJobsInFlight.get(recoverKey);
  }
  if (Date.now() - lastEmptyRecoverSubmittedJobAt < 5000) {
    const { activeJob } = await getWindowState(windowId);
    if (!orderSubmitStarted(activeJob)) {
      return { ok: true, recovered: false, activeJob: null };
    }
  }
  const task = (async () => {
  const workerId = await getWorkerId();
  const result = await api(`/api/chrome/jobs/recover-submitted?worker_id=${encodeURIComponent(workerId)}`);
  const job = result.job || null;
  if (!job?.group_key) {
    lastEmptyRecoverSubmittedJobAt = Date.now();
    const { activeJob } = await getWindowState(windowId);
    if (orderSubmitStarted(activeJob)) {
      await clearStoredJobGroup(activeJob.job.group_key);
    }
    return { ok: true, recovered: false, activeJob: null };
  }
  const targetWindowId = await navigateWindowToOrderHistory(windowId);
  const activeJob = {
    ...activeJobFor(job, workerId, targetWindowId),
    stage: "find_order_id",
    cartCleared: true,
    amazonSubmittedAt: Date.now(),
    lastHeartbeatAt: Date.now(),
  };
  await setWindowJob(targetWindowId, activeJob);
  await log(`Recovered submitted ${job.group_key}; opened order history to look up Amazon order ID.`, targetWindowId);
  return { ok: true, recovered: true, activeJob, targetWindowId };
  })();
  recoverSubmittedJobsInFlight.set(recoverKey, task);
  try {
    return await task;
  } finally {
    recoverSubmittedJobsInFlight.delete(recoverKey);
  }
}

async function cleanupCartBeforeNextJob(activeJob, windowId, reason = "") {
  const cleanupJob = {
    ...activeJob,
    stage: "cleanup_after_failure",
    cleanupAfterFailure: true,
    cleanupReason: reason || "Cleaning Amazon cart before starting the next order.",
    paused: false,
  };
  await setWindowJob(windowId, cleanupJob);
  await log(`Cleaning cart after ${activeJob.job.group_key} before starting the next order.`, windowId);
  await navigateWindowToCart(windowId);
}

async function stopJob(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (activeJob?.job?.group_key && activeJob?.workerId) {
    if (orderSubmitStarted(activeJob)) {
      await log(`Stopped local automation for ${activeJob.job.group_key}, but kept server submit lock because Amazon submit already started.`, windowId);
    } else {
      try {
        await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/release`, {
          method: "POST",
          body: JSON.stringify({ worker_id: activeJob.workerId }),
        });
      } catch (error) {
        await log(`Could not release ${activeJob.job.group_key}: ${error.message}`, windowId);
      }
    }
  }
  await setWindowJob(windowId, null);
  await releaseMissingWindowJobs();
  await log("Stopped active job.", windowId);
  return { ok: true, message: "Stopped active job." };
}

async function skipJob(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job to skip." };
  const groupKey = activeJob.job.group_key;
  const released = await releaseStoredJob(activeJob, windowId, "after manual skip");
  if (!released) return { ok: false, message: `Could not release ${groupKey} to skip it.` };
  const nextJob = await claimNextJobInWindow(windowId);
  return {
    ok: true,
    message: nextJob ? `Skipped ${groupKey}. Started ${nextJob.job.group_key}.` : `Skipped ${groupKey}. No more queued Chrome jobs found.`,
    next_job_started: Boolean(nextJob),
    next_group_key: nextJob?.job?.group_key || "",
  };
}

async function markCurrentJobMissing(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job to mark missing." };
  const groupKey = activeJob.job.group_key;
  const result = await failJob("Marked missing from Chrome progress popup.", { failureCode: "manual_missing" }, windowId);
  return {
    ...result,
    message: result.next_job_started
      ? `Marked ${groupKey} as Missing ASINs. Started ${result.next_group_key}.`
      : `Marked ${groupKey} as Missing ASINs. No more queued Chrome jobs found.`,
  };
}

async function checkExistingAmazonOrder(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job?.group_key) return { ok: true, duplicate: false, orders: [] };
  try {
    await heartbeatJob(activeJob, windowId);
  } catch (error) {
    await log(`Continuing duplicate check after heartbeat failed for ${activeJob.job.group_key}: ${error.message}`, windowId);
  }
  let result;
  let lastError = null;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/duplicate-check`, {
        method: "POST",
        timeoutMs: attempt === 1 ? 45000 : 90000,
        body: JSON.stringify({
          worker_id: activeJob.workerId || "",
          line_ids: activeJob.job.line_ids || [],
        }),
      });
      break;
    } catch (error) {
      lastError = error;
      const message = String(error?.message || error || "");
      const transientAbort = /abort|signal|timeout|network/i.test(message);
      if (!transientAbort || attempt === 3) break;
      await log(`Duplicate check retry ${attempt + 1} for ${activeJob.job.group_key} after transient error: ${message}`, windowId);
      await new Promise((resolve) => setTimeout(resolve, 1200 * attempt));
    }
  }
  if (!result) {
    throw lastError || new Error("Duplicate check failed.");
  }
  activeJob.duplicateOrder = result.duplicate ? result : null;
  if (result.duplicate) {
    activeJob.paused = true;
    activeJob.pausedStage = activeJob.stage || "checkout";
    activeJob.stage = "duplicate_order";
    await log(result.message || `Amazon order already exists for ${activeJob.job.group_key}.`, windowId);
  }
  await setWindowJob(windowId, activeJob);
  return result;
}

async function resetDuplicateFulfilment(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job?.group_key) return { ok: false, message: "No active job to reset." };
  const result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/reset-fulfilment`, {
    method: "POST",
    body: JSON.stringify({
      worker_id: activeJob.workerId || "",
      line_ids: activeJob.job.line_ids || [],
    }),
  });
  activeJob.duplicateOrder = null;
  activeJob.paused = false;
  activeJob.pausedStage = null;
  activeJob.stage = "checkout";
  await setWindowJob(windowId, activeJob);
  await log(result.message || `Cleared existing Amazon order for ${activeJob.job.group_key}.`, windowId);
  return result;
}

async function releaseStoredJob(activeJob, windowId = null, label = "Chrome job") {
  if (!activeJob?.job?.group_key || !activeJob?.workerId) return false;
  if (orderSubmitStarted(activeJob)) {
    await log(`Kept ${activeJob.job.group_key} locked ${label}; Amazon submit already started.`, windowId);
    return false;
  }
  try {
    await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/release`, {
      method: "POST",
      body: JSON.stringify({ worker_id: activeJob.workerId }),
    });
    await log(`Released ${activeJob.job.group_key} ${label}.`, windowId);
    return true;
  } catch (error) {
    await log(`Could not release ${activeJob.job.group_key}: ${error.message}`, windowId);
    return false;
  }
}

function orderSubmitStarted(activeJob) {
  const stage = String(activeJob?.stage || "");
  const pausedStage = String(activeJob?.pausedStage || "");
  return Boolean(
    activeJob?.amazonSubmittedAt ||
      activeJob?.amazonDuplicateOrderConfirmed ||
      ["complete_pending", "find_order_id", "reporting_complete"].includes(stage) ||
      ["complete_pending", "find_order_id", "reporting_complete"].includes(pausedStage),
  );
}

async function markAmazonSubmitted(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job?.group_key || !activeJob?.workerId) {
    return { ok: false, message: "No active job to protect before Amazon submit." };
  }
  const result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/submitted`, {
    method: "POST",
    body: JSON.stringify({ worker_id: activeJob.workerId }),
  });
  const latest = (await getWindowState(windowId)).activeJob || activeJob;
  latest.amazonSubmittedAt = latest.amazonSubmittedAt || Date.now();
  latest.stage = "complete_pending";
  latest.paused = false;
  latest.pausedStage = null;
  latest.lastHeartbeatAt = Date.now();
  await setWindowJob(windowId, latest);
  await log(`Protected ${latest.job.group_key} after Amazon submit started.`, windowId);
  return result;
}

async function releaseMissingWindowJobs() {
  if (releaseMissingWindowJobsInFlight) return releaseMissingWindowJobsInFlight;
  if (Date.now() - lastReleaseMissingWindowJobsAt < 15000) return;
  releaseMissingWindowJobsInFlight = (async () => {
    lastReleaseMissingWindowJobsAt = Date.now();
    const state = await getSettings();
    const activeJobsByWindow = { ...(state.activeJobsByWindow || {}) };
    const windows = await chrome.windows.getAll({ windowTypes: ["normal", "popup"] });
    const openWindowIds = new Set(windows.map((item) => String(item.id)));
    let changed = false;
    for (const [windowId, activeJob] of Object.entries(activeJobsByWindow)) {
      if (openWindowIds.has(windowId)) continue;
      const released = await releaseStoredJob(activeJob, Number(windowId) || null, "because its Chrome window is closed");
      if (released) {
        delete activeJobsByWindow[windowId];
        changed = true;
      }
    }
    if (changed) {
      await chrome.storage.local.set({ activeJobsByWindow, activeJob: Object.values(activeJobsByWindow)[0] || null });
    }
  })();
  try {
    await releaseMissingWindowJobsInFlight;
  } finally {
    releaseMissingWindowJobsInFlight = null;
  }
}

async function releaseAllStoredJobs(label = "from the previous Chrome session") {
  const state = await getSettings();
  const activeJobsByWindow = { ...(state.activeJobsByWindow || {}) };
  const seen = new Set();
  const releasedKeys = new Set();
  let changed = false;
  for (const [windowId, activeJob] of Object.entries(activeJobsByWindow)) {
    const groupKey = activeJob?.job?.group_key || "";
    const workerId = activeJob?.workerId || "";
    if (!groupKey || !workerId) continue;
    const key = `${groupKey}:${workerId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const released = await releaseStoredJob(activeJob, Number(windowId) || null, label);
    if (released) {
      releasedKeys.add(key);
      delete activeJobsByWindow[windowId];
      changed = true;
    }
  }
  let activeJob = state.activeJob || null;
  if (activeJob?.job?.group_key && activeJob?.workerId) {
    const key = `${state.activeJob.job.group_key}:${state.activeJob.workerId}`;
    if (releasedKeys.has(key)) {
      activeJob = null;
      changed = true;
    } else if (!seen.has(key)) {
      const released = await releaseStoredJob(state.activeJob, state.activeJob.targetWindowId || null, label);
      if (released) {
        activeJob = null;
        changed = true;
      }
    }
  }
  if (changed) {
    await chrome.storage.local.set({ activeJobsByWindow, activeJob: activeJob || Object.values(activeJobsByWindow)[0] || null, controlWindowsById: {} });
  }
}

async function heartbeatJob(activeJob, windowId) {
  if (!activeJob?.job?.group_key || !activeJob?.workerId) return;
  await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/heartbeat`, {
    method: "POST",
    body: JSON.stringify({ worker_id: activeJob.workerId }),
  });
  activeJob.lastHeartbeatAt = Date.now();
  await setWindowJob(windowId, activeJob);
}

async function togglePause(windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job." };
  const nextPaused = !activeJob.paused;
  if (nextPaused) {
    activeJob.pausedStage = activeJob.stage || activeJob.pausedStage || "product";
  } else if (activeJob.pausedStage) {
    activeJob.stage = activeJob.pausedStage;
    activeJob.pausedStage = null;
  }
  activeJob.paused = nextPaused;
  await setWindowJob(windowId, activeJob);
  await log(`${activeJob.paused ? "Paused" : "Resumed"} ${activeJob.job.group_key}.`, windowId);
  return { ok: true, paused: activeJob.paused, stage: activeJob.stage || "", message: activeJob.paused ? "Paused fulfilment." : `Resumed ${activeJob.stage || "fulfilment"}.` };
}

async function completeJob(orderId, orderUrl, amazonAccountName, windowId, orderMappings = []) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job." };
  const groupKey = activeJob.job.group_key;
  const lockKey = `${windowId || "global"}:${groupKey}`;
  if (completionLocks.has(lockKey)) {
    await log(`Ignored duplicate completion report for ${groupKey}.`, windowId);
    return { ok: true, duplicate_ignored: true, message: `Completion for ${groupKey} is already being reported.` };
  }
  completionLocks.add(lockKey);
  try {
    await heartbeatJob(activeJob, windowId);
    const body = {
      amazon_order_id: orderId || "",
      amazon_order_url: orderUrl || "",
      amazon_account_name: amazonAccountName || "",
      line_ids: activeJob.job.line_ids || [],
      order_mappings: orderMappings || [],
      pricing_summary: Object.values(activeJob.pricing || {}),
      worker_id: activeJob.workerId || "",
    };
    const result = await api(`/api/chrome/jobs/${encodeURIComponent(groupKey)}/complete`, {
      method: "POST",
      body: JSON.stringify(body),
    });
    await log(`Completed ${groupKey} as ${result.amazon_order_id}.`, windowId);
    const latest = await getWindowState(windowId);
    if (latest.activeJob?.job?.group_key !== groupKey) {
      return { ...result, next_job_started: false, next_group_key: "" };
    }
    await clearStoredJobGroup(groupKey);
    const nextJob = await claimNextJobInWindow(windowId);
    return { ...result, next_job_started: Boolean(nextJob), next_group_key: nextJob?.job?.group_key || "" };
  } finally {
    completionLocks.delete(lockKey);
  }
}

async function failJob(message, details = {}, windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job." };
  try {
    await heartbeatJob(activeJob, windowId);
  } catch (error) {
    await log(`Continuing fail report after heartbeat failed for ${activeJob.job.group_key}: ${error.message}`, windowId);
  }
  const result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/fail`, {
    method: "POST",
    body: JSON.stringify({
      message,
      line_ids: activeJob.job.line_ids || [],
      missing_asin: details.missingAsin || "",
      missing_line_id: details.missingLineId || null,
      failure_code: details.failureCode || "",
      requested_quantity: details.requestedQuantity ?? null,
      fulfilled_quantity: details.fulfilledQuantity ?? null,
      available_quantity: details.availableQuantity ?? null,
      worker_id: activeJob.workerId || "",
    }),
  });
  await log(`Failed ${activeJob.job.group_key}: ${message}`, windowId);
  await cleanupCartBeforeNextJob(activeJob, windowId, message);
  return { ...result, next_job_started: false, cleanup_required: true, next_group_key: "" };
}

async function markLineMissing(message, details = {}, windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job." };
  try {
    await heartbeatJob(activeJob, windowId);
  } catch (error) {
    await log(`Continuing partial missing report after heartbeat failed for ${activeJob.job.group_key}: ${error.message}`, windowId);
  }
  const result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/missing-line`, {
    method: "POST",
    body: JSON.stringify({
      message,
      line_ids: activeJob.job.line_ids || [],
      missing_asin: details.missingAsin || "",
      missing_line_id: details.missingLineId || null,
      failure_code: details.failureCode || "",
      requested_quantity: details.requestedQuantity ?? null,
      fulfilled_quantity: details.fulfilledQuantity ?? null,
      available_quantity: details.availableQuantity ?? null,
      worker_id: activeJob.workerId || "",
    }),
  });
  await log(`Partially marked missing in ${activeJob.job.group_key}: ${message}`, windowId);
  if (result?.ok && Number(result.remaining_count || 0) === 0) {
    await cleanupCartBeforeNextJob(activeJob, windowId, message);
  }
  return { ...result, next_job_started: false, cleanup_required: result?.ok && Number(result.remaining_count || 0) === 0, next_group_key: "" };
}

async function costlyJob(message, details = {}, windowId) {
  const { activeJob } = await getWindowState(windowId);
  if (!activeJob?.job) return { ok: false, message: "No active job." };
  await heartbeatJob(activeJob, windowId);
  const result = await api(`/api/chrome/jobs/${encodeURIComponent(activeJob.job.group_key)}/costly`, {
    method: "POST",
    body: JSON.stringify({
      message,
      line_ids: activeJob.job.line_ids || [],
      costly_asin: details.costlyAsin || "",
      costly_line_id: details.costlyLineId || null,
      store_total_price: details.storeTotalPrice || 0,
      amazon_total_price: details.amazonTotalPrice || 0,
      worker_id: activeJob.workerId || "",
    }),
  });
  await setWindowJob(windowId, null);
  await log(`Costly review ${activeJob.job.group_key}: ${message}`, windowId);
  return result;
}

async function clearFailedJobs() {
  const result = await api("/api/chrome/failed-jobs/clear", { method: "POST", body: JSON.stringify({}) });
  await chrome.storage.local.set({ activeJob: null, cachedQueueStatus: null });
  await log(result.message || `Cleared ${result.cleared || 0} failed Chrome job line(s).`);
  return result;
}

chrome.action.onClicked.addListener((tab) => {
  openControlWindow(tab);
});

chrome.runtime.onStartup.addListener(() => {
  releaseAllStoredJobs().catch((error) => log(`Could not release previous Chrome session jobs: ${error.message}`));
});

chrome.runtime.onInstalled.addListener(() => {
  releaseAllStoredJobs("after extension reload").catch((error) => log(`Could not clean up Chrome job locks: ${error.message}`));
});

chrome.windows.onRemoved.addListener((windowId) => {
  (async () => {
    const { controlWindowsById, activeJobsByWindow } = await getSettings();
    const targetWindowId = controlWindowsById?.[String(windowId)] || null;
    if (targetWindowId) {
      await setControlWindow(windowId, null);
      return;
    }
    if (activeJobsByWindow?.[String(windowId)]) {
      await stopJob(windowId);
    }
  })().catch((error) => log(`Could not release Chrome job after window closed: ${error.message}`));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const windowId = messageWindowId(message, sender);
    if (message.type === "START_NEXT") return startNextJob(windowId);
    if (message.type === "REGISTER_CONTROL_WINDOW") {
      await setControlWindow(Number(message.controlWindowId || 0) || null, Number(message.targetWindowId || 0) || null);
      return { ok: true };
    }
    if (message.type === "STOP_JOB") return stopJob(windowId);
    if (message.type === "SKIP_JOB") return skipJob(windowId);
    if (message.type === "MARK_CURRENT_MISSING") return markCurrentJobMissing(windowId);
    if (message.type === "CHECK_EXISTING_AMAZON_ORDER") return checkExistingAmazonOrder(windowId);
    if (message.type === "RESET_DUPLICATE_FULFILMENT") return resetDuplicateFulfilment(windowId);
    if (message.type === "TOGGLE_PAUSE") return togglePause(windowId);
    if (message.type === "GET_STATE") {
      await releaseMissingWindowJobs();
      await refreshActiveJobFromQueue(windowId);
      return getWindowState(windowId);
    }
    if (message.type === "GET_QUEUE_STATUS") {
      await releaseMissingWindowJobs();
      return getQueueStatus();
    }
    if (message.type === "REMEMBER_RECENT_AMAZON_ORDERS") return rememberRecentAmazonOrders(message.orders || []);
    if (message.type === "LOOKUP_AMAZON_HISTORY_ORDERS") return lookupAmazonHistoryOrders(message.orders || []);
    if (message.type === "SYNC_AMAZON_HISTORY_ORDER") return syncAmazonHistoryOrder(message.order || {});
    if (message.type === "GET_RECENT_AMAZON_ORDERS") {
      const { recentAmazonOrders } = await getSettings();
      return { ok: true, orders: recentAmazonOrders || [] };
    }
    if (message.type === "CLAIM_NEXT_IN_WINDOW") {
      const nextJob = await claimNextJobInWindow(windowId);
      return {
        ok: true,
        next_job_started: Boolean(nextJob),
        next_group_key: nextJob?.job?.group_key || "",
        message: nextJob ? `Started next ${nextJob.job.group_key}.` : "No more queued Chrome jobs found.",
      };
    }
    if (message.type === "RECOVER_SUBMITTED_JOB") return recoverSubmittedJobInWindow(windowId);
    if (message.type === "TEST_CONNECTION") return testConnection();
    if (message.type === "GET_ACTIVE_JOB") {
      const { activeJob } = await getWindowState(windowId);
      if (activeJob?.job && activeJob?.workerId && Date.now() - Number(activeJob.lastHeartbeatAt || 0) > 5 * 60 * 1000) {
        try {
          await heartbeatJob(activeJob, windowId);
        } catch (error) {
          await log(`Chrome job lock heartbeat failed: ${error.message}`, windowId);
        }
      }
      return { ok: true, activeJob: (await getWindowState(windowId)).activeJob };
    }
    if (message.type === "HEARTBEAT_JOB") {
      const { activeJob } = await getWindowState(windowId);
      if (!activeJob?.job) return { ok: false, message: "No active job." };
      await heartbeatJob(activeJob, windowId);
      return { ok: true };
    }
    if (message.type === "MARK_ORDER_SUBMITTED") return markAmazonSubmitted(windowId);
    if (message.type === "SET_ACTIVE_JOB") {
      await setWindowJob(windowId, message.activeJob || null);
      return { ok: true };
    }
    if (message.type === "SET_API_BASE") {
      await chrome.storage.local.set({
        apiBase: normalizeApiBase(message.apiBase),
        adminToken: message.adminToken || "",
        cardLast4Preference: message.cardLast4Preference || "",
        editExistingAddress: message.editExistingAddress !== false,
        fulfilAvailableMixedAsin: message.fulfilAvailableMixedAsin === true,
        splitMixedAsinOrders: message.splitMixedAsinOrders === true,
      });
      return { ok: true };
    }
    if (message.type === "COMPLETE_JOB") return completeJob(message.orderId, message.orderUrl, message.amazonAccountName || "", windowId, message.orderMappings || []);
    if (message.type === "MARK_LINE_MISSING") return markLineMissing(message.message || "Chrome extension line is missing.", message, windowId);
    if (message.type === "FAIL_JOB") return failJob(message.message || "Chrome extension job failed.", message, windowId);
    if (message.type === "COSTLY_JOB") return costlyJob(message.message || "Chrome extension job needs costly approval.", message, windowId);
    if (message.type === "CLEAR_FAILED_JOBS") return clearFailedJobs();
    return { ok: false, message: "Unknown message." };
  })()
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({ ok: false, message: connectionErrorMessage(error) }));
  return true;
});
