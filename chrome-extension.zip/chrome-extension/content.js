const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const ACTION_DELAY = 1800;
const PAGE_READY_TIMEOUT = 12000;
const DEFAULT_NEW_DELIVERY_ADDRESS = {
  countryCode: "US",
  phoneNumber: "9176818556",
  addressLine1: "6614 AVENUE U STE 7",
  addressLine2: "",
  city: "BROOKLYN",
  stateOrRegion: "NY",
  postalCode: "11234-6021",
};

let extensionContextAlive = true;
let panelOrderStatusVersion = 0;
let orderHistoryAnnotationScheduled = false;
let orderHistoryAnnotationInFlight = false;
const orderHistoryLookupCache = new Map();
const orderHistorySyncInProgress = new Map();
const orderHistorySyncedConfirmations = new Map();

async function send(message) {
  if (!extensionContextAlive) return null;
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    if (/Extension context invalidated/i.test(String(error?.message || error))) {
      extensionContextAlive = false;
      return null;
    }
    throw error;
  }
}

async function getActiveJob() {
  const data = await send({ type: "GET_ACTIVE_JOB" });
  if (data?.activeJob) return data.activeJob;
  if (!/amazon\.com$/i.test(location.hostname)) return null;
  if (!isOrderHistoryPage() && !confirmationSaysPlaced()) return null;
  const recovered = await send({ type: "RECOVER_SUBMITTED_JOB" });
  return recovered?.activeJob || null;
}

async function setActiveJob(activeJob) {
  await send({ type: "SET_ACTIVE_JOB", activeJob });
}

async function getExtensionState() {
  const data = await send({ type: "GET_STATE" });
  return data || {};
}

async function isPaused() {
  const activeJob = await getActiveJob();
  return Boolean(activeJob?.paused);
}

async function waitIfPaused() {
  while (await isPaused()) {
    const activeJob = await getActiveJob();
    showPanel(
      "Nutricity fulfilment paused",
      "Fulfilment is paused. Click Resume to retry this step, or continue if you completed it manually.",
      "I did it manually, continue",
      () => continueAfterManualStep(activeJob),
    );
    await sleep(1000);
  }
}

async function waitForPageReady(label = "page") {
  showPanel("Nutricity fulfilment", `Waiting for ${label} controls.`, null, null);
  const started = Date.now();
  while (document.readyState === "loading" && Date.now() - started < PAGE_READY_TIMEOUT) {
    await waitIfPaused();
    await sleep(250);
  }
  await waitForStableDom(350, 2500);
  await sleep(200);
}

async function waitForStableDom(quietMs = 1000, timeoutMs = 8000) {
  let lastMutation = Date.now();
  const observer = new MutationObserver(() => {
    lastMutation = Date.now();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
  const started = Date.now();
  try {
    while (Date.now() - started < timeoutMs) {
      await waitIfPaused();
      if (Date.now() - lastMutation >= quietMs) return true;
      await sleep(200);
    }
    return false;
  } finally {
    observer.disconnect();
  }
}

async function waitForElement(selectors, timeoutMs = 18000) {
  const list = Array.isArray(selectors) ? selectors : [selectors];
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    await waitIfPaused();
    for (const selector of list) {
      const element = [...document.querySelectorAll(selector)].find(visible);
      if (element) return element;
    }
    await sleep(300);
  }
  return null;
}

function activeJobOrderLabel(activeJob) {
  const names = Array.isArray(activeJob?.job?.order_names)
    ? activeJob.job.order_names.map((name) => String(name || "").trim()).filter(Boolean)
    : [];
  if (names.length) return names.join(", ");
  const recipient = String(activeJob?.job?.recipient_name || "").replace(/\s+/g, " ").trim();
  if (recipient) return recipient;
  return String(activeJob?.job?.group_key || "").replace(/\s+/g, " ").trim();
}

function activeJobStepLabel(activeJob) {
  const stage = String(activeJob?.stage || "").replace(/_/g, " ").trim();
  if (!stage) return "Preparing";
  return stage.replace(/\b\w/g, (letter) => letter.toUpperCase());
}

async function updatePanelOrderStatus(panel = document.querySelector("#nutricity-panel")) {
  if (!panel) return;
  const version = ++panelOrderStatusVersion;
  const orderNode = panel.querySelector(".nutricity-panel-order");
  const orderText = panel.querySelector(".nutricity-panel-order-text");
  const statusText = panel.querySelector(".nutricity-panel-order-status");
  const stepText = panel.querySelector(".nutricity-panel-step-text");
  if (!orderNode || !orderText || !statusText || !stepText) return;
  const activeJob = await getActiveJob();
  if (version !== panelOrderStatusVersion) return;
  const label = activeJobOrderLabel(activeJob);
  if (!activeJob?.job || !label) {
    orderNode.hidden = true;
    orderText.textContent = "";
    stepText.textContent = "";
    statusText.textContent = "";
    return;
  }
  orderNode.hidden = false;
  orderText.textContent = label;
  stepText.textContent = activeJobStepLabel(activeJob);
  statusText.textContent = activeJob.paused ? "Paused" : "In progress";
}

function showPanel(title, message, actionText, action) {
  let panel = document.querySelector("#nutricity-panel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "nutricity-panel";
    panel.innerHTML = `<div class="nutricity-panel-order" hidden><span class="nutricity-panel-order-label">Order being processed</span><span class="nutricity-panel-order-status"></span><div class="nutricity-panel-order-text"></div><div class="nutricity-panel-step">Step: <span class="nutricity-panel-step-text"></span></div></div><div class="nutricity-panel-header"><strong></strong><button class="nutricity-pause-toggle" type="button">Pause</button></div><div class="nutricity-panel-message"></div><ol class="nutricity-panel-activity"></ol>`;
    panel.querySelector(".nutricity-pause-toggle").addEventListener("click", togglePanelPause);
    document.documentElement.append(panel);
  }
  panel.querySelector("strong").textContent = title;
  panel.querySelector(".nutricity-panel-message").textContent = message;
  rememberPanelActivity(panel, title, message);
  panel.querySelector(".nutricity-panel-action")?.remove();
  updatePanelPauseButton(panel);
  updatePanelOrderStatus(panel);
  if (actionText && action) {
    const button = document.createElement("button");
    button.className = "nutricity-panel-action";
    button.textContent = actionText;
    button.addEventListener("click", action);
    panel.append(button);
  }
}

function rememberPanelActivity(panel, title, message) {
  const activity = panel.querySelector(".nutricity-panel-activity");
  if (!activity || !message) return;
  const text = `${title}: ${message}`.replace(/\s+/g, " ").trim();
  if (activity.firstElementChild?.dataset?.text === text) return;
  const item = document.createElement("li");
  item.dataset.text = text;
  item.textContent = text;
  activity.prepend(item);
  while (activity.children.length > 5) {
    activity.lastElementChild.remove();
  }
}

async function togglePanelPause(event) {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    const result = await send({ type: "TOGGLE_PAUSE" });
    const paused = Boolean(result?.paused);
    button.textContent = paused ? "Resume" : "Pause";
    button.classList.toggle("is-paused", paused);
    if (paused) {
      const activeJob = await getActiveJob();
      showPanel(
        "Nutricity fulfilment paused",
        "Fulfilment is paused. Click Resume to retry this step, or continue if you completed it manually.",
        "I did it manually, continue",
        () => continueAfterManualStep(activeJob),
      );
    } else {
      showPanel("Nutricity fulfilment", `Resuming ${result?.stage || "last step"}.`, null, null);
      setTimeout(runSafely, 250);
    }
  } finally {
    button.disabled = false;
  }
}

async function updatePanelPauseButton(panel = document.querySelector("#nutricity-panel")) {
  if (!panel) return;
  const button = panel.querySelector(".nutricity-pause-toggle");
  if (!button) return;
  const activeJob = await getActiveJob();
  if (!activeJob?.job) {
    button.hidden = true;
    return;
  }
  button.hidden = false;
  button.textContent = activeJob.paused ? "Resume" : "Pause";
  button.classList.toggle("is-paused", Boolean(activeJob.paused));
}

function visible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
}

function clickFirst(selectors) {
  for (const selector of selectors) {
    const element = [...document.querySelectorAll(selector)].find(visible);
    if (element) {
      element.scrollIntoView({ block: "center", behavior: "smooth" });
      element.click();
      return true;
    }
  }
  return false;
}

async function clickElement(element, label = "element") {
  if (!element) return false;
  await waitIfPaused();
  element.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(250);
  await waitIfPaused();
  element.click();
  await sleep(ACTION_DELAY);
  return true;
}

function findButtonByText(texts) {
  const wanted = texts.map((text) => text.toLowerCase());
  const candidates = [...document.querySelectorAll("button, input[type='submit'], input[type='button'], a, span.a-button")];
  return candidates.find((element) => {
    const labelledBy = element.getAttribute?.("aria-labelledby");
    const labelText = labelledBy ? document.getElementById(labelledBy)?.textContent : "";
    const text = (element.value || element.title || element.innerText || element.textContent || labelText || "").replace(/\s+/g, " ").trim().toLowerCase();
    return visible(element) && wanted.some((needle) => text.includes(needle));
  });
}

function findVisibleTextTarget(texts, selectors = "a, button, input[type='submit'], input[type='button'], label, span.a-button, span.a-button-text, [role='button'], [role='option']") {
  const wanted = texts.map((text) => text.toLowerCase());
  const candidates = [...document.querySelectorAll(selectors)];
  return candidates.find((element) => {
    const text = (element.value || element.innerText || element.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    return visible(element) && wanted.some((needle) => text.includes(needle));
  });
}

function parsePriceFrom(element) {
  if (!element) return null;
  if (isUnitPriceElement(element)) return null;
  const offscreen = element.querySelector(".a-offscreen")?.textContent || "";
  const offscreenPrice = priceFromText(offscreen);
  if (offscreenPrice) return offscreenPrice;
  const whole = element.querySelector(".a-price-whole")?.textContent || "";
  const fraction = element.querySelector(".a-price-fraction")?.textContent || "00";
  const value = Number(`${whole.replace(/[^0-9]/g, "")}.${fraction.replace(/[^0-9]/g, "").slice(0, 2)}`);
  if (Number.isFinite(value) && value > 0) return value;
  return priceFromText(element.textContent || "");
}

function isUnitPriceElement(element) {
  if (!element) return false;
  if (element.closest(".aok-relative")) return true;
  const text = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
  if (/\/\s*(?:count|ct|unit|each|oz|ounce|fl\s*oz|lb|pound|g|gram|mg|ml)\b/i.test(text)) return true;
  for (let node = element.parentElement; node && node !== document.body; node = node.parentElement) {
    const nodeText = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
    if (nodeText.length > 80) break;
    if (/\/\s*(?:count|ct|unit|each|oz|ounce|fl\s*oz|lb|pound|g|gram|mg|ml)\b/i.test(nodeText)) return true;
  }
  return false;
}

function priceCandidatesIn(root, selectors = [".a-price"]) {
  if (!root) return null;
  const prices = selectors
    .flatMap((selector) => [...root.querySelectorAll(selector)])
    .filter((element, index, all) => all.indexOf(element) === index && visible(element) && !element.closest(".aok-hidden"))
    .map(parsePriceFrom)
    .filter((value) => Number(value) > 0);
  return prices;
}

function priceCandidateElementsIn(root, selectors = [".a-price"]) {
  if (!root) return [];
  return selectors
    .flatMap((selector) => [...root.querySelectorAll(selector)])
    .filter((element, index, all) => all.indexOf(element) === index && visible(element) && !element.closest(".aok-hidden"));
}

function firstPriceIn(root) {
  if (!root) return null;
  const prices = priceCandidatesIn(root);
  return prices[0] || priceFromText(root.innerText || root.textContent || "");
}

function lowestPriceIn(root, selectors = [".a-price"]) {
  const prices = priceCandidatesIn(root, selectors);
  return prices.length ? Math.min(...prices) : null;
}

function moneyText(value) {
  const number = Number(value || 0);
  return number ? `$${number.toFixed(2)}` : "unknown price";
}

function isInSubscribeAndSave(element) {
  return Boolean(element?.closest?.(subscribeAndSaveRootSelector()));
}

function subscribeAndSaveRootSelector() {
  return [
    "#snsAccordionRowMiddle",
    "#snsAccordionRow",
    "#snsAccordionRowContent",
    "#reinvent_price_desktop_snsAccordionRowMiddle",
    "#snsQuantity_feature_div",
    "[data-csa-c-buying-option-type='SNS']",
    "[data-csa-c-slot-id*='sns']",
    "[id*='rcx-subscribe']",
    "[id*='rcxOrdFreqSns']",
    "[id*='snsAccordion']",
    "[id*='snsBuyingOption']",
    "[data-a-accordion-row-name*='sns']",
  ].join(", ");
}

function subscribeAndSavePriceFromText(text) {
  const match = String(text || "")
    .replace(/,/g, "")
    .match(/subscribe\s*&\s*save\s*\$+\s*([0-9]+(?:\.[0-9]{1,2})?)/i);
  if (!match) return null;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : null;
}

function oneTimePurchaseRootSelector() {
  return [
    "#qualifiedBuybox",
    "#desktop_qualifiedBuyBox",
    "#buybox",
    "#newAccordionRow",
    "#reinvent_price_desktop_newAccordionRow",
    "[data-csa-c-buying-option-type='NEW']",
    "[data-csa-c-buying-option-type='B2B']",
    "[data-a-accordion-row-name*='new']",
  ].join(", ");
}

function oneTimePurchaseRoots() {
  const roots = [...document.querySelectorAll(oneTimePurchaseRootSelector())].filter((root) => visible(root) && !isInSubscribeAndSave(root));
  for (const node of document.querySelectorAll("[id*='new_buyingOption'], [id*='DesktopFfqp_'][id*='new_buyingOption']")) {
    const root = node.closest("[data-csa-c-buying-option-type], [data-a-accordion-row-name], .a-accordion-row, .a-box, #qualifiedBuybox, #desktop_qualifiedBuyBox, #buybox") || node.closest(".a-section") || node;
    if (root && visible(root) && !isInSubscribeAndSave(root) && !roots.includes(root)) roots.push(root);
  }
  for (const node of document.querySelectorAll("button, [role='button'], .a-accordion-row, .a-box, #rightCol, #desktop_buybox")) {
    if (!visible(node) || isInSubscribeAndSave(node) || roots.includes(node)) continue;
    const text = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    if (!text.includes("one-time purchase") || !/\$\s*\d/.test(text)) continue;
    roots.push(node);
  }
  return roots;
}

function productPriceSnapshot() {
  const regularPriceSelectors = [
    ".a-price[data-a-color='price'][data-a-size='b']",
    ".a-price[data-a-color='price'].header-price",
    ".a-price.a-color-price[data-a-size='b']",
    "#corePrice_feature_div .a-price[data-a-size='b']",
    "#apex_desktop .a-price[data-a-size='b']",
    "#reinvent_price_desktop_newAccordionRow .a-price[data-a-size='b']",
    "#newAccordionRow .a-price[data-a-size='b']",
    "#buybox .a-price[data-a-size='b']",
    "#tp_price_block_total_price_ww .a-price[data-a-size='b']",
  ];
  const regularRoots = oneTimePurchaseRoots();
  const regularPool = regularRoots.length ? regularRoots : [document];
  const regularPrices = regularPool
    .flatMap((root) => priceCandidateElementsIn(root, regularPriceSelectors))
    .filter((element, index, all) => all.indexOf(element) === index && visible(element) && !isInSubscribeAndSave(element) && !element.closest(".aok-hidden"))
    .map(parsePriceFrom)
    .filter((value) => Number(value) > 0);
  const regularFallbackPrices = regularPrices.length ? [] : regularRoots
    .map((root) => firstPriceIn(root))
    .filter((value) => Number(value) > 0);
  const regular = regularPrices.length ? Math.min(...regularPrices) : (regularFallbackPrices.length ? Math.min(...regularFallbackPrices) : null);
  const snsRoots = [...document.querySelectorAll(subscribeAndSaveRootSelector())].filter(visible);
  const snsPriceSelectors = [
    "#sns-tiered-price .a-price[data-a-size='b']",
    "#subscriptionPrice .a-price[data-a-color='secondary'][data-a-size='b']",
    ".a-price[data-a-color='secondary'][data-a-size='b']",
    ".a-price[data-a-color='secondary'].header-price",
    ".a-price.a-color-price[data-a-size='b']",
  ];
  const snsPrices = snsRoots
    .flatMap((root) => priceCandidatesIn(root, snsPriceSelectors))
    .filter((value) => Number(value) > 0);
  const sns = snsPrices.length ? Math.min(...snsPrices) : subscribeAndSavePriceFromText(document.body.innerText);
  const best = sns && regular ? Math.min(sns, regular) : sns || regular || 0;
  return { regular, sns, best };
}

function snsQuantityControlVisible() {
  if (!subscribeAndSaveAccordionIsActive()) return false;
  return Boolean([...document.querySelectorAll(subscribeAndSaveRootSelector())].find((root) => {
    if (!visible(root)) return false;
    const control = root.querySelector("select[id*='sns'][id*='predefinedQuantitiesDropdown'], input#rcxsubsQuan, input[id*='sns'][id$='freeQuantityTextInput']");
    return visible(control) || visible(control?.closest?.("td, table, .a-section, .a-dropdown-container"));
  }));
}

function productTitleText() {
  return (document.querySelector("#productTitle")?.textContent || document.querySelector("#title")?.textContent || "").replace(/\s+/g, " ").trim();
}

function dosageFromProductTitle() {
  const match = productTitleText().match(/\b(\d+(?:\.\d+)?)\s*mg\b/i);
  return match ? `${match[1]}mg` : "";
}

function rememberProductDosage(activeJob, item = null) {
  const dosage = dosageFromProductTitle();
  if (!dosage) return activeJob;
  const dosages = Array.isArray(activeJob.productDosages) ? activeJob.productDosages : [];
  if (!dosages.map((item) => String(item).toLowerCase()).includes(dosage.toLowerCase())) {
    activeJob.productDosages = [...dosages, dosage];
  }
  const dosageByOrder = activeJob.dosageByOrder && typeof activeJob.dosageByOrder === "object" ? activeJob.dosageByOrder : {};
  const orderNames = item?.order_names?.length ? item.order_names : activeJob.job?.order_names || [];
  for (const orderName of orderNames) {
    const key = String(orderName || "").trim();
    if (!key) continue;
    const orderDosages = Array.isArray(dosageByOrder[key]) ? dosageByOrder[key] : [];
    if (!orderDosages.map((value) => String(value).toLowerCase()).includes(dosage.toLowerCase())) {
      dosageByOrder[key] = [...orderDosages, dosage];
    }
  }
  activeJob.dosageByOrder = dosageByOrder;
  return activeJob;
}

function recipientName(activeJob) {
  const orderNames = Array.isArray(activeJob?.job?.order_names) ? activeJob.job.order_names : [];
  const mixedAsin = isMixedAsinOrder(activeJob);
  const recipientSuffix = String(activeJob?.job?.recipient_suffix || "").replace(/\s+/g, "").trim();
  const dosageByOrder = activeJob?.dosageByOrder && typeof activeJob.dosageByOrder === "object" ? activeJob.dosageByOrder : {};
  if (orderNames.length) {
    const parts = ["Nutricity"];
    const assigned = new Set();
    for (const orderName of orderNames) {
      const name = String(orderName || "").trim();
      if (!name) continue;
      parts.push(name);
      if (mixedAsin) continue;
      const dosages = Array.isArray(dosageByOrder[name]) ? dosageByOrder[name] : [];
      for (const dosage of dosages) {
        const normalized = String(dosage || "").replace(/\s+/g, "").trim();
        if (normalized) {
          parts.push(normalized);
          assigned.add(normalized.toLowerCase());
        }
      }
    }
    if (mixedAsin) parts.push("Multi");
    const globalDosages = (Array.isArray(activeJob?.productDosages) ? activeJob.productDosages : [])
      .map((item) => String(item || "").replace(/\s+/g, "").trim())
      .filter(Boolean);
    for (const dosage of mixedAsin ? [] : globalDosages) {
      if (!assigned.has(dosage.toLowerCase())) parts.push(dosage);
    }
    if (recipientSuffix) parts.push(recipientSuffix);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }
  const base = String(activeJob?.job?.recipient_name || "").replace(/\s+/g, " ").trim();
  if (mixedAsin) return `${base} Multi${recipientSuffix ? ` ${recipientSuffix}` : ""}`.replace(/\s+/g, " ").trim();
  const dosages = (Array.isArray(activeJob?.productDosages) ? activeJob.productDosages : [])
    .map((item) => String(item || "").replace(/\s+/g, "").trim())
    .filter((dosage) => dosage && !base.toLowerCase().includes(dosage.toLowerCase()));
  return [base, ...dosages, recipientSuffix].filter(Boolean).join(" ").trim();
}

function priceFromText(text) {
  const match = String(text || "").replace(/,/g, "").match(/\$\s*([0-9]+(?:\.[0-9]{1,2})?)/);
  if (!match) return null;
  const value = Number(match[1]);
  return Number.isFinite(value) ? value : null;
}

function normalizedPackUnit(unit) {
  const value = String(unit || "").toLowerCase().replace(/\s+/g, " ").trim();
  if (!value) return "";
  if (/^(counts?|ct|capsules?|tablets?|softgels?|gummies?|packs?|pieces?|pcs)$/.test(value)) return "count";
  if (/^(fl oz|fluid ounces?)$/.test(value)) return "fl oz";
  if (/^(ounces?|oz)$/.test(value)) return "oz";
  if (/^(pounds?|lbs?)$/.test(value)) return "lb";
  if (/^(grams?|g)$/.test(value)) return "g";
  if (/^(milligrams?|mg)$/.test(value)) return "mg";
  if (/^(milliliters?|ml)$/.test(value)) return "ml";
  if (/^(liters?|l)$/.test(value)) return "l";
  return value;
}

function parseCountPack(text) {
  const normalized = String(text || "").replace(/\s+/g, " ").trim();
  if (!normalized) return null;
  const countMatch = normalized.match(/\b(\d+(?:\.\d+)?)\s*(?:mini\s*)?(counts?|ct|capsules?|tablets?|softgels?|gummies?|packs?|pieces?|pcs)\b/i);
  const amountMatch = normalized.match(/\b(\d+(?:\.\d+)?)\s*(fl\s*oz|fluid\s*ounces?|ounces?|oz|pounds?|lbs?|grams?|g|milligrams?|mg|milliliters?|ml|liters?|l)\b/i);
  const sizeMatch = countMatch || amountMatch;
  if (!sizeMatch) return null;
  const packMatch = normalized.match(/\bpack\s*of\s*(\d+(?:\.\d+)?)\b/i);
  const count = Number(sizeMatch[1]);
  const pack = packMatch ? Number(packMatch[1]) : 1;
  const units = count * pack;
  if (!Number.isFinite(units) || units <= 0) return null;
  const unit = normalizedPackUnit(countMatch ? "count" : sizeMatch[2]);
  return { count, pack, units, unit, label: normalized };
}

function itemCountPack(item) {
  const names = [
    item.product_name,
    ...(Array.isArray(item.product_names) ? item.product_names : []),
  ].filter(Boolean);
  for (const name of names) {
    const parsed = parseCountPack(name);
    if (parsed) return parsed;
  }
  return null;
}

function selectedVariantFromPage() {
  const text =
    document.querySelector("[id^='inline-twister-expanded-dimension-text']")?.textContent ||
    document.querySelector("[aria-label^='Selected Size is'], [aria-label^='Selected Style is']")?.getAttribute("aria-label") ||
    "";
  return parseCountPack(text);
}

function swatchLabel(swatch) {
  const label =
    swatch.querySelector(".swatch-title-text")?.textContent ||
    swatch.querySelector("img[alt]")?.getAttribute("alt") ||
    swatch.querySelector(".a-button-text")?.textContent ||
    "";
  return label.replace(/\s+/g, " ").trim();
}

function swatchPrice(swatch) {
  return (
    parsePriceFrom(swatch.querySelector(".apex-pricetopay-value")) ||
    parsePriceFrom(swatch.querySelector(".a-price")) ||
    priceFromText(swatch.innerText || swatch.textContent)
  );
}

function variantSwatches() {
  const rows = [
    ...document.querySelectorAll("#twister-plus-inline-twister-card li[data-asin], #twister-plus-inline-twister li[data-asin], li.inline-twister-swatch[data-asin]"),
  ];
  const seen = new Set();
  return rows
    .filter((swatch) => {
      const asin = (swatch.getAttribute("data-asin") || "").toUpperCase();
      if (!asin || seen.has(asin)) return false;
      seen.add(asin);
      return swatch.getAttribute("data-initiallyunavailable") !== "true";
    })
    .map((swatch) => {
      const label = swatchLabel(swatch);
      const parsed = parseCountPack(label);
      const price = swatchPrice(swatch);
      const asin = (swatch.getAttribute("data-asin") || "").toUpperCase();
      const selected =
        swatch.getAttribute("data-initiallyselected") === "true" ||
        Boolean(swatch.querySelector(".a-button-selected, input[aria-checked='true']"));
      const target = swatch.querySelector("input.a-button-input, button, .a-button") || swatch;
      return parsed && price ? { ...parsed, asin, price, selected, target } : null;
    })
    .filter(Boolean);
}

function selectedVariantItem(activeJob, item) {
  const selection = activeJob.variantSelections?.[item.asin];
  if (!selection) return item;
  return {
    ...item,
    asin: selection.asin || item.asin,
    quantity: selection.quantity || item.quantity,
    original_asin: item.asin,
    selected_variant_label: selection.label || "",
    selected_variant_units: selection.units || null,
    requested_total_units: selection.requested_total_units || null,
  };
}

function purchaseAsinForJobItem(activeJob, item) {
  return String(selectedVariantItem(activeJob, item)?.asin || item?.asin || "").toUpperCase();
}

function uniquePurchaseAsins(activeJob) {
  const asins = new Set();
  for (const item of activeJob?.job?.items || []) {
    const asin = purchaseAsinForJobItem(activeJob, item);
    if (asin) asins.add(asin);
  }
  return asins;
}

function isMixedAsinOrder(activeJob) {
  return uniquePurchaseAsins(activeJob).size > 1;
}

function variantSelectionNote(item, purchaseItem) {
  if (!purchaseItem.selected_variant_label || !purchaseItem.original_asin || purchaseItem.original_asin === purchaseItem.asin) return "";
  const originalLabel = itemCountPack(item)?.label || item.product_name || item.asin;
  const orderedQuantity = Number(item.quantity || 1);
  const purchaseQuantity = Number(purchaseItem.quantity || 1);
  const totalUnits = purchaseItem.requested_total_units ? ` (${purchaseItem.requested_total_units} total count)` : "";
  return `Equivalent Amazon pack variant found and used: ordered ${orderedQuantity} x ${originalLabel}${totalUnits}; purchased ${purchaseQuantity} x ${purchaseItem.selected_variant_label} (${purchaseItem.asin}) instead of ${item.asin}.`;
}

function chooseBestCountVariant(item, currentUnitPrice) {
  const ordered = itemCountPack(item) || selectedVariantFromPage();
  if (!ordered || !currentUnitPrice) return null;
  const requestedQuantity = Math.max(1, Math.round(Number(item.quantity || 1)));
  const requestedTotalUnits = ordered.units * requestedQuantity;
  const variants = variantSwatches();
  if (!variants.length) return null;

  const currentAsin = currentAsinFromUrl() || item.asin;
  const currentPageVariant = selectedVariantFromPage();
  if (currentPageVariant && currentUnitPrice) {
    variants.push({
      ...currentPageVariant,
      asin: currentAsin,
      price: currentUnitPrice,
      selected: true,
      target: null,
    });
  }

  const candidates = variants
    .map((variant) => {
      if (ordered.unit && variant.unit && ordered.unit !== variant.unit) return null;
      const purchaseQuantity = requestedTotalUnits / variant.units;
      if (!Number.isInteger(purchaseQuantity) || purchaseQuantity < 1) return null;
      return {
        ...variant,
        quantity: purchaseQuantity,
        total: purchaseQuantity * variant.price,
        requested_total_units: requestedTotalUnits,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.total - b.total || a.quantity - b.quantity || b.units - a.units);
  if (!candidates.length) return null;

  const currentTotal = Number(currentUnitPrice || 0) * requestedQuantity;
  const best = candidates[0];
  if (best.asin === currentAsin && best.quantity === requestedQuantity) {
    return null;
  }
  if (currentTotal && best.total >= currentTotal - 0.01) return null;
  return best;
}

async function selectCheapestCountVariant(activeJob, item, currentUnitPrice) {
  const best = chooseBestCountVariant(item, currentUnitPrice);
  if (!best) return false;
  activeJob.variantSelections = activeJob.variantSelections || {};
  activeJob.variantSelections[item.asin] = {
    asin: best.asin,
    quantity: best.quantity,
    label: best.label,
    units: best.units,
    price: best.price,
    requested_total_units: best.requested_total_units,
  };
  await setActiveJob(activeJob);
  if (best.asin !== currentAsinFromUrl()) {
    const currentTotal = Number(currentUnitPrice || 0) * Math.max(1, Math.round(Number(item.quantity || 1)));
    const savingText = currentTotal && best.total < currentTotal - 0.01 ? " for less" : "";
    showPanel("Nutricity fulfilment", `Switching to ${best.label} to buy ${best.requested_total_units} total count${savingText}.`, null, null);
    if (best.target && visible(best.target)) {
      best.target.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(500);
      best.target.click();
      await sleep(2500);
    }
    if (currentAsinFromUrl() !== best.asin) {
      location.href = `https://www.amazon.com/dp/${best.asin}`;
    }
    return true;
  }
  return false;
}

async function recordAmazonPrice(activeJob, item, unitPrice, source = "product", purchaseItem = item) {
  if (!unitPrice) return activeJob;
  activeJob.pricing = activeJob.pricing || {};
  const quantity = Number(purchaseItem.quantity || item.quantity || 1);
  const storeUnit = Number(item.store_unit_price || 0);
  const storeTotal = Number(item.store_total_price || storeUnit * Number(item.quantity || 1) || 0);
  const amazonTotal = unitPrice * quantity;
  activeJob.pricing[item.asin] = {
    asin: item.asin,
    purchased_asin: purchaseItem.asin || item.asin,
    quantity,
    ordered_quantity: Number(item.quantity || 1),
    selected_variant_label: purchaseItem.selected_variant_label || "",
    requested_total_units: purchaseItem.requested_total_units || null,
    fulfilment_note: variantSelectionNote(item, purchaseItem),
    store_unit_price: storeUnit,
    store_total_price: storeTotal,
    amazon_unit_price: unitPrice,
    amazon_total_price: amazonTotal,
    profit_total: storeTotal - amazonTotal,
    source,
  };
  await setActiveJob(activeJob);
  return activeJob;
}

function currentAsinFromUrl() {
  const match = location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
  return match ? match[1].toUpperCase() : "";
}

function itemPrimaryLineId(item) {
  return item.line_id || item.line_ids?.[0] || null;
}

function comparableText(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}

function matchCheckoutIssueItem(activeJob, title) {
  const items = activeJob.job?.items || [];
  if (!items.length) return null;
  if (items.length === 1) return items[0];
  const wanted = comparableText(title);
  if (!wanted) return null;
  return items.find((item) => {
    const names = [item.product_name, ...(item.product_names || [])].map(comparableText).filter(Boolean);
    return names.some((name) => name.includes(wanted) || wanted.includes(name));
  }) || null;
}

function checkoutLineItemGroups(panel) {
  return [...panel.querySelectorAll("[id^='line-item-group-display-']")]
    .filter((element) => visible(element) && !element.classList.contains("aok-hidden"));
}

function checkoutLineItemTitle(groupView) {
  const titleNode = groupView?.querySelector?.(".lineitem-title-text, [id^='item-block-product-title-']");
  return String(titleNode?.innerText || titleNode?.textContent || "").replace(/\s+/g, " ").trim();
}

function checkoutLineItemQuantity(groupView) {
  const stepper = groupView?.querySelector?.("[name='stma-checkout-quantity-stepper'], [data-a-component='stepper']");
  const rawValue = stepper?.getAttribute?.("data-steppervalue")
    ?? stepper?.getAttribute?.("data-displaystring")
    ?? stepper?.querySelector?.("[data-a-selector='inner-value']")?.textContent
    ?? (groupView?.innerText || groupView?.textContent || "").match(/Quantity:\s*(\d+)/i)?.[1]
    ?? "";
  const value = Number(String(rawValue).trim());
  return Number.isFinite(value) ? value : null;
}

function checkoutLineItemLimitCandidate(activeJob, groupView) {
  if (!groupView) return null;
  const groupText = normalizedText(groupView.innerText || groupView.textContent);
  if (
    !groupText.includes("limited purchase quantity") ||
    !groupText.includes("business has reached it")
  ) {
    return null;
  }
  const title = checkoutLineItemTitle(groupView);
  const item = matchCheckoutIssueItem(activeJob, title);
  const currentQuantity = checkoutLineItemQuantity(groupView);
  const removeButton = [...groupView.querySelectorAll("a.js-delete-button, a[aria-label='Remove item'], a, button")]
    .find((element) => visible(element) && normalizedText(element.getAttribute?.("aria-label") || element.innerText || element.textContent).includes("remove item"));
  return {
    item,
    title,
    currentQuantity,
    removeButton,
    message: "Limit purchase: Amazon says this item has limited purchase quantity and the business has already reached it.",
  };
}

function checkoutLimitPurchaseIssue(activeJob) {
  const panel = document.querySelector("#checkout-javaItemSelectPanel");
  if (!panel || !visible(panel)) return null;
  const panelText = normalizedText(panel.innerText || panel.textContent);
  if (
    !panelText.includes("limited purchase quantity") ||
    !panelText.includes("business has reached it")
  ) {
    return null;
  }

  const lineIssue = checkoutLineItemGroups(panel)
    .map((groupView) => checkoutLineItemLimitCandidate(activeJob, groupView))
    .find(Boolean);
  if (lineIssue) return lineIssue;

  const messageNode = [...panel.querySelectorAll("[data-messageid='AmazonBusinessCVMessages'], .line-item-destination-message-groups")]
    .find((element) => normalizedText(element.innerText || element.textContent).includes("limited purchase quantity"));
  const parentView = messageNode?.closest?.("[id^='line-item-parent-view-']");
  const parentId = parentView?.id || "";
  const suffix = parentId.startsWith("line-item-parent-view-") ? parentId.slice("line-item-parent-view-".length) : "";
  const groupView = suffix ? document.getElementById(`line-item-group-display-${suffix}`) : messageNode?.closest?.("[id^='line-item-group-display-']");
  const titleNode = suffix ? document.getElementById(`item-block-product-title-${suffix}`) : groupView?.querySelector?.(".lineitem-title-text, [id^='item-block-product-title-']");
  const title = String(titleNode?.innerText || titleNode?.textContent || "").replace(/\s+/g, " ").trim();
  const item = matchCheckoutIssueItem(activeJob, title);
  const removeButton = [...(groupView || parentView || panel).querySelectorAll?.("a.js-delete-button, a[aria-label='Remove item'], a, button") || []]
    .find((element) => visible(element) && normalizedText(element.getAttribute?.("aria-label") || element.innerText || element.textContent).includes("remove item"));
  const currentQuantity = checkoutLineItemQuantity(groupView);
  return {
    item,
    title,
    currentQuantity,
    removeButton,
    message: "Limit purchase: Amazon says this item has limited purchase quantity and the business has already reached it.",
  };
}

function cartDeleteButtons() {
  const activeCart = document.querySelector("#sc-active-cart");
  if (!activeCart || !visible(activeCart)) return [];
  const activeItems = [...activeCart.querySelectorAll("[data-itemtype='active'], .sc-list-item[data-asin]")].filter(visible);
  const buttons = activeItems
    .map((item) =>
      item.querySelector(
        "input[data-action='delete-active'][data-feature-id='item-delete-button'], input[name^='submit.delete-active.'][value='Delete']",
      ),
    )
    .filter((button) => button && visible(button));
  if (buttons.length) return [...new Set(buttons)];
  return [
    ...activeCart.querySelectorAll(
      "input[data-action='delete-active'][data-feature-id='item-delete-button'], input[name^='submit.delete-active.'][value='Delete']",
    ),
  ].filter(visible);
}

function cartLooksEmpty() {
  const text = (document.body.innerText || "").replace(/\s+/g, " ").toLowerCase();
  return (
    text.includes("your amazon cart is empty") ||
    text.includes("your shopping cart is empty") ||
    text.includes("cart is empty")
  );
}

function cartItemQuantity(item) {
  const stepperValue = [
    "[data-a-selector='inner-value']",
    "[data-a-selector='value'] [data-a-selector='inner-value']",
    "[data-action='a-stepper-spinbutton'] [data-a-selector='value']",
    ".a-stepper [data-a-selector='value']",
    ".a-stepper-value-live",
  ]
    .map((selector) => [...item.querySelectorAll(selector)].find(visible))
    .find(Boolean);
  if (stepperValue) {
    const value = Number((stepperValue.innerText || stepperValue.textContent || "").replace(/[^\d.]/g, ""));
    if (Number.isFinite(value) && value > 0) return value;
  }
  const quantityButton = [...item.querySelectorAll("button[aria-label*='quantity' i], button[aria-label*='Increase quantity' i], button[aria-label*='Decrease quantity' i]")]
    .find((button) => visible(button) && /\b\d+\b/.test(button.getAttribute("aria-label") || ""));
  if (quantityButton) {
    const value = Number((quantityButton.getAttribute("aria-label") || "").match(/\b(\d+)\b/)?.[1]);
    if (Number.isFinite(value) && value > 0) return value;
  }
  const prompt = [...item.querySelectorAll(".a-dropdown-prompt, [data-a-class*='quantity' i] .a-button-text")]
    .find((node) => visible(node) && /^\s*\d+\s*$/.test(node.innerText || node.textContent || ""));
  if (prompt) {
    const value = Number((prompt.innerText || prompt.textContent || "").trim());
    if (Number.isFinite(value) && value > 0) return value;
  }
  const select = item.querySelector("select[name='quantity'], select[id*='quantity']");
  if (select?.value) {
    const value = Number(select.value);
    if (Number.isFinite(value) && value > 0) return value;
  }
  const input = item.querySelector("input[name='quantity'], input[id*='quantity']");
  if (input?.value) {
    const value = Number(input.value);
    if (Number.isFinite(value) && value > 0) return value;
  }
  const text = (item.innerText || item.textContent || "").replace(/\s+/g, " ");
  const match = text.match(/\bQty(?:uantity)?\s*:?\s*(\d+)\b/i);
  return match ? Number(match[1]) : 1;
}

function cartActiveItems() {
  const activeCart = document.querySelector("#sc-active-cart");
  const activeRoots = [
    activeCart,
    document.querySelector("[data-name='Active Items']"),
    document.querySelector("[aria-label='Shopping Cart']"),
  ].filter((root) => root && visible(root));
  const candidates = [];
  for (const root of activeRoots) {
    candidates.push(...root.querySelectorAll("[data-itemtype='active'], .sc-list-item, [data-asin], [data-name='Active Items'] [role='listitem']"));
  }

  // Amazon's newer cart can omit #sc-active-cart. In that layout, active cart
  // rows are still anchored by visible Delete buttons and quantity controls.
  for (const control of document.querySelectorAll("button[aria-label^='Delete '], input[aria-label^='Delete '], button[title^='Delete '], input[value='Delete']")) {
    if (!visible(control)) continue;
    let node = control;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      const text = (node.innerText || node.textContent || "").replace(/\s+/g, " ");
      const hasProductLink = Boolean(node.querySelector?.("a[href*='/dp/'], a[href*='/gp/product/']"));
      const hasQuantityControl = Boolean(node.querySelector?.("select[name='quantity'], input[name='quantity'], button[aria-label*='quantity' i], [data-a-selector='inner-value']"));
      if (hasProductLink && (hasQuantityControl || /in stock|size:/i.test(text))) {
        candidates.push(node);
        break;
      }
    }
  }

  const seen = new Set();
  return candidates
    .filter((item) => {
      if (!item || !visible(item)) return false;
      const text = (item.innerText || item.textContent || "").replace(/\s+/g, " ");
      if (/saved for later|sponsored|discover more|buy it again/i.test(text)) return false;
      if (!item.querySelector?.("a[href*='/dp/'], a[href*='/gp/product/']")) return false;
      if (!item.querySelector?.("button[aria-label^='Delete '], input[aria-label^='Delete '], button[title^='Delete '], input[value='Delete'], [data-itemtype='active'], .sc-list-item")) return false;
      if (seen.has(item)) return false;
      seen.add(item);
      return true;
    });
}

function cartIsVisiblyEmpty() {
  const emptyCart = document.querySelector("#sc-empty-cart");
  const emptyHeading = [...document.querySelectorAll("h1, h2, h3")].find((element) => (
    visible(element) && /your amazon cart is empty/i.test(element.innerText || element.textContent || "")
  ));
  return Boolean((emptyCart && visible(emptyCart)) || emptyHeading);
}

function addedItemMarkerKey(activeJob) {
  return `nutricity-added-${activeJob?.job?.group_key || "active"}`;
}

function checkoutMarkerKey(activeJob) {
  return `nutricity-checkout-${activeJob?.job?.group_key || "active"}`;
}

function markItemAdded(activeJob) {
  try {
    sessionStorage.setItem(addedItemMarkerKey(activeJob), String(Date.now()));
  } catch {
    // Session storage can be blocked on unusual browser profiles; state storage still carries the marker.
  }
}

function markCheckoutStarted(activeJob) {
  activeJob.checkoutStartedAt = Date.now();
  try {
    sessionStorage.setItem(checkoutMarkerKey(activeJob), String(activeJob.checkoutStartedAt));
  } catch {
    // State storage still carries the marker when session storage is unavailable.
  }
}

function itemWasAdded(activeJob) {
  if (activeJob?.addClickedAt || Object.keys(activeJob?.pricing || {}).length) return true;
  try {
    return Boolean(sessionStorage.getItem(addedItemMarkerKey(activeJob)));
  } catch {
    return false;
  }
}

function checkoutWasStarted(activeJob) {
  if (activeJob?.checkoutStartedAt || ["subscribe_checkout", "checkout", "editing_address", "complete_pending", "find_order_id"].includes(String(activeJob?.stage || ""))) return true;
  try {
    return Boolean(sessionStorage.getItem(checkoutMarkerKey(activeJob)));
  } catch {
    return false;
  }
}

function canClearCart(activeJob) {
  return (
    activeJob?.stage === "clear_cart" &&
    !activeJob.cartCleared &&
    !itemWasAdded(activeJob) &&
    !checkoutWasStarted(activeJob) &&
    Number(activeJob.itemIndex || 0) === 0
  );
}

function cartItemAsin(item) {
  const direct = String(item.getAttribute("data-asin") || "").toUpperCase();
  if (/^[A-Z0-9]{10}$/.test(direct)) return direct;
  const link = [...item.querySelectorAll("a[href]")].find((anchor) => /\/(?:dp|gp\/product)\/[A-Z0-9]{10}/i.test(anchor.href || anchor.getAttribute("href") || ""));
  const href = link?.href || link?.getAttribute("href") || "";
  const match = href.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
  if (match) return match[1].toUpperCase();
  const textMatch = (item.innerText || item.textContent || "").match(/\b([A-Z0-9]{10})\b/);
  return textMatch ? textMatch[1].toUpperCase() : "";
}

function expectedCartQuantities(activeJob) {
  const expected = {};
  const pricing = Object.values(activeJob.pricing || {});
  if (pricing.length) {
    for (const item of pricing) {
      const asin = String(item.purchased_asin || item.asin || "").toUpperCase();
      if (!asin) continue;
      expected[asin] = (expected[asin] || 0) + Number(item.quantity || 1);
    }
    return expected;
  }
  for (const item of activeJob.job?.items || []) {
    const asin = String(item.asin || "").toUpperCase();
    if (!asin) continue;
    expected[asin] = (expected[asin] || 0) + Number(item.quantity || 1);
  }
  return expected;
}

function smartWagonAddedCartState(activeJob, expected) {
  const bodyText = (document.body?.innerText || document.body?.textContent || "").replace(/\s+/g, " ");
  const lower = bodyText.toLowerCase();
  const onSmartWagon = /\/cart\/smart-wagon/i.test(location.pathname) || /[?&]ref_=sw_/i.test(location.href);
  const added = lower.includes("added to cart");
  const checkoutButton = findButtonByText(["proceed to checkout", "check out amazon cart"]);
  if (!added || (!onSmartWagon && !checkoutButton)) return null;

  const expectedTotal = Object.values(expected || {}).reduce((sum, quantity) => sum + Number(quantity || 0), 0);
  const buttonText = (checkoutButton?.value || checkoutButton?.title || checkoutButton?.innerText || checkoutButton?.textContent || "").replace(/\s+/g, " ");
  const countMatch =
    buttonText.match(/\((\d+)\s+items?\)/i) ||
    bodyText.match(/cart\s+subtotal\s*:\s*\$?[\d,.]+\s*\((\d+)\s+items?\)/i) ||
    bodyText.match(/subtotal\s*\((\d+)\s+items?\)/i);
  const cartCount = countMatch ? Number(countMatch[1]) : null;
  if (Number.isFinite(cartCount) && expectedTotal && cartCount < expectedTotal) {
    return {
      ok: false,
      message: `Amazon added-to-cart page shows ${cartCount} cart item(s), but expected ${expectedTotal}.`,
      mismatches: Object.entries(expected || {}).map(([asin, quantity]) => ({ asin, expected: Number(quantity), actual: 0 })),
    };
  }
  return {
    ok: true,
    warning: Number.isFinite(cartCount)
      ? `Amazon added-to-cart page shows ${cartCount} item(s). Proceeding to checkout.`
      : "Amazon added-to-cart page is visible. Proceeding to checkout.",
  };
}

function verifyCartQuantities(activeJob) {
  const activeCart = document.querySelector("#sc-active-cart");
  const expected = expectedCartQuantities(activeJob);
  if (!Object.keys(expected).length) return { ok: true };
  const items = cartActiveItems();
  if ((!activeCart || !visible(activeCart)) && !items.length) {
    const smartWagon = smartWagonAddedCartState(activeJob, expected);
    if (smartWagon) return smartWagon;
    if (cartIsVisiblyEmpty()) {
      const details = Object.entries(expected).map(([asin, quantity]) => ({ asin, expected: Number(quantity), actual: 0 }));
      return {
        ok: false,
        message: `Amazon cart is empty after Add to cart. ${details.map((item) => `${item.asin} expected ${item.expected}, cart has 0`).join("; ")}`,
        mismatches: details,
      };
    }
    return { ok: false, message: "Could not find Amazon active cart items after Add to cart.", mismatches: [] };
  }
  const actual = {};
  const unknownItems = [];
  for (const item of items) {
    const asin = cartItemAsin(item);
    if (!asin) {
      unknownItems.push((item.innerText || item.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120));
      continue;
    }
    if (!expected[asin]) continue;
    actual[asin] = (actual[asin] || 0) + cartItemQuantity(item);
  }
  if (!Object.keys(actual).length && items.length && unknownItems.length) {
    return { ok: true, warning: `Could not read ASIN from Amazon cart markup. Found ${items.length} active cart item(s), so checkout was not blocked.` };
  }
  const mismatches = Object.entries(expected).filter(([asin, quantity]) => Number(actual[asin] || 0) !== Number(quantity));
  if (!mismatches.length) return { ok: true };
  const details = mismatches.map(([asin, quantity]) => ({ asin, expected: Number(quantity), actual: Number(actual[asin] || 0) }));
  const message = mismatches
    .map(([asin, quantity]) => `${asin} expected ${quantity}, cart has ${actual[asin] || 0}`)
    .join("; ");
  return { ok: false, message, mismatches: details };
}

function lineIdForAsin(activeJob, asin) {
  const wanted = String(asin || "").toUpperCase();
  const item = (activeJob.job?.items || []).find((entry) => String(entry.asin || "").toUpperCase() === wanted);
  if (item) return itemPrimaryLineId(item);
  const pricingItem = Object.values(activeJob.pricing || {}).find((entry) => {
    const purchasedAsin = String(entry.purchased_asin || "").toUpperCase();
    const originalAsin = String(entry.asin || "").toUpperCase();
    return purchasedAsin === wanted || originalAsin === wanted;
  });
  if (!pricingItem?.asin) return null;
  const originalItem = (activeJob.job?.items || []).find((entry) => String(entry.asin || "").toUpperCase() === String(pricingItem.asin || "").toUpperCase());
  return originalItem ? itemPrimaryLineId(originalItem) : null;
}

function promotionNodes() {
  const roots = [
    ...document.querySelectorAll(
      ".promoPriceBlockMessage, [data-csa-c-owner='PromotionsDiscovery'], #promoPriceBlockMessage_feature_div, #couponFeature, [id*='coupon'][id*='Feature']",
    ),
  ].filter(visible);
  const nodes = roots.filter((root) => {
    const text = (root.innerText || root.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    if (!text || text.length > 600) return false;
    if (!/\b(coupon|promotion|promo|save)\b/i.test(text)) return false;
    const redeemed = [...root.querySelectorAll("[id^='doneButton'], .a-color-success")].some((node) => {
      const nodeText = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
      return visible(node) && nodeText.includes("redeemed");
    });
    if (redeemed) return false;
    const hasRedeem = [...root.querySelectorAll("span.a-button:not(.a-button-disabled), input.a-button-input[type='submit'], button")].some((candidate) => promoRedeemTarget(candidate));
    const hasCouponCheckbox = [...root.querySelectorAll("input[type='checkbox']:not(:checked), .a-checkbox:not(.aok-hidden) label, .a-icon-checkbox")]
      .some((candidate) => visible(candidate) || visible(candidate.closest?.("label, .a-checkbox, span, div")));
    return hasRedeem || hasCouponCheckbox;
  });
  return nodes.filter(visible).slice(0, 12);
}

function savingsRoots(context = "regular") {
  return context === "sns"
    ? [
        document.querySelector("#snsAccordionRowMiddle"),
        document.querySelector("#snsAccordionRow"),
        document.querySelector("#reinvent_price_desktop_snsAccordionRowMiddle"),
        document.querySelector("#promoPriceBlockMessage_feature_div"),
        document.body,
      ].filter(Boolean)
    : [
        document.querySelector("#reinvent_price_desktop_newAccordionRow"),
        document.querySelector("#promoPriceBlockMessage_feature_div"),
        document.body,
      ].filter(Boolean);
}

function promoRedeemTarget(candidate) {
  const button = candidate.closest?.("span.a-button") || candidate;
  if (button.classList?.contains("a-button-disabled") || button.closest?.(".aok-hidden")) return null;
  const text = (button.innerText || button.textContent || candidate.value || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (text !== "redeem") return null;
  const promoBlock = button.closest?.(".promoPriceBlockMessage, [data-csa-c-owner='PromotionsDiscovery'], #promoPriceBlockMessage_feature_div");
  if (!promoBlock) return null;
  const clickTarget = button.closest(".a-declarative") || candidate;
  return visible(clickTarget) || visible(button) ? clickTarget : null;
}

async function clickVisibleRedeemPromotions(context = "regular") {
  const clicked = new Set();
  let count = 0;
  for (const root of savingsRoots(context)) {
    const candidates = [
      ...root.querySelectorAll("span.a-button:not(.a-button-disabled), input.a-button-input[type='submit']"),
    ];
    for (const candidate of candidates) {
      const target = promoRedeemTarget(candidate);
      if (!target || clicked.has(target)) continue;
      target.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(350);
      target.click();
      clicked.add(target);
      count += 1;
      await waitForStableDom(700, 5000);
      await sleep(1300);
    }
  }
  if (count) {
    showPanel("Nutricity fulfilment", `Redeemed ${count} Amazon promotion${count === 1 ? "" : "s"}.`, null, null);
  }
  return count;
}

async function clipVisibleCoupons(context = "regular") {
  const roots = savingsRoots(context);
  const clicked = new Set();
  let count = 0;
  for (const root of roots) {
    const candidates = [
      ...root.querySelectorAll("input[type='checkbox']:not(:checked)"),
      ...root.querySelectorAll("[data-csa-c-action='clipPromotion'] input[type='checkbox']:not(:checked), [data-csa-c-owner='PromotionsDiscovery'] input[type='checkbox']:not(:checked)"),
      ...root.querySelectorAll(".a-checkbox:not(.aok-hidden) label, .a-icon-checkbox"),
    ].filter((element) => visible(element) || visible(element.closest?.("label, .a-checkbox, span, div")));
    for (const candidate of candidates) {
      const target = candidate.matches?.("input[type='checkbox']") ? candidate : candidate.closest?.("label") || candidate;
      if (clicked.has(target)) continue;
      const nearbyText = (target.closest?.(".promoPriceBlockMessage, [data-csa-c-owner='PromotionsDiscovery'], #promoPriceBlockMessage_feature_div")?.innerText || target.parentElement?.innerText || "").toLowerCase();
      if (!nearbyText.includes("coupon") && !nearbyText.includes("save")) continue;
      target.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(350);
      target.click();
      clicked.add(target);
      count += 1;
      await sleep(1200);
    }
  }
  if (count) {
    showPanel("Nutricity fulfilment", `Applied ${count} Amazon coupon${count === 1 ? "" : "s"}.`, null, null);
  }
  return count;
}

function unavailableMessage() {
  const allBuyingOptions = [...document.querySelectorAll(
    "a[href*='/gp/offer-listing/'], a[href*='/offer-listing/'], a[title='See All Buying Options'], a.a-button-text",
  )].find((element) => {
    const text = (element.innerText || element.textContent || element.getAttribute("title") || "").replace(/\s+/g, " ").trim().toLowerCase();
    return visible(element) && text.includes("see all buying options");
  });
  if (allBuyingOptions) {
    return "Amazon only shows See All Buying Options, so this ASIN is not directly available to add to cart.";
  }
  const roots = [
    ...document.querySelectorAll("#availability, #outOfStock, #availabilityInsideBuyBox_feature_div, #desktop_qualifiedBuyBox, #buybox, #centerCol"),
  ].filter(Boolean);
  for (const root of roots) {
    if (!visible(root) && root.id !== "centerCol") continue;
    const text = (root.innerText || root.textContent || "").replace(/\s+/g, " ").trim();
    const lowered = text.toLowerCase();
    if (
      lowered.includes("currently unavailable") ||
      lowered.includes("we don't know when or if this item will be back in stock") ||
      lowered.includes("we do not know when or if this item will be back in stock")
    ) {
      return text.match(/currently unavailable[^.]*\./i)?.[0] || "Currently unavailable. We do not know when or if this item will be back in stock.";
    }
  }
  return "";
}

function amazonProductPageErrorMessage() {
  const title = String(document.title || "").replace(/\s+/g, " ").trim();
  const bodyText = String(document.body?.innerText || document.body?.textContent || "").replace(/\s+/g, " ").trim();
  const loweredTitle = title.toLowerCase();
  const loweredBody = bodyText.toLowerCase();
  if (
    loweredTitle.includes("page not found") ||
    loweredTitle.includes("404") ||
    loweredBody.includes("sorry! we couldn't find that page") ||
    loweredBody.includes("sorry we couldn't find that page") ||
    loweredBody.includes("looking for something?") ||
    loweredBody.includes("the web address you entered is not a functioning page")
  ) {
    return "Amazon opened a 404 / product page not found page.";
  }
  if (
    loweredBody.includes("no results for") ||
    loweredBody.includes("did not match any products") ||
    loweredBody.includes("couldn't find a match")
  ) {
    return "Amazon could not find a product page for this ASIN.";
  }
  return "";
}

function removeMissingItemFromActiveJob(activeJob, item, purchaseItem = item) {
  if (!item) return activeJob.job?.items || [];
  const missingLineId = itemPrimaryLineId(item);
  const missingAsins = new Set([item?.asin, purchaseItem?.asin].filter(Boolean).map((asin) => String(asin).toUpperCase()));
  const currentIndex = Number(activeJob.itemIndex || 0);
  const remainingItems = (activeJob.job?.items || []).filter((entry) => {
    const lineId = itemPrimaryLineId(entry);
    if (missingLineId && lineId === missingLineId) return false;
    if (missingLineId) return true;
    return !missingAsins.has(String(entry.asin || "").toUpperCase());
  });
  activeJob.job.items = remainingItems;
  activeJob.job.line_ids = (activeJob.job.line_ids || []).filter((lineId) => !missingLineId || lineId !== missingLineId);
  if (activeJob.pricing) {
    for (const asin of missingAsins) delete activeJob.pricing[asin];
  }
  activeJob.itemIndex = currentIndex;
  return remainingItems;
}

async function continueAfterPartialMissing(activeJob, item, purchaseItem, message, failureCode = "unavailable", details = {}) {
  if (!item) return false;
  const lineId = itemPrimaryLineId(item);
  if (!lineId) return false;
  if (!await shouldFulfilAvailableMixedAsin(activeJob)) return false;
  showPanel("Sending line to Missing ASINs", message, null, null);
  const result = await send({
    type: "MARK_LINE_MISSING",
    message,
    missingAsin: item?.asin || purchaseItem?.asin || currentAsinFromUrl(),
    missingLineId: lineId,
    failureCode,
    requestedQuantity: details.requestedQuantity ?? null,
    fulfilledQuantity: details.fulfilledQuantity ?? null,
    availableQuantity: details.availableQuantity ?? null,
  });
  if (!result?.ok) return false;
  const remainingItems = removeMissingItemFromActiveJob(activeJob, item, purchaseItem);
  if (!remainingItems.length) {
    showPanel("Missing ASINs", `${message} ${result.message || "Order moved to Missing ASINs."}`, null, null);
    return true;
  }
  if (activeJob.itemIndex < remainingItems.length) {
    activeJob.stage = "product";
    await setActiveJob(activeJob);
    showPanel("Split fulfilment", `${message} ${result.message || ""} Continuing with remaining Amazon item(s).`, null, null);
    location.href = `https://www.amazon.com/dp/${remainingItems[activeJob.itemIndex].asin}`;
  } else {
    activeJob.stage = "cart";
    await setActiveJob(activeJob);
    showPanel("Split fulfilment", `${message} ${result.message || ""} Proceeding to checkout for remaining Amazon item(s).`, null, null);
    location.href = "https://www.amazon.com/cart?ref_=sw_gtc";
  }
  return true;
}

async function shouldFulfilAvailableMixedAsin(activeJob) {
  if ((activeJob.job?.items || []).length <= 1) return true;
  const state = await getExtensionState();
  return state.fulfilAvailableMixedAsin === true;
}

async function failCurrentItemAsMissing(activeJob, item, purchaseItem, message, failureCode = "unavailable", details = {}) {
  if (await continueAfterPartialMissing(activeJob, item, purchaseItem, message, failureCode, details)) return true;
  showPanel("Sending to Missing ASINs", message, null, null);
  const result = await send({
    type: "FAIL_JOB",
    message,
    missingAsin: item?.asin || purchaseItem?.asin || currentAsinFromUrl(),
    missingLineId: item ? itemPrimaryLineId(item) : null,
    failureCode,
    requestedQuantity: details.requestedQuantity ?? null,
    fulfilledQuantity: details.fulfilledQuantity ?? null,
    availableQuantity: details.availableQuantity ?? null,
  });
  if (result?.ok) {
    showPanel("Missing ASINs", `${message} ${result.message || "Order moved to Missing ASINs."}`, null, null);
    return true;
  }
  throw new Error(result?.message || "The app did not confirm the Missing ASIN report.");
}

async function applyAdditionalSavings(context = "regular") {
  const redeemed = await clickVisibleRedeemPromotions(context);
  const clipped = await clipVisibleCoupons(context);
  return redeemed + clipped;
}

function markPromotions() {
  const nodes = promotionNodes();
  nodes.forEach((node) => node.classList.add("nutricity-highlight"));
  return nodes.length;
}

async function applySubscribeAndSaveIfCheaper(quantity, activeJob = null) {
  await waitForElement(["#corePrice_feature_div .a-price", "#apex_desktop .a-price", "#snsAccordionRowMiddle, #snsAccordionRow, #snsAccordionRowContent, [data-csa-c-slot-id*='sns']"], 12000);
  const { regular: pagePrice, sns: snsPrice } = productPriceSnapshot();
  if (!pagePrice || !snsPrice || snsPrice >= pagePrice) {
    showPanel(
      "Subscribe & Save",
      `Using one-time purchase because Subscribe & Save was not cheaper or could not be read (${moneyText(snsPrice)} vs ${moneyText(pagePrice)}).`,
      null,
      null,
    );
    return false;
  }
  showPanel("Subscribe & Save", `Subscribe & Save is cheaper (${moneyText(snsPrice)} vs ${moneyText(pagePrice)}). Switching to subscription checkout.`, null, null);

  const activated = await activateSubscribeAndSaveOption();
  if (!activated) {
    const error = new Error("Subscribe & Save is cheaper, but Amazon did not activate the Subscribe & Save radio button. Fulfilment paused before touching regular Add to cart quantity.");
    error.failureCode = "";
    throw error;
  }
  const controlsReady = await waitUntil(snsQuantityControlVisible, 8000, 300);
  if (!controlsReady) {
    const error = new Error("Subscribe & Save is cheaper and selected, but Amazon did not show the Subscribe & Save quantity controls. Fulfilment paused before touching regular Add to cart quantity.");
    error.failureCode = "";
    throw error;
  }
  await applyAdditionalSavings("sns");
  const quantitySet = await setQuantity(quantity, "sns");
  if (!quantitySet) {
    const requestedQuantity = Math.max(1, Math.round(Number(quantity || 1)));
    const quantityIssue = window.__nutricityLastQuantityIssue || {};
    const availableQuantity = quantityIssue.availableQuantity || maxPredefinedQuantity("sns") || maxSelectableQuantity("sns");
    const error = new Error(
      availableQuantity > 0 && availableQuantity < requestedQuantity
        ? `Less Subscribe & Save quantity available. Customer ordered ${requestedQuantity}, Amazon only allows ${availableQuantity}. ${quantityIssue.message || ""}`.trim()
        : `Could not set Subscribe & Save quantity ${requestedQuantity}. ${quantityIssue.message || ""}`.trim(),
    );
    error.failureCode = "partial_quantity";
    error.requestedQuantity = requestedQuantity;
    error.fulfilledQuantity = availableQuantity > 0 && availableQuantity < requestedQuantity ? availableQuantity : null;
    error.availableQuantity = availableQuantity > 0 && availableQuantity < requestedQuantity ? availableQuantity : null;
    throw error;
  }
  await configureSubscribeAndSaveDelivery();
  const syncedQuantity = syncSubscribeAndSaveQuantity(quantity);
  if (!syncedQuantity) {
    const requestedQuantity = Math.max(1, Math.round(Number(quantity || 1)));
    const error = new Error(`Subscribe & Save quantity ${requestedQuantity} was visible, but Amazon's checkout form still had a different quantity. Fulfilment paused before checkout.`);
    error.failureCode = "partial_quantity";
    error.requestedQuantity = requestedQuantity;
    throw error;
  }
  const subscribeButton = document.querySelector("#rcx-subscribe-submit-button-announce, #rcx-subscribe-submit-button button, #rcx-subscribe-submit-button input, button[value='snsText']") || findButtonByText(["subscribe"]);
  if (subscribeButton) {
    if (activeJob) {
      activeJob.stage = "subscribe_checkout";
      activeJob.addClickedAt = Date.now();
      activeJob.subscribeAndSave = true;
      markCheckoutStarted(activeJob);
      markItemAdded(activeJob);
      await setActiveJob(activeJob);
    }
    await clickElement(subscribeButton, "Subscribe button");
    return true;
  }
  return false;
}

async function activateSubscribeAndSaveOption() {
  if (subscribeAndSaveIsActive()) return true;
  const target = findSubscribeAndSaveAccordionClickTarget();
  if (!target) return false;
  showPanel("Subscribe & Save", "Clicking the Subscribe & Save accordion row.", null, null);
  const clickTargets = [
    target.querySelector?.(".a-accordion-radio.a-icon-radio-inactive")?.closest?.("[data-action='a-accordion'][role='button'], .a-accordion-row[role='button'], .accordion-header[role='button']"),
    target.querySelector?.("[data-action='a-accordion'][role='button']"),
    target.querySelector?.(".a-accordion-row[role='button']"),
    target.querySelector?.(".accordion-header[role='button']"),
    target.matches?.("[data-action='a-accordion'][role='button'], .a-accordion-row[role='button'], .accordion-header[role='button']") ? target : null,
    target,
    target.querySelector?.("h5"),
  ].filter(Boolean);
  for (const clickTarget of [...new Set(clickTargets)]) {
    clickTarget.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(250);
    clickTarget.focus?.();
    dispatchAmazonClickSequence(clickTarget);
    clickTarget.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    clickTarget.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    clickTarget.dispatchEvent(new KeyboardEvent("keydown", { key: " ", code: "Space", bubbles: true, cancelable: true }));
    clickTarget.dispatchEvent(new KeyboardEvent("keyup", { key: " ", code: "Space", bubbles: true, cancelable: true }));
    dispatchClickAtElementCenter(clickTarget);
    await waitForStableDom(700, 5000);
    if (subscribeAndSaveIsActive()) return true;
  }
  return await waitUntil(subscribeAndSaveIsActive, 3000, 250);
}

function dispatchAmazonClickSequence(element) {
  const pointerEvent = typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
  element.dispatchEvent(new pointerEvent("pointerdown", { bubbles: true, cancelable: true, pointerType: "mouse", view: window }));
  element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
  element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
  element.dispatchEvent(new pointerEvent("pointerup", { bubbles: true, cancelable: true, pointerType: "mouse", view: window }));
  element.click();
}

function dispatchClickAtElementCenter(element) {
  const rect = element?.getBoundingClientRect?.();
  if (!rect?.width || !rect?.height) return false;
  const x = rect.left + Math.min(Math.max(12, rect.width * 0.08), rect.width / 2);
  const y = rect.top + rect.height / 2;
  const target = document.elementFromPoint(x, y) || element;
  dispatchAmazonClickSequence(target);
  return true;
}

function subscribeAndSaveIsActive() {
  return subscribeAndSaveAccordionIsActive();
}

function subscribeAndSaveAccordionIsActive() {
  return Boolean(
    document.querySelector("#snsAccordionRowMiddle .a-accordion-radio-active, #snsAccordionRow .a-accordion-radio-active, #snsAccordionRowContent .a-accordion-radio-active, [data-csa-c-slot-id*='sns'] .a-accordion-radio-active, [data-a-accordion-row-name*='sns'] .a-accordion-radio-active, [data-csa-c-buying-option-type='SNS'] .a-accordion-radio-active") ||
    document.querySelector("#snsAccordionRowMiddle [data-action='a-accordion'][aria-expanded='true'], #snsAccordionRow [data-action='a-accordion'][aria-expanded='true'], #snsAccordionRowContent [data-action='a-accordion'][aria-expanded='true'], [data-csa-c-slot-id*='sns'][data-action='a-accordion'][aria-expanded='true'], [data-a-accordion-row-name*='sns'] [data-action='a-accordion'][aria-expanded='true']") ||
    [...document.querySelectorAll(subscribeAndSaveRootSelector())].some((root) => root.querySelector?.("[role='radio'][aria-checked='true']") || visible(root.querySelector?.("#rcx-subscribe-submit-button, #rcx-subscribe-submit-button-announce, input#rcxsubsQuan"))),
  );
}

function findSubscribeAndSaveAccordionClickTarget() {
  const direct = document.querySelector("#snsAccordionRowMiddle [data-action='a-accordion'][role='button']")
    || document.querySelector("#snsAccordionRowMiddle .a-accordion-row[role='button']")
    || document.querySelector("#snsAccordionRowMiddle")
    || document.querySelector("#snsAccordionRow [data-action='a-accordion'][role='button']")
    || document.querySelector("#snsAccordionRow")
    || document.querySelector("#snsAccordionRowContent [data-action='a-accordion'][role='button']")
    || document.querySelector("#snsAccordionRowContent")
    || document.querySelector("[data-a-accordion-row-name='snsAccordionRowMiddle'] [data-action='a-accordion'][role='button']")
    || document.querySelector("[data-a-accordion-row-name='snsAccordionRowMiddle']")
    || document.querySelector("[data-csa-c-slot-id='snsAccordionRowMiddle'][data-action='a-accordion'][role='button']")
    || document.querySelector("[data-csa-c-slot-id='snsAccordionRowMiddle']")?.closest(".a-accordion-row[role='button'], .a-box, [data-a-accordion-row-name]")
    || findSubscribeAndSaveRadio();
  if (direct) return direct;

  const rows = [
    ...document.querySelectorAll("[data-csa-c-buying-option-type='SNS'], [data-a-accordion-row-name*='sns'], [data-csa-c-slot-id*='sns'], .a-accordion-row, .accordion-header"),
  ].filter((row, index, all) => all.indexOf(row) === index && visible(row));
  for (const row of rows) {
    const text = (row.innerText || row.textContent || "").replace(/\s+/g, " ").toLowerCase();
    const idData = `${row.id || ""} ${row.getAttribute("data-a-accordion-row-name") || ""} ${row.getAttribute("data-csa-c-slot-id") || ""} ${row.getAttribute("data-csa-c-buying-option-type") || ""}`.toLowerCase();
    if (!text.includes("subscribe") && !idData.includes("sns")) continue;
    const header = row.closest?.("[data-a-accordion-row-name]")?.querySelector?.("[data-action='a-accordion'][role='button'], .a-accordion-row[role='button'], .accordion-header[role='button']")
      || row.querySelector?.("[data-action='a-accordion'][role='button'], .a-accordion-row[role='button'], .accordion-header[role='button']")
      || row.closest?.("[data-action='a-accordion'][role='button'], .a-accordion-row[role='button'], .accordion-header[role='button']")
      || row.closest?.("[data-a-accordion-row-name], .a-box")
      || row;
    if (header && visible(header)) return header;
  }
  return null;
}

function findSubscribeAndSaveRadio(root = null) {
  const direct = [
    "#snsAccordionRowMiddle .a-accordion-row",
    "#snsAccordionRow .a-accordion-row",
    "#snsAccordionRowContent .a-accordion-row",
    "[data-csa-c-slot-id='snsAccordionRowMiddle'][role='button']",
    "[data-a-accordion-row-name='snsAccordionRowMiddle'] .a-accordion-row",
  ]
    .flatMap((selector) => [...document.querySelectorAll(selector)])
    .find((item) => item.querySelector(".a-accordion-radio.a-icon-radio-inactive") || /subscribe\s*&\s*save/i.test(item.innerText || item.textContent || ""));
  if (direct) return direct;
  const roots = root ? [root] : [...document.querySelectorAll(subscribeAndSaveRootSelector())];
  for (const item of roots) {
    if (!item) continue;
    const text = (item.innerText || item.textContent || "").replace(/\s+/g, " ").toLowerCase();
    if (!text.includes("subscribe") && !/sns/i.test(item.id || "") && !/sns/i.test(item.getAttribute("data-csa-c-slot-id") || "")) continue;
    const inactive = item.querySelector(".a-accordion-radio.a-icon-radio-inactive, [role='radio'][aria-checked='false'], input[type='radio']:not(:checked)");
    if (inactive) return inactive.closest("[role='button'], .a-accordion-row, label") || inactive;
    const header = item.matches("[role='button'], .a-accordion-row") ? item : item.closest?.("[role='button'], .a-accordion-row");
    if (header && !header.querySelector(".a-accordion-radio-active")) return header;
  }
  return document.querySelector(".a-accordion-row[data-csa-c-slot-id*='sns'] .a-accordion-radio.a-icon-radio-inactive")?.closest("[role='button'], .a-accordion-row") || null;
}

async function configureSubscribeAndSaveDelivery() {
  showPanel("Nutricity fulfilment", "Checking Subscribe & Save delivery preferences.", null, null);
  await chooseSubscribeSoonerDelivery();
  await chooseSubscribeFrequencySixMonths();
}

async function chooseSubscribeSoonerDelivery() {
  const changeDateLink = findVisibleTextTarget(["change first delivery date"]);
  if (!changeDateLink) return false;
  await clickElement(changeDateLink, "Change first delivery date");
  const soonerOption = await waitUntil(() => (
    document.querySelector("#onmlDeliveryOpt") ||
    findVisibleTextTarget(["get it sooner"], "#snsDeliveryDateBottomSheet label, .a-popover-inner label, .a-popover-inner span, .a-popover-inner div")
  ), 7000);
  if (!soonerOption) return false;
  const soonerTarget = soonerOption.closest?.("label") || soonerOption;
  await clickElement(soonerTarget, "Get it sooner delivery option");
  const selectDateButton = await waitUntil(() => (
    findVisibleTextTarget(["select date"], "#snsDeliveryDateBottomSheet input, #snsDeliveryDateBottomSheet button, #snsDeliveryDateBottomSheet span.a-button, #snsDeliveryDateBottomSheet span.a-button-text, .a-popover-inner input, .a-popover-inner button, .a-popover-inner span.a-button, .a-popover-inner span.a-button-text")
  ), 5000);
  if (selectDateButton) {
    const buttonTarget = selectDateButton.closest?.("span.a-button, button") || selectDateButton;
    await clickElement(buttonTarget, "Select Subscribe & Save delivery date");
  }
  await waitForStableDom(700, 5000);
  return true;
}

async function chooseSubscribeFrequencySixMonths() {
  showPanel("Subscribe & Save", "Opening delivery every dropdown.", null, null);
  const nativeFrequency = [...document.querySelectorAll("#snsAccordionRowMiddle select, #snsAccordionRow select, #snsAccordionRowContent select, #reinvent_price_desktop_snsAccordionRowMiddle select")]
    .find((select) => [...select.options || []].some((option) => /\b(weeks?|months?)\b/i.test(option.textContent || "") || /\d+[WM]\|sns/i.test(String(option.value || ""))));
  const nativeContainerButton = nativeFrequency?.closest?.(".a-dropdown-container")?.querySelector?.(".a-button-dropdown, [data-action='a-dropdown-button']");
  const explicitButton = document.querySelector("#rcxOrdFreqSns, #rcxOrdFreqSns-announce")?.closest?.("[data-action='a-dropdown-button'], .a-button-dropdown, span.a-button");
  const frequencyButton = findSubscribeFrequencyDropdownButton();
  const dropdownButton = explicitButton || nativeContainerButton || frequencyButton;
  if (!dropdownButton || !visible(dropdownButton)) return selectNativeSubscribeFrequency(nativeFrequency);
  await clickElement(dropdownButton, "Subscribe & Save delivery schedule dropdown");
  const frequencyOption = await waitUntil(findLastSubscribeFrequencyOption, 5000);
  if (!frequencyOption) return selectNativeSubscribeFrequency(nativeFrequency);
  const selectedText = (frequencyOption.textContent || "").replace(/\s+/g, " ").trim();
  showPanel("Subscribe & Save", `Selecting delivery every ${selectedText}.`, null, null);
  await clickElement(frequencyOption, `Subscribe & Save ${selectedText} schedule`);
  await waitForStableDom(700, 5000);
  return true;
}

async function selectNativeSubscribeFrequency(select) {
  if (!select?.options?.length) return false;
  const options = [...select.options].filter((option) => /sns/i.test(String(option.value || "")) || /\b(weeks?|months?)\b/i.test(option.textContent || ""));
  const target = options.at(-1);
  if (!target) return false;
  const selectedText = (target.textContent || "").replace(/\s+/g, " ").trim();
  showPanel("Subscribe & Save", `Selecting delivery every ${selectedText}.`, null, null);
  select.value = target.value;
  select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  select.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  await waitForStableDom(700, 5000);
  return true;
}

function findSubscribeFrequencyDropdownButton() {
  const roots = [
    document.querySelector("#snsAccordionRowMiddle"),
    document.querySelector("#snsAccordionRow"),
    document.querySelector("#snsAccordionRowContent"),
    document.querySelector("#reinvent_price_desktop_snsAccordionRowMiddle"),
  ].filter(Boolean);
  const candidates = [
    ...roots.flatMap((root) => [
      ...root.querySelectorAll("[data-action='a-dropdown-button'], .a-button-dropdown, span.a-button"),
    ]),
    ...document.querySelectorAll("[id$='-announce'], span.a-dropdown-prompt"),
  ];
  return candidates.find((element) => {
    const text = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    const inSns = roots.some((root) => root.contains(element));
    const looksLikeFrequency = /deliver(?:y)?\s*every/.test(text) || /\b\d+\s*(weeks?|months?)\b/.test(text);
    return visible(element) && (inSns || /rcxordfreqsns/i.test(element.id || "")) && looksLikeFrequency;
  })?.closest?.("[data-action='a-dropdown-button'], .a-button-dropdown, span.a-button") || null;
}

function findLastSubscribeFrequencyOption() {
  const popovers = [...document.querySelectorAll(".a-popover-wrapper, .a-popover-inner")]
    .filter((popover) => visible(popover) && /\b(weeks?|months?)\b/i.test(popover.innerText || popover.textContent || ""));
  for (const popover of popovers) {
    const scroller = popover.querySelector(".a-popover-inner") || popover;
    scroller.scrollTop = scroller.scrollHeight;
  }
  const options = popovers
    .flatMap((popover) => [...popover.querySelectorAll("a.a-dropdown-link, a[role='option']")])
    .filter((link, index, all) => {
      const text = (link.textContent || "").replace(/\s+/g, " ").trim();
      const value = link.getAttribute("data-value") || "";
      return all.indexOf(link) === index && visible(link) && (/\b\d+\s*(weeks?|months?)\b/i.test(text) || /\d+[WM]\|sns/i.test(value));
    });
  return options.at(-1) || null;
}

function quantitySelects(context = "regular") {
  const selects = [...document.querySelectorAll("select")].filter((select) => {
    const id = select.id || "";
    if (context === "sns") {
      return (
        /sns/i.test(id) && id.includes("predefinedQuantitiesDropdown") ||
        Boolean(select.closest(subscribeAndSaveRootSelector()))
      );
    }
    return (
      id === "quantity" ||
      id.includes("predefinedQuantitiesDropdown") && !/^sns/i.test(id) ||
      select.name === "quantity"
    );
  });
  return selects;
}

function maxSelectableQuantity(context = "regular") {
  const quantities = [];
  for (const select of quantitySelects(context)) {
    for (const option of [...select.options || []]) {
      const text = clean(option.textContent || option.value);
      if (/10\+/.test(text)) {
        quantities.push(10);
        continue;
      }
      const numeric = Number((option.value || text).match(/\d+/)?.[0] || 0);
      if (numeric > 0) quantities.push(numeric);
    }
  }
  return quantities.length ? Math.max(...quantities) : 0;
}

function maxPredefinedQuantity(context = "regular") {
  const quantities = [];
  const selectors = context === "sns"
    ? ["select[id^='sns'][id*='predefinedQuantitiesDropdown']"]
    : ["select[id*='new_buyingOption'][id*='predefinedQuantitiesDropdown']", "select[id*='DesktopFfqp'][id*='predefinedQuantitiesDropdown']:not([id^='sns'])"];
  for (const selector of selectors) {
    for (const select of document.querySelectorAll(selector)) {
      for (const option of [...select.options || []]) {
        const numeric = Number((option.value || option.textContent || "").match(/\d+/)?.[0] || 0);
        if (numeric > 0) quantities.push(numeric);
      }
    }
  }
  return quantities.length ? Math.max(...quantities) : 0;
}

function quantityFreeFormInput(select, context = "regular") {
  const id = select?.id || "";
  const candidates = [];
  if (id.includes("predefinedQuantitiesDropdown")) {
    candidates.push(`#${CSS.escape(id.replace("predefinedQuantitiesDropdown", "freeQuantityTextInput"))}`);
    candidates.push(`#${CSS.escape(id.replace("predefinedQuantitiesDropdown", "quantityTextInput"))}`);
  }
  if (context === "sns") {
    candidates.push(
      "input[id*='sns'][id$='freeQuantityTextInput']",
      "input[id*='sns'][id$='quantityTextInput']",
      "input[id^='sns'][id$='freeQuantityTextInput']",
      "input[id^='sns'][id$='quantityTextInput']",
      "#snsAccordionRowMiddle input.freeQuantityTextInput",
      "#snsAccordionRowMiddle input.quantity-text-input-with-label",
      "#snsAccordionRow input.freeQuantityTextInput",
      "#snsAccordionRow input.quantity-text-input-with-label",
    );
  } else {
    candidates.push(
      "input[id*='new_buyingOption'][id$='freeQuantityTextInput']",
      "input[id*='new_buyingOption'][id$='quantityTextInput']",
      "input.freeQuantityTextInput:not([id^='sns'])",
      "input.quantity-text-input-with-label:not([id^='sns'])",
      "input#quantity",
    );
  }
  for (const selector of candidates) {
    const input = document.querySelector(selector);
    if (input) return input;
  }
  if (context === "sns") {
    for (const root of document.querySelectorAll(subscribeAndSaveRootSelector())) {
      const input = root.querySelector("input.freeQuantityTextInput, input.quantity-text-input-with-label, input[id$='quantityTextInput'], input[id$='freeQuantityTextInput']");
      if (input) return input;
    }
  }
  return null;
}

function quantityUpdateButton(select, context = "regular") {
  const id = select?.id || "";
  const candidates = [];
  if (id.includes("predefinedQuantitiesDropdown")) {
    candidates.push(`#${CSS.escape(id.replace("predefinedQuantitiesDropdown", "updateButton"))}`);
  }
  if (id.includes("quantityTextInput")) {
    candidates.push(`#${CSS.escape(id.replace("quantityTextInput", "updateButton"))}`);
  }
  if (id.includes("freeQuantityTextInput")) {
    candidates.push(`#${CSS.escape(id.replace("freeQuantityTextInput", "updateButton"))}`);
  }
  if (context === "sns") {
    candidates.push("#snsQuantity_feature_div [id$='-updateButton']", "#snsAccordionRowMiddle [id$='-updateButton']", "#snsAccordionRow [id$='-updateButton']");
  } else {
    candidates.push("[id*='new_buyingOption'][id$='-updateButton']", "#qualifiedBuybox [id$='-updateButton']", "#desktop_qualifiedBuyBox [id$='-updateButton']");
  }
  for (const selector of candidates) {
    const button = document.querySelector(`${selector} button, ${selector} input, ${selector}`);
    if (button && visible(button)) return button;
  }
  return null;
}

function quantityTextInputs(context = "regular") {
  const selectors = context === "sns"
    ? [
        "input[id*='sns'][id$='quantityTextInput']",
        "input[id*='sns'][id$='freeQuantityTextInput']",
        "input[id^='sns'][id$='quantityTextInput']",
        "input[id^='sns'][id$='freeQuantityTextInput']",
        "#snsAccordionRowMiddle input.quantity-text-input-with-label",
        "#snsAccordionRowMiddle input.freeQuantityTextInput",
      ]
    : [
        "input#quantity",
        "input[name='quantity']",
        "input[id*='new_buyingOption'][id$='quantityTextInput']",
        "input[id*='new_buyingOption'][id$='freeQuantityTextInput']",
        "input.quantity-text-input-with-label:not([id^='sns'])",
        "input.freeQuantityTextInput:not([id^='sns'])",
      ];
  const inputs = selectors.flatMap((selector) => [...document.querySelectorAll(selector)]);
  if (context === "sns") {
    for (const root of document.querySelectorAll(subscribeAndSaveRootSelector())) {
      inputs.push(...root.querySelectorAll("input.quantity-text-input-with-label, input.freeQuantityTextInput, input[id$='quantityTextInput'], input[id$='freeQuantityTextInput']"));
    }
  }
  return inputs.filter((input, index, all) => (
    all.indexOf(input) === index && visible(input)
  ));
}

function regularBuyboxQuantityControls() {
  const controls = [
    ...document.querySelectorAll(
      [
        "#addToCart select#quantity",
        "#addToCart input#quantity",
        "#addToCart input[name='quantity']",
        "#buybox select#quantity",
        "#buybox input#quantity",
        "#buybox input[name='quantity']",
        "#desktop_buybox select#quantity",
        "#desktop_buybox input#quantity",
        "#desktop_buybox input[name='quantity']",
        "select#quantity",
        "input#quantity",
        "input[name='quantity']",
      ].join(", "),
    ),
  ];
  return controls.filter((control, index, all) => (
    all.indexOf(control) === index &&
    !control.closest(subscribeAndSaveRootSelector()) &&
    String(control.name || control.id || "").toLowerCase() === "quantity"
  ));
}

function setQuantityControlValue(control, qty) {
  if (!control) return false;
  const requested = Math.max(1, Math.round(Number(qty) || 1));
  if (control.tagName === "SELECT") {
    const option = [...control.options || []].find((item) => String(item.value) === String(requested) || Number(item.value) === requested);
    if (!option) return false;
    control.value = option.value;
  } else {
    control.value = String(requested);
    control.setAttribute("value", String(requested));
  }
  control.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  control.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  return true;
}

function syncRegularQuantity(qty = 1) {
  const requested = Math.max(1, Math.round(Number(qty) || 1));
  const controls = [
    ...regularBuyboxQuantityControls(),
    ...quantitySelects("regular"),
    ...quantityTextInputs("regular"),
  ].filter((control, index, all) => all.indexOf(control) === index);
  let synced = false;
  for (const control of controls) {
    synced = setQuantityControlValue(control, requested) || synced;
  }
  return synced || requested === 1;
}

function quantityValueAccepted(context = "regular", qty = 1) {
  const requested = Math.max(1, Math.round(Number(qty) || 1));
  if (context !== "sns") {
    const buyboxControls = regularBuyboxQuantityControls();
    if (buyboxControls.length) {
      return buyboxControls.some((control) => {
        const value = Number(String(control.value || "").replace(/[^\d.]/g, ""));
        return Number.isFinite(value) && value === requested;
      });
    }
  }
  const roots = context === "sns"
    ? [...document.querySelectorAll(subscribeAndSaveRootSelector())]
    : [document];
  const controls = roots.flatMap((root) => [
    ...root.querySelectorAll("select[id*='predefinedQuantitiesDropdown'], select#quantity, select[name='quantity'], input#rcxsubsQuan, input[id$='quantityTextInput'], input[id$='freeQuantityTextInput'], input#quantity"),
  ]).filter((control) => context === "sns" || !control.closest(subscribeAndSaveRootSelector()));
  const accepted = controls.some((control) => {
    const value = Number(String(control.value || "").replace(/[^\d.]/g, ""));
    return Number.isFinite(value) && value === requested;
  });
  if (!accepted) return false;
  if (context !== "sns") return true;
  const subscribeButton = document.querySelector("#rcx-subscribe-submit-button-announce, #rcx-subscribe-submit-button button, #rcx-subscribe-submit-button input, button[value='snsText']");
  return Boolean(subscribeButton && visible(subscribeButton) && !subscribeButton.disabled);
}

function syncSubscribeAndSaveQuantity(qty = 1) {
  const requested = Math.max(1, Math.round(Number(qty) || 1));
  const roots = [
    ...document.querySelectorAll("#snsAccordionRowMiddle, #snsAccordionRow, #snsAccordionRowContent, #reinvent_price_desktop_snsAccordionRowMiddle, #snsQuantity_feature_div"),
  ].filter((root, index, all) => root && all.indexOf(root) === index);
  const scopedRoots = roots.length ? roots : [document];
  const controls = scopedRoots.flatMap((root) => [
    ...root.querySelectorAll("input#rcxsubsQuan, form input[name='quantity'], select[id*='sns'][id*='predefinedQuantitiesDropdown'], input[id*='sns'][id$='quantityTextInput'], input[id*='sns'][id$='freeQuantityTextInput']"),
  ]).filter((control, index, all) => all.indexOf(control) === index);

  for (const control of controls) {
    if (control.tagName === "SELECT") {
      const option = [...control.options || []].find((item) => String(item.value) === String(requested) || Number(item.value) === requested);
      if (!option) continue;
      control.value = option.value;
    } else {
      control.value = String(requested);
      control.setAttribute("value", String(requested));
    }
    control.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    control.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }

  const hiddenQuantityControls = controls.filter((control) => {
    const type = String(control.type || "").toLowerCase();
    return type === "hidden" || control.id === "rcxsubsQuan" || control.name === "quantity";
  });
  const requiredControls = hiddenQuantityControls.length ? hiddenQuantityControls : controls;
  const synced = requiredControls.some((control) => Number(String(control.value || "").replace(/[^\d.]/g, "")) === requested);
  if (synced && requested > 1) {
    showPanel("Nutricity fulfilment", `Synced Subscribe & Save checkout quantity to ${requested}.`, null, null);
  }
  return synced || requested === 1;
}

async function clickQuantityUpdateButton(select, context = "regular") {
  const button = await waitUntil(() => quantityUpdateButton(select, context), 2500, 250);
  if (!button) return false;
  await clickElement(button, `${context === "sns" ? "Subscribe & Save " : ""}quantity update`);
  await waitForStableDom(500, 4000);
  return true;
}

function quantityAvailabilityIssue(context = "regular", requestedQuantity = 1) {
  const roots = context === "sns"
    ? [
        ...document.querySelectorAll("#snsQuantity_feature_div, #snsAccordionRowMiddle, #snsAccordionRow, #snsAccordionRowContent, [id^='snsABDesktopFfqp_'][id$='-limitedAvailabilityMessage']"),
      ]
    : [
        ...document.querySelectorAll("#qualifiedBuybox, #desktop_qualifiedBuyBox, #buybox, #centerCol, #splitoffer_detailpage_buybox_section, [id*='DesktopFfqp_'][id$='-limitedAvailabilityMessage']:not([id^='sns'])"),
      ];
  const text = roots
    .map((root) => (root.innerText || root.textContent || "").replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
  const lowered = text.toLowerCase();
  const hasSingleSellerSplitOffer = lowered.includes("quantity unavailable from a single seller") || lowered.includes("buy from multiple sellers");
  const hasSpecificInventoryLimit = (
    lowered.includes("limited availability at this quantity") ||
    lowered.includes("limited availability") ||
    lowered.includes("not enough inventory") ||
    lowered.includes("not enough available") ||
    lowered.includes("maximum quantity") ||
    lowered.includes("seller does not have") ||
    lowered.includes("seller doesn't have") ||
    lowered.includes("only") && lowered.includes("available")
  );
  if (context === "sns" && hasSingleSellerSplitOffer && !hasSpecificInventoryLimit) {
    return null;
  }
  const hasIssue = (
    hasSpecificInventoryLimit ||
    hasSingleSellerSplitOffer
  );
  const splitOffer = context !== "sns" && document.querySelector("#splitoffer_detailpage_buybox_link[href*='quantity=']");
  if (!hasIssue && !splitOffer) return null;

  const requested = Math.max(1, Math.round(Number(requestedQuantity || 1)));
  const textQuantity =
    Number(lowered.match(/only\s+(\d+)\s+(?:left|available|in stock)/)?.[1] || 0) ||
    Number(lowered.match(/maximum(?: order)? quantity(?: is)?\s+(\d+)/)?.[1] || 0);
  const predefinedQuantity = maxPredefinedQuantity(context);
  const availableQuantity = textQuantity || (predefinedQuantity > 0 && predefinedQuantity < requested ? predefinedQuantity : 0);
  return {
    message: text || (context === "sns" ? "Limited availability at this Subscribe & Save quantity." : "Quantity unavailable from a single seller."),
    requestedQuantity: requested,
    availableQuantity: availableQuantity || null,
    fulfilledQuantity: availableQuantity || null,
  };
}

function partialQuantityMessage(asin, requestedQuantity, availableQuantity, issueMessage = "", context = "regular") {
  const prefix = context === "sns" ? "Less Subscribe & Save quantity available" : "Less quantity available";
  const availableText = availableQuantity
    ? `Amazon only allows ${availableQuantity}`
    : "Amazon showed limited availability";
  return `${prefix} for ASIN ${asin}. Customer ordered ${requestedQuantity}, ${availableText}.${issueMessage ? ` ${issueMessage}` : ""}`.trim();
}

async function pauseAfterMissingAsinReportFailure(activeJob, message) {
  activeJob.pausedStage = activeJob.stage || "product";
  activeJob.paused = true;
  await setActiveJob(activeJob);
  showPanel(
    "Missing ASIN report failed",
    `${message} The order is paused so it does not stay locked silently.`,
    "I did it manually, continue",
    () => continueAfterManualStep(activeJob),
  );
}

async function reportMissingQuantityIssue(activeJob, item, purchaseItem, quantityIssue = {}) {
  const requestedQuantity = Math.max(1, Math.round(Number(purchaseItem?.quantity || item?.quantity || quantityIssue.requestedQuantity || 1)));
  const availableQuantity = quantityIssue.availableQuantity || quantityIssue.fulfilledQuantity || maxPredefinedQuantity(quantityIssue.context || "regular") || maxSelectableQuantity(quantityIssue.context || "regular") || null;
  const message = partialQuantityMessage(purchaseItem?.asin || item?.asin || "", requestedQuantity, availableQuantity, quantityIssue.message || "", quantityIssue.context || "regular");
  showPanel("Sending to Missing ASINs", message, null, null);
  const result = await send({
    type: "FAIL_JOB",
    message,
    missingAsin: item?.asin || purchaseItem?.asin || "",
    missingLineId: item ? itemPrimaryLineId(item) : null,
    failureCode: "partial_quantity",
    requestedQuantity,
    fulfilledQuantity: availableQuantity,
    availableQuantity,
  });
  if (result?.ok) {
    showPanel("Missing ASINs", `${message} ${result.message || "Quantity issue moved to Missing ASINs."}`, null, null);
    return true;
  }
  throw new Error(result?.message || "Could not move quantity issue to Missing ASINs.");
}

async function chooseAmazonDropdownOption(select, qty) {
  return chooseAmazonDropdownText(select, qty > 9 ? "10+" : String(qty));
}

async function chooseAmazonDropdownText(select, optionText) {
  const container = select.closest(".a-dropdown-container") || select.parentElement;
  const dropdownButton = container?.querySelector(".a-button-dropdown, [data-action='a-dropdown-button']");
  if (!dropdownButton || !visible(dropdownButton)) return false;
  dropdownButton.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(350);
  dropdownButton.click();
  await sleep(700);
  const wanted = String(optionText || "").replace(/\s+/g, " ").trim();
  const links = [...document.querySelectorAll(".a-popover-wrapper a.a-dropdown-link, .a-popover-inner a.a-dropdown-link, a[role='option']")].filter(visible);
  const option = links.find((link) => (link.textContent || "").replace(/\s+/g, " ").trim() === wanted);
  if (!option) return false;
  option.scrollIntoView({ block: "nearest" });
  await sleep(250);
  option.click();
  await sleep(900);
  return true;
}

async function selectFreeFormQuantityOption(select, qty) {
  const thresholds = qty > 9 ? ["10+", "4+"] : ["4+", "10+"];
  const option = [...select.options || []].find((item) => {
    const text = (item.textContent || item.value || "").replace(/\s+/g, " ").trim();
    return thresholds.includes(text) || item.value === "";
  });
  if (!option) return false;
  const text = (option.textContent || option.value || "").replace(/\s+/g, " ").trim();
  const clicked = await chooseAmazonDropdownText(select, text || thresholds[0]);
  if (clicked) return true;
  select.value = option.value;
  select.dispatchEvent(new Event("input", { bubbles: true }));
  select.dispatchEvent(new Event("change", { bubbles: true }));
  await sleep(900);
  return true;
}

async function setNativeSelectQuantity(select, qty) {
  if (!select) return false;
  const wantedValue = qty > 9 ? "" : String(qty);
  const option = [...select.options].find((item) => String(item.value) === wantedValue || Number(item.value) === qty);
  if (!option) return false;
  select.value = option.value;
  select.dispatchEvent(new Event("input", { bubbles: true }));
  select.dispatchEvent(new Event("change", { bubbles: true }));
  await sleep(1000);
  return true;
}

async function setFreeFormQuantity(select, qty, context = "regular") {
  const input = quantityFreeFormInput(select, context);
  if (!input) return false;
  await selectFreeFormQuantityOption(select, qty);
  await sleep(500);
  input.classList.remove("aok-hidden");
  input.removeAttribute("aria-hidden");
  input.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(350);
  input.focus();
  input.select?.();
  input.value = String(qty);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.blur();
  await sleep(1000);
  const updated = await clickQuantityUpdateButton(select, context);
  await sleep(updated ? 1300 : 700);
  const value = Number(String(input.value || "").replace(/[^\d.]/g, ""));
  return Number.isFinite(value) && value === qty;
}

async function setDirectQuantityInput(input, qty, context = "regular") {
  if (!input) return false;
  showPanel("Nutricity fulfilment", `Typing ${context === "sns" ? "Subscribe & Save " : ""}quantity ${qty}.`, null, null);
  input.classList.remove("aok-hidden");
  input.removeAttribute("aria-hidden");
  input.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(350);
  await setInputValue(input, String(qty));
  input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
  input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  input.blur();
  await sleep(800);
  const updated = await clickQuantityUpdateButton(input, context);
  await sleep(updated ? 1300 : 700);
  const value = Number(String(input.value || "").replace(/[^\d.]/g, ""));
  return Number.isFinite(value) && value === qty;
}

async function setQuantity(quantity, context = "regular") {
  const quantitySelectors = context === "sns"
    ? [
        "#snsAccordionRowMiddle select[id*='sns'][id*='predefinedQuantitiesDropdown']",
        "#snsAccordionRow select[id*='sns'][id*='predefinedQuantitiesDropdown']",
        "#snsQuantity_feature_div select[id*='sns'][id*='predefinedQuantitiesDropdown']",
        "#snsAccordionRowMiddle input#rcxsubsQuan",
        "#snsAccordionRow input#rcxsubsQuan",
        "#rcx-subscribe-submit-button",
      ]
    : ["select#quantity", "select[name='quantity']", "select[id*='predefinedQuantitiesDropdown']", "input[id$='quantityTextInput']", ".quantity-text-input-with-label", "#add-to-cart-button"];
  await waitForElement(quantitySelectors, 12000);
  const qty = Math.max(1, Math.round(Number(quantity) || 1));
  window.__nutricityLastQuantityIssue = null;
  if (context === "sns" && !subscribeAndSaveAccordionIsActive()) {
    const error = new Error("Subscribe & Save quantity was requested before the Subscribe & Save row became active.");
    error.failureCode = "";
    throw error;
  }
  if (qty === 1) return true;

  const selects = quantitySelects(context);
  for (const select of selects) {
    showPanel("Nutricity fulfilment", `Setting ${context === "sns" ? "Subscribe & Save " : ""}quantity to ${qty}.`, null, null);
    const freeFormInput = quantityFreeFormInput(select, context);
    const freeFormSet = freeFormInput ? await setFreeFormQuantity(select, qty, context) : false;
    const selected = freeFormSet || await chooseAmazonDropdownOption(select, qty) || await setNativeSelectQuantity(select, qty);
    if (!selected) continue;
    if (context === "regular") {
      syncRegularQuantity(qty);
      await sleep(400);
      if (!quantityValueAccepted(context, qty)) continue;
    }
    await sleep(900);
    const issue = quantityAvailabilityIssue(context, qty);
    if (issue) {
      if (quantityValueAccepted(context, qty)) {
        showPanel(
          "Nutricity fulfilment",
          `Amazon accepted the ${context === "sns" ? "Subscribe & Save " : ""}quantity despite a limited availability warning. Continuing.`,
          null,
          null,
        );
        return true;
      }
      issue.context = context;
      window.__nutricityLastQuantityIssue = issue;
      return false;
    }
    return true;
  }
  for (const input of quantityTextInputs(context)) {
    const typed = await setDirectQuantityInput(input, qty, context);
    if (!typed) continue;
    if (context === "regular") {
      syncRegularQuantity(qty);
      await sleep(400);
      if (!quantityValueAccepted(context, qty)) continue;
    }
    const issue = quantityAvailabilityIssue(context, qty);
    if (issue) {
      if (quantityValueAccepted(context, qty)) {
        showPanel(
          "Nutricity fulfilment",
          `Amazon accepted the ${context === "sns" ? "Subscribe & Save " : ""}quantity despite a limited availability warning. Continuing.`,
          null,
          null,
        );
        return true;
      }
      issue.context = context;
      window.__nutricityLastQuantityIssue = issue;
      return false;
    }
    return true;
  }
  const issue = quantityAvailabilityIssue(context, qty);
  if (issue) {
    issue.context = context;
    window.__nutricityLastQuantityIssue = issue;
  }
  return false;
}

async function navigateToNext(activeJob) {
  const nextIndex = activeJob.itemIndex + 1;
  if (nextIndex < activeJob.job.items.length) {
    activeJob.itemIndex = nextIndex;
    activeJob.stage = "product";
    await setActiveJob(activeJob);
    location.href = `https://www.amazon.com/dp/${activeJob.job.items[nextIndex].asin}`;
    return;
  }
  activeJob.stage = "cart";
  await setActiveJob(activeJob);
  location.href = "https://www.amazon.com/cart?ref_=sw_gtc";
}

async function handleClearCart(activeJob) {
  if (!canClearCart(activeJob)) {
    activeJob.stage = "cart";
    activeJob.cartCleared = true;
    await setActiveJob(activeJob);
    showPanel("Nutricity fulfilment", "Cart clear is no longer safe at this stage. Continuing with cart check.", null, null);
    return;
  }
  await waitForElement(["#sc-active-cart", "input[name='proceedToRetailCheckout']", "#sc-buy-box-ptc-button input"], 15000);
  showPanel("Nutricity fulfilment", "Clearing the existing Amazon cart before starting this order.", null, null);
  await waitForElement("#sc-active-cart", 15000);
  for (let attempt = 0; attempt < 30; attempt += 1) {
    const buttons = cartDeleteButtons();
    if (!buttons.length) break;
    showPanel("Nutricity fulfilment", `Clearing Amazon cart item ${attempt + 1}. ${buttons.length} active delete link(s) found.`, null, null);
    await clickElement(buttons[0], "cart delete button");
    await waitForStableDom(800, 6000);
  }

  activeJob.stage = "product";
  activeJob.itemIndex = 0;
  activeJob.cartCleared = true;
  await setActiveJob(activeJob);
  const first = activeJob.job.items[0];
  location.href = `https://www.amazon.com/dp/${first.asin}`;
}

async function clearCartItems(reason = "Cleaning Amazon cart before starting the next order.") {
  await waitForElement([
    "#sc-active-cart",
    "#sc-empty-cart",
    "input[name='proceedToRetailCheckout']",
    "#sc-buy-box-ptc-button input",
    "[data-name='Active Items']",
  ], 15000);
  showPanel("Nutricity fulfilment", reason, null, null);
  for (let attempt = 0; attempt < 30; attempt += 1) {
    const buttons = cartDeleteButtons();
    if (!buttons.length) break;
    showPanel("Nutricity fulfilment", `Cleaning Amazon cart item ${attempt + 1}. ${buttons.length} active delete link(s) found.`, null, null);
    await clickElement(buttons[0], "cart delete button");
    await waitForStableDom(800, 6000);
  }
}

async function handleFailureCleanup(activeJob) {
  if (!/\/cart/i.test(location.pathname)) {
    showPanel("Nutricity fulfilment", "Order was moved to Missing ASINs. Opening cart cleanup before continuing.", null, null);
    location.href = "https://www.amazon.com/cart?ref_=sw_gtc";
    return;
  }
  await clearCartItems(activeJob.cleanupReason || "Order was moved to Missing ASINs. Cleaning cart before continuing.");
  const result = await send({ type: "CLAIM_NEXT_IN_WINDOW" });
  if (result?.next_job_started) {
    showPanel("Nutricity fulfilment", result.message || `Started next ${result.next_group_key}.`, null, null);
    return;
  }
  showPanel("Nutricity fulfilment", result?.message || "No more queued Chrome jobs found.", null, null);
}

async function handleProduct(activeJob) {
  const item = activeJob.job.items[activeJob.itemIndex];
  if (!item) return;
  const expectedItem = selectedVariantItem(activeJob, item);
  const pageError = amazonProductPageErrorMessage();
  if (pageError) {
    await failCurrentItemAsMissing(activeJob, item, expectedItem, `ASIN ${expectedItem.asin} is missing or unavailable on Amazon. ${pageError}`);
    return;
  }
  const productReady = await waitForElement([
    "#productTitle",
    "#add-to-cart-button",
    "input[name='submit.add-to-cart']",
    "#rcx-subscribe-submit-button",
    "#corePrice_feature_div .a-price",
    "#apex_desktop .a-price",
  ], 18000);
  const delayedPageError = amazonProductPageErrorMessage();
  if (!productReady || delayedPageError) {
    await failCurrentItemAsMissing(
      activeJob,
      item,
      expectedItem,
      `ASIN ${expectedItem.asin} is missing or unavailable on Amazon. ${delayedPageError || "Amazon did not load product controls for this ASIN."}`,
    );
    return;
  }
  const asin = currentAsinFromUrl();
  showPanel("Nutricity fulfilment", `Adding ${expectedItem.asin} for ${recipientName(activeJob)}.`, null, null);
  if (asin && asin !== expectedItem.asin) {
    location.href = `https://www.amazon.com/dp/${expectedItem.asin}`;
    return;
  }
  rememberProductDosage(activeJob, item);
  await setActiveJob(activeJob);

  const unavailable = unavailableMessage();
  if (unavailable) {
    await failCurrentItemAsMissing(activeJob, item, expectedItem, `ASIN ${expectedItem.asin} is unavailable on Amazon. ${unavailable}`);
    return;
  }

  const savingsApplied = await applyAdditionalSavings("regular");
  if (savingsApplied) {
    await waitForStableDom(900, 6000);
  }
  const promoCount = markPromotions();
  if (promoCount && !activeJob.promoAcknowledged[item.asin]) {
    activeJob.promoAcknowledged[item.asin] = true;
    await setActiveJob(activeJob);
    showPanel("Nutricity fulfilment", "Coupon or promotion detected. Continuing price comparison.", null, null);
    await sleep(900);
  }

  const priceSnapshot = productPriceSnapshot();
  const mixedAsinOrder = isMixedAsinOrder(activeJob);
  const priceForVariantDecision = mixedAsinOrder ? (priceSnapshot.regular || priceSnapshot.best) : priceSnapshot.best;
  const switchedVariant = await selectCheapestCountVariant(activeJob, item, priceForVariantDecision);
  if (switchedVariant) return;
  const purchaseItem = selectedVariantItem(activeJob, item);
  const mixedAsinAfterVariant = isMixedAsinOrder(activeJob);
  const selectionNote = variantSelectionNote(item, purchaseItem);
  if (selectionNote) {
    showPanel("Pack variant found", `${selectionNote} Proceeding with this option.`, null, null);
    await sleep(1800);
  }
  const snsIsCheaper = priceSnapshot.sns && priceSnapshot.regular && priceSnapshot.sns < priceSnapshot.regular;
  const useSubscribeAndSave = snsIsCheaper && !mixedAsinAfterVariant;
  const priceForDecision = useSubscribeAndSave ? priceSnapshot.sns : (priceSnapshot.regular || priceSnapshot.best);
  await recordAmazonPrice(activeJob, item, priceForDecision, useSubscribeAndSave ? "subscribe-save" : "product", purchaseItem);
  const quantity = Number(purchaseItem.quantity || 1);
  const storeTotal = Number(item.store_total_price || Number(item.store_unit_price || 0) * Number(item.quantity || 1) || 0);
  const amazonTotal = Number(priceForDecision || 0) * quantity;
  if (!item.cost_approved && storeTotal > 0 && amazonTotal > storeTotal) {
    await send({
      type: "COSTLY_JOB",
      message: `ASIN ${purchaseItem.asin} costs $${amazonTotal.toFixed(2)} on Amazon but store sale value is $${storeTotal.toFixed(2)}. Approval required before fulfilment.`,
      costlyAsin: item.asin,
      costlyLineId: itemPrimaryLineId(item),
      storeTotalPrice: storeTotal,
      amazonTotalPrice: amazonTotal,
    });
    showPanel("Costly fulfilment review", "Amazon cost is higher than store sale value. Order moved to Costly page.", null, null);
    return;
  }

  if (mixedAsinAfterVariant && snsIsCheaper) {
    showPanel(
      "Subscribe & Save skipped",
      `This order has multiple different ASINs, so ${purchaseItem.asin} will be added with regular Add to cart even though Subscribe & Save is cheaper (${moneyText(priceSnapshot.sns)} vs ${moneyText(priceSnapshot.regular)}).`,
      null,
      null,
    );
    await sleep(900);
  }

  const subscribed = useSubscribeAndSave ? await applySubscribeAndSaveIfCheaper(purchaseItem.quantity, activeJob) : false;
  if (!subscribed) {
    if (useSubscribeAndSave) {
      throw new Error(`Subscribe & Save is cheaper (${moneyText(priceSnapshot.sns)} vs ${moneyText(priceSnapshot.regular)}), but the extension did not complete the Subscribe & Save selection. Fulfilment paused before changing regular quantity.`);
    }
    const quantitySet = await setQuantity(purchaseItem.quantity, "regular");
    if (!quantitySet) {
      const requestedQuantity = Math.max(1, Math.round(Number(purchaseItem.quantity || 1)));
      const quantityIssue = window.__nutricityLastQuantityIssue || {};
      const availableQuantity = quantityIssue.availableQuantity || maxPredefinedQuantity("regular") || maxSelectableQuantity("regular");
      const lessQuantity = availableQuantity > 0 && availableQuantity < requestedQuantity;
      const issueMessage = quantityIssue.message ? ` ${quantityIssue.message}` : "";
      const message = lessQuantity
        ? `Less quantity available for ASIN ${purchaseItem.asin}. Customer ordered ${requestedQuantity}, Amazon only allows ${availableQuantity}.${issueMessage}`
        : `ASIN ${purchaseItem.asin} is missing or unavailable. Could not set quantity ${purchaseItem.quantity || 1}.${issueMessage}`;
      if (await continueAfterPartialMissing(activeJob, item, purchaseItem, message, "partial_quantity", {
        requestedQuantity,
        fulfilledQuantity: availableQuantity || null,
        availableQuantity: availableQuantity || null,
      })) {
        return;
      }
      showPanel("Sending to Missing ASINs", message, null, null);
      await send({
        type: "FAIL_JOB",
        message,
        missingAsin: item.asin,
        missingLineId: itemPrimaryLineId(item),
        failureCode: "partial_quantity",
        requestedQuantity,
        fulfilledQuantity: availableQuantity || null,
        availableQuantity: availableQuantity || null,
      });
      showPanel("Missing ASINs", `${message} Order moved to Missing ASINs.`, null, null);
      return;
    }
    const requestedQuantity = Math.max(1, Math.round(Number(purchaseItem.quantity || 1)));
    if (requestedQuantity > 1 && !quantityValueAccepted("regular", requestedQuantity)) {
      const message = `ASIN ${purchaseItem.asin} is missing or unavailable. Amazon did not verify regular Add to cart quantity ${requestedQuantity}.`;
      if (await continueAfterPartialMissing(activeJob, item, purchaseItem, message, "partial_quantity", {
        requestedQuantity,
        fulfilledQuantity: null,
        availableQuantity: null,
      })) {
        return;
      }
      showPanel("Sending to Missing ASINs", message, null, null);
      await send({
        type: "FAIL_JOB",
        message,
        missingAsin: item.asin,
        missingLineId: itemPrimaryLineId(item),
        failureCode: "partial_quantity",
        requestedQuantity,
        fulfilledQuantity: null,
        availableQuantity: null,
      });
      showPanel("Missing ASINs", `${message} Order moved to Missing ASINs.`, null, null);
      return;
    }
    const addButton = await waitForElement(["#add-to-cart-button", "input[name='submit.add-to-cart']", "#buybox-add-to-cart-button input"], 18000);
    activeJob.stage = "add_clicked";
    activeJob.addClickedAt = Date.now();
    markItemAdded(activeJob);
    await setActiveJob(activeJob);
    const added = await clickElement(addButton, "Add to cart button");
    if (!added) {
      const message = `ASIN ${purchaseItem.asin} is missing or unavailable. Could not find Add to cart button.`;
      showPanel("Sending to Missing ASINs", message, null, null);
      await send({ type: "FAIL_JOB", message, missingAsin: item.asin, missingLineId: itemPrimaryLineId(item) });
      showPanel("Missing ASINs", `${message} Job marked as error.`, null, null);
      return;
    }
  }

  showPanel("Nutricity fulfilment", `Add clicked for ${purchaseItem.asin}. Waiting for Amazon before moving on.`, null, null);
}

async function handleAddClicked(activeJob) {
  const clickedAt = Number(activeJob.addClickedAt || 0);
  const waitMs = Math.max(0, 4500 - (Date.now() - clickedAt));
  if (waitMs) {
    showPanel("Nutricity fulfilment", "Amazon add was clicked. Waiting before moving to the next step.", null, null);
    await sleep(waitMs);
  }
  if (/\/cart/i.test(location.pathname)) {
    const nextIndex = Number(activeJob.itemIndex || 0) + 1;
    if (nextIndex >= (activeJob.job?.items || []).length) {
      activeJob.stage = "cart";
      await setActiveJob(activeJob);
      await handleCart(activeJob);
      return;
    }
  }
  await navigateToNext(activeJob);
}

async function handleSubscribeCheckout(activeJob) {
  markCheckoutStarted(activeJob);
  activeJob.subscribeAndSave = true;
  if (/\/checkout/i.test(location.pathname) || document.querySelector("#placeOrder, input.place-your-order-button, [data-checkout-view-modal], #checkout-primary-continue-button-id, input[aria-label='Full name']")) {
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
    await handleCheckout(activeJob);
    return;
  }
  showPanel("Nutricity fulfilment", "Subscribe & Save clicked. Waiting for checkout.", null, null);
  await sleep(2500);
  const latest = await getActiveJob();
  if (latest?.stage === "subscribe_checkout" && !/\/checkout/i.test(location.pathname)) {
    latest.stage = "checkout";
    await setActiveJob(latest);
  }
}

async function handleCart(activeJob) {
  await waitForElement(["#sc-active-cart", "input[name='proceedToRetailCheckout']", "#sc-buy-box-ptc-button input"], 15000);
  if (activeJob.subscribeAndSave || activeJob.stage === "subscribe_checkout") {
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
    showPanel("Nutricity fulfilment", "Subscribe & Save is already in checkout flow. Not clearing cart.", null, null);
    return;
  }
  if (activeJob.stage === "clear_cart") {
    if (!canClearCart(activeJob)) {
      activeJob.stage = "cart";
      activeJob.cartCleared = true;
      await setActiveJob(activeJob);
    } else {
      await handleClearCart(activeJob);
      return;
    }
  }
  const cartCheck = verifyCartQuantities(activeJob);
  if (!cartCheck.ok) {
    const mismatch = (cartCheck.mismatches || [])[0];
    const missingAsin = mismatch?.asin || "";
    const message = mismatch
      ? `Could not add the desired quantity for ASIN ${missingAsin}. Customer ordered ${mismatch.expected}, Amazon cart has ${mismatch.actual}.`
      : `Could not verify the desired Amazon cart quantities. ${cartCheck.message}`;
    const missingItem = (activeJob.job?.items || []).find((entry) => String(entry.asin || "").toUpperCase() === String(missingAsin || "").toUpperCase());
    if (missingItem && (activeJob.job?.items || []).length > 1 && await shouldFulfilAvailableMixedAsin(activeJob)) {
      showPanel("Sending line to Missing ASINs", message, null, null);
      const partialResult = await send({
        type: "MARK_LINE_MISSING",
        message,
        missingAsin,
        missingLineId: itemPrimaryLineId(missingItem),
        failureCode: "partial_quantity",
        requestedQuantity: mismatch?.expected ?? null,
        fulfilledQuantity: mismatch?.actual ?? 0,
        availableQuantity: mismatch?.actual ?? 0,
      });
      if (partialResult?.ok) {
        removeMissingItemFromActiveJob(activeJob, missingItem, selectedVariantItem(activeJob, missingItem));
        activeJob.stage = "cart";
        await setActiveJob(activeJob);
        showPanel("Split fulfilment", `${message} ${partialResult.message || ""} Proceeding to checkout for remaining Amazon item(s).`, null, null);
        return;
      }
    }
    showPanel("Sending to Missing ASINs", message, null, null);
    await send({
      type: "FAIL_JOB",
      message,
      missingAsin,
      missingLineId: lineIdForAsin(activeJob, missingAsin),
      failureCode: "partial_quantity",
      requestedQuantity: mismatch?.expected ?? null,
      fulfilledQuantity: mismatch?.actual ?? 0,
      availableQuantity: mismatch?.actual ?? 0,
    });
    showPanel("Missing ASINs", `${message} Order moved to Missing ASINs.`, null, null);
    return;
  }
  if (cartCheck.warning) {
    showPanel("Nutricity fulfilment", cartCheck.warning, null, null);
    await sleep(1800);
  }
  showPanel("Nutricity fulfilment", "Cart ready. Proceeding to checkout.", null, null);
  let clicked = false;
  const checkoutInput = await waitForElement([
    "input[name='proceedToRetailCheckout']",
    "#sc-buy-box-ptc-button input",
    "input[data-feature-id='proceed-to-checkout-action']",
  ], 18000);
  if (checkoutInput) {
    markCheckoutStarted(activeJob);
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
    clicked = await clickElement(checkoutInput, "Proceed to checkout button");
  }
  if (!clicked) {
    const button = findButtonByText(["proceed to checkout", "check out amazon cart"]);
    if (button) {
      markCheckoutStarted(activeJob);
      activeJob.stage = "checkout";
      await setActiveJob(activeJob);
      clicked = await clickElement(button, "Proceed to checkout button");
    }
  } else {
    markCheckoutStarted(activeJob);
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
  }
  if (!clicked) return;
}

async function fillFullName(name) {
  if (window.__nutricityFillingFullName) return false;
  window.__nutricityFillingFullName = true;
  try {
  const input = await waitUntil(() => (
    document.querySelector("input#address-ui-widgets-enterAddressFullName[name='address-ui-widgets-enterAddressFullName']")
    || findAddressNameInput()
  ), 20000);
  if (!input) return false;
  const desired = String(name || "").replace(/\s+/g, " ").trim();
  if (!desired) return false;
  input.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(500);
  await setInputValue(input, desired);
  await sleep(800);
  let saved = input.value.replace(/\s+/g, " ").trim() === desired;
  if (!saved) {
    await setInputValue(input, desired);
    await sleep(500);
    saved = input.value.replace(/\s+/g, " ").trim() === desired;
  }
  input.blur();
  return saved;
  } finally {
    window.__nutricityFillingFullName = false;
  }
}

async function setInputValue(input, value) {
  const desired = String(value ?? "");
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
  input.focus();
  input.click?.();
  await sleep(100);
  input.select?.();
  setter ? setter.call(input, "") : (input.value = "");
  input.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, composed: true, inputType: "deleteContentBackward", data: null }));
  input.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "deleteContentBackward", data: null }));
  await sleep(50);
  input.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, composed: true, inputType: "insertText", data: desired }));
  setter ? setter.call(input, desired) : (input.value = desired);
  input.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: desired }));
  input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key: "Tab" }));
  input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key: "Tab" }));
}

function addressDataForRow(row) {
  const carrier = row?.closest?.("[data-action='select_address_in_list'][data-select_address_in_list]") || row?.querySelector?.("[data-action='select_address_in_list'][data-select_address_in_list]");
  if (!carrier) return {};
  try {
    return JSON.parse(carrier.getAttribute("data-select_address_in_list") || "{}");
  } catch {
    return {};
  }
}

function rowIsNutricityAddress(row) {
  if (!row) return false;
  const data = addressDataForRow(row);
  const dataName = normalizedText(data.fullName);
  const visibleName = normalizedText(row.querySelector?.("[data-testid='address-row-radio-name']")?.textContent || "");
  const rowText = normalizedText(row.innerText || row.textContent || "");
  return dataName.includes("nutricity") || visibleName.includes("nutricity") || rowText.includes("nutricity");
}

function checkoutAddressRows() {
  const selectorRows = [...document.querySelectorAll(
    [
      "[data-testid='address-row-radio']",
      "[data-testid='address-row-section']",
      "[data-testid^='address-row-'][id^='address-row-']",
      ".address-row-section",
      ".address-row",
      "[data-action='select_address_in_list']",
    ].join(", "),
  )];
  const radioRows = [...document.querySelectorAll("input[type='radio']")]
    .map((radio) => {
      let row = radio.closest("label, .a-row, .a-section, div");
      for (let i = 0; row && i < 6; i += 1) {
        const text = normalizedText(row.innerText || row.textContent || "");
        if (text.includes("edit address") || text.includes("delivery preferences") || text.includes("united states")) return row;
        row = row.parentElement;
      }
      return radio.closest("label") || radio.parentElement;
    })
    .filter(Boolean);
  return [...new Set([...selectorRows, ...radioRows])].filter(visible);
}

function nutricityAddressRow() {
  return checkoutAddressRows().find(rowIsNutricityAddress) || null;
}

function addressRowForRecipient(name) {
  const wanted = normalizedText(name);
  if (!wanted) return null;
  return checkoutAddressRows().find((row) => normalizedText(row.innerText || row.textContent).includes(wanted)) || null;
}

function addressSelectionControl(row) {
  if (!row) return null;
  const label = row.closest?.("label");
  const radio = row.matches?.("input[type='radio']") ? row
    : row.querySelector("input[type='radio'][name='addressID'], input[type='radio']")
    || label?.querySelector?.("input[type='radio'][name='addressID']")
    || row.closest?.("[data-testid='address-row-radio']")?.querySelector?.("input[type='radio'][name='addressID']");
  return radio?.closest?.("label") || radio || row;
}

function nutricityAddressSelectionControl() {
  return addressSelectionControl(nutricityAddressRow());
}

function recipientAddressSelectionControl(name) {
  return addressSelectionControl(addressRowForRecipient(name));
}

function addressSelectionControlForElement(element) {
  const row = element?.closest?.(
    "[data-testid='address-row-radio'], [data-testid='address-row-section'], [data-testid^='address-row-'], .address-row-section, .address-row, [data-action='select_address_in_list']",
  );
  if (!row) return null;
  const label = row.closest?.("label");
  const radio = row.querySelector("input[type='radio'][name='addressID']")
    || label?.querySelector?.("input[type='radio'][name='addressID']")
    || row.closest?.("[data-testid='address-row-radio']")?.querySelector?.("input[type='radio'][name='addressID']");
  return radio?.checked ? null : radio?.closest?.("label") || radio || null;
}

async function selectAddressRadioForElement(element) {
  const control = addressSelectionControlForElement(element);
  if (!control) return false;
  showPanel("Nutricity checkout", "Selecting delivery address row.", null, null);
  await clickElement(control, "Address radio button");
  await sleep(700);
  return true;
}

function findEditAddressTrigger() {
  const triggers = [...document.querySelectorAll("[id^='declarativeAction-'][data-action='checkout-view-modal']")].filter((element) => {
    const modalData = element.getAttribute("data-checkout-view-modal") || "";
    const text = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    return visible(element) && (modalData.includes("editAddressModal") || text.includes("edit address"));
  });
  const nutricityRowTrigger = triggers.find((element) => {
    const row = element.closest("[data-testid='address-row-radio'], [data-testid='address-row-section'], [data-testid^='address-row-'], .address-row-section, .address-row, [data-action='select_address_in_list']");
    return rowIsNutricityAddress(row);
  });
  if (nutricityRowTrigger) return nutricityRowTrigger.querySelector("a, button, span") || nutricityRowTrigger;

  const preferred = triggers.find((element) => {
    const row = element.closest("[data-testid='address-row-radio'], [data-testid='address-row-section'], [data-testid^='address-row-'], .address-row-section, .address-row, [data-action='select_address_in_list']");
    return rowIsNutricityAddress(row);
  });
  const selected = preferred || triggers[1] || triggers[0];
  if (selected) return selected.querySelector("a, button, span") || selected;

  const modalTriggers = [...document.querySelectorAll("[data-checkout-view-modal]")].filter((element) => {
    const modalData = element.getAttribute("data-checkout-view-modal") || "";
    return visible(element) && modalData.includes("editAddressModal");
  });
  const modalTrigger = modalTriggers[1] || modalTriggers[0];
  if (modalTrigger) return modalTrigger.querySelector("a, button, span") || modalTrigger;

  const xpath = "//*[starts-with(@id,'declarativeAction-') and .//*[normalize-space()='Edit address']]";
  const xpathNode = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (xpathNode && visible(xpathNode)) return xpathNode.querySelector?.("a, button, span") || xpathNode;

  const nutricityRow = nutricityAddressRow();
  const rowEditLink = [...(nutricityRow?.querySelectorAll?.("a, button, span") || [])].find((element) => {
    const text = (element.innerText || element.textContent || "").trim().toLowerCase();
    return visible(element) && text === "edit address";
  });
  if (rowEditLink) return rowEditLink;

  return [...document.querySelectorAll("a, button, span")].find((element) => {
    const text = (element.innerText || element.textContent || "").trim().toLowerCase();
    return visible(element) && text === "edit address";
  });
}

function normalizedText(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function elementReadableText(element) {
  if (!element) return "";
  return [
    element.innerText,
    element.textContent,
    element.getAttribute?.("aria-label"),
    element.getAttribute?.("title"),
    element.getAttribute?.("data-testid"),
  ].filter(Boolean).join(" ");
}

function checkoutShowsRecipient(name) {
  const wanted = normalizedText(name);
  if (!wanted) return false;
  const roots = [];
  const deliveryHeading = document.querySelector("#deliver-to-customer-text");
  if (deliveryHeading) roots.push(deliveryHeading.closest?.("a, .a-row, .a-section, div") || deliveryHeading);
  const deliveryAddress = document.querySelector("#deliver-to-address-text");
  if (deliveryAddress) roots.push(deliveryAddress.closest?.("a, .a-row, .a-section, div") || deliveryAddress);
  for (const radio of [...document.querySelectorAll("input[type='radio']:checked")]) {
    const row = radio.closest?.("[data-testid^='address-row-'], .address-row, .a-box, .a-row, div");
    if (row) roots.push(row);
  }
  for (const root of roots) {
    if (!root || root.closest?.("#nutricity-panel") || root.closest?.(".a-popover, .a-popover-preload")) continue;
    const text = normalizedText(elementReadableText(root));
    if (text.includes(wanted)) return true;
  }
  return false;
}

function checkoutDeliveryRecipientText() {
  const direct = document.querySelector("#deliver-to-customer-text");
  const candidates = [
    direct,
    document.querySelector("#deliver-to-address-text")?.closest?.(".a-row, .a-section, a, div"),
    ...document.querySelectorAll("h2, [id*='deliver-to'][id*='customer'], a[aria-label='Change delivery address'], a[href*='/checkout/'][href*='/address']"),
  ].filter(Boolean);
  for (const element of candidates) {
    if (!visible(element)) continue;
    const text = elementReadableText(element).replace(/\s+/g, " ").trim();
    if (/^delivering\s+to\s+/i.test(text)) return text.replace(/^delivering\s+to\s+/i, "").trim();
    const embedded = text.match(/\bDelivering\s+to\s+(.+?)(?:\s+\d{3,}|\s+Edit delivery preferences|\s+Deliver to multiple addresses|\s+Change delivery address|$)/i);
    if (embedded?.[1]) return embedded[1].trim();
  }
  const bodyText = (document.body?.innerText || document.body?.textContent || "").replace(/\s+/g, " ").trim();
  const bodyMatch = bodyText.match(/\bDelivering\s+to\s+(.+?)(?:\s+\d{3,}|\s+Edit delivery preferences|\s+Deliver to multiple addresses|\s+Change delivery address|$)/i);
  if (bodyMatch?.[1]) return bodyMatch[1].trim();
  return "";
}

function checkoutDeliveryRecipientMatches(name) {
  const deliveredTo = normalizedText(checkoutDeliveryRecipientText());
  const wanted = normalizedText(name);
  return Boolean(deliveredTo && wanted && (
    deliveredTo === wanted ||
    deliveredTo.includes(wanted) ||
    wanted.includes(deliveredTo)
  ));
}

function checkoutRecipientConfirmed(name) {
  return checkoutDeliveryRecipientMatches(name) || checkoutShowsRecipient(name);
}

async function markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, message = "Verified delivery address. Continuing checkout.") {
  activeJob.stage = "checkout";
  activeJob.editAddressClickedAt = null;
  activeJob.addressEditedRecipient = checkoutRecipient;
  activeJob.addressEditedAt = Date.now();
  activeJob.addressVerifiedRecipient = checkoutRecipient;
  activeJob.addressVerifiedAt = Date.now();
  activeJob.addressVerifyAttempts = 0;
  await setActiveJob(activeJob);
  showPanel("Nutricity checkout", message, null, null);
  return true;
}

function findChangeDeliveryAddressButton() {
  return [...document.querySelectorAll(
    [
      "a[data-csa-c-slot-id='checkout-change-shipaddressselect']",
      "a[data-topage='shipaddressselect']",
      "a[aria-label='Change delivery address']",
      "a#change-delivery-link",
      "a.expand-panel-button",
      "a",
      "button",
    ].join(", "),
  )].find((element) => {
    const href = String(element.getAttribute?.("href") || element.href || "").toLowerCase();
    const text = normalizedText(element.getAttribute?.("aria-label") || element.innerText || element.textContent);
    return visible(element) && !element.disabled && (
      element.getAttribute?.("data-csa-c-slot-id") === "checkout-change-shipaddressselect" ||
      element.getAttribute?.("data-topage") === "shipaddressselect" ||
      text === "change delivery address" ||
      text === "change" && href.includes("/checkout/") && href.includes("/address")
    );
  });
}

function findAddressNameInput() {
  return [...document.querySelectorAll(
    [
      "#address-ui-widgets-enterAddressFullName",
      "input[name='address-ui-widgets-enterAddressFullName']",
      "input[aria-label='Full name']",
      "input[aria-label='Full Name']",
      "input[placeholder='Full name']",
      "input[placeholder='Full Name']",
      "input[autocomplete='name']",
      "input[name*='FullName']",
      "input[id*='FullName']",
      "input[name*='fullName']",
      "input[id*='fullName']",
      "input[name*='Name']",
      "input[id*='Name']",
    ].join(", "),
  )].find((element) => visible(element) && !element.disabled);
}

function findAddressField(selectors) {
  return [...document.querySelectorAll(selectors.join(", "))].find((element) => visible(element) && !element.disabled);
}

async function fillAddressInput(selectors, value, required = true) {
  const input = await waitUntil(() => findAddressField(selectors), 8000, 300);
  if (!input) return !required;
  input.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(200);
  await setInputValue(input, value);
  await sleep(150);
  input.blur();
  return String(input.value || "").trim() === String(value || "").trim();
}

async function setAddressSelect(selectors, value, required = true) {
  const select = await waitUntil(() => findAddressField(selectors), 8000, 300);
  if (!select) return !required;
  select.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(200);
  const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
  setter ? setter.call(select, value) : (select.value = value);
  select.dispatchEvent(new Event("input", { bubbles: true }));
  select.dispatchEvent(new Event("change", { bubbles: true }));
  await sleep(250);
  return select.value === value;
}

async function fillNewDeliveryAddress(checkoutRecipient) {
  const address = DEFAULT_NEW_DELIVERY_ADDRESS;
  const steps = [
    () => setAddressSelect([
      "#address-ui-widgets-countryCode-dropdown-nativeId",
      "select[name='address-ui-widgets-countryCode']",
    ], address.countryCode),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressFullName",
      "input[name='address-ui-widgets-enterAddressFullName']",
      "input[autocomplete='name']",
    ], checkoutRecipient),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressPhoneNumber",
      "input[name='address-ui-widgets-enterAddressPhoneNumber']",
      "input[autocomplete='tel']",
    ], address.phoneNumber),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressLine1",
      "input[name='address-ui-widgets-enterAddressLine1']",
    ], address.addressLine1),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressLine2",
      "input[name='address-ui-widgets-enterAddressLine2']",
    ], address.addressLine2, false),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressCity",
      "input[name='address-ui-widgets-enterAddressCity']",
    ], address.city),
    () => setAddressSelect([
      "#address-ui-widgets-enterAddressStateOrRegion-dropdown-nativeId",
      "select[name='address-ui-widgets-enterAddressStateOrRegion']",
    ], address.stateOrRegion),
    () => fillAddressInput([
      "#address-ui-widgets-enterAddressPostalCode",
      "input[name='address-ui-widgets-enterAddressPostalCode']",
    ], address.postalCode),
  ];
  for (const step of steps) {
    if (!await step()) return false;
  }
  return true;
}

async function waitUntil(check, timeoutMs = 12000, intervalMs = 300) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    await waitIfPaused();
    const result = check();
    if (result) return result;
    await sleep(intervalMs);
  }
  return null;
}

function findUseAddressButton() {
  const addressEditorOpen = Boolean(findAddressNameInput());
  const selectors = [
    "input[data-csa-c-slot-id='address-ui-widgets-continue-edit-address-btn-bottom'][data-testid='bottom-continue-button']",
    "input[data-csa-c-slot-id*='continue-edit-address']",
    "button[data-csa-c-slot-id*='continue-edit-address']",
    "input[data-testid='bottom-continue-button']",
    "button[data-testid='bottom-continue-button']",
    "input[data-testid*='continue-button']",
    "button[data-testid*='continue-button']",
    "input[aria-labelledby='checkout-primary-continue-button-id-announce']",
    "#checkout-primary-continue-button-id input",
  ];
  if (addressEditorOpen) {
    selectors.push(
      ".a-popover input[type='submit']",
      ".a-popover button[type='submit']",
      ".a-modal-scroller input[type='submit']",
      ".a-modal-scroller button[type='submit']",
    );
  }
  const direct = [...document.querySelectorAll(selectors.join(", "))].find((element) => visible(element) && !element.disabled);
  if (direct) return direct;

  return [...document.querySelectorAll("input[type='submit'], button, span.a-button")].find((element) => {
    const text = normalizedText(element.value || element.innerText || element.textContent);
    return visible(element) && [
      "use this address",
      "save address",
      "continue to checkout",
      "continue",
    ].some((needle) => text.includes(needle));
  });
}

async function clickUseAddressButton(useAddress) {
  const target = document.querySelector("#checkout-primary-continue-button-id-announce")
    || useAddress?.closest?.("[data-action='checkout-continue-button-click-action']")?.querySelector?.("#checkout-primary-continue-button-id-announce, .a-button-text")
    || useAddress?.closest?.("#checkout-primary-continue-button-id")?.querySelector?.("#checkout-primary-continue-button-id-announce, .a-button-text")
    || useAddress?.closest?.("span.a-button")?.querySelector?.(".a-button-text")
    || useAddress;
  return clickElement(target, "Use this address button");
}

function findDeliverToThisAddressButton() {
  if (findAddressNameInput()) return null;
  const direct = [...document.querySelectorAll(
    "input[data-testid='ab-select-address-continue-button-bottom'], #ab-select-address-continue-button-bottom input, input[aria-labelledby='ab-select-address-continue-button-bottom-announce']",
  )].find((element) => visible(element) && !element.disabled);
  return direct || findButtonByText(["deliver to this address", "use this address"]);
}

function cardPreferenceList(value) {
  return String(value || "")
    .split(/[\s,;|]+/)
    .map((item) => item.replace(/\D/g, "").slice(-4))
    .filter((item) => item.length === 4);
}

function paymentRowForRadio(radio) {
  if (!radio) return null;
  const label = radio.closest?.("label");
  const labelText = normalizedText(label?.innerText || label?.textContent || "");
  if (labelText.match(/\bending\s+in\s+\d{4}\b/i)) return label;

  let fallback = null;
  let node = radio.parentElement;
  for (let depth = 0; node && depth < 14; depth += 1, node = node.parentElement) {
    const text = normalizedText(node.innerText || node.textContent || "");
    const endings = text.match(/\bending\s+in\s+\d{4}\b/gi) || [];
    if (endings.length === 1) return node;
    if (!fallback && endings.length > 0) fallback = node;
  }
  return fallback || label || radio.parentElement || radio;
}

function paymentRowVisible(row) {
  if (!row) return false;
  if (visible(row)) return true;
  return [...row.querySelectorAll?.("*") || []].some((element) => visible(element));
}

function paymentRadioVisible(radio) {
  if (!radio || radio.disabled) return false;
  if (visible(radio)) return true;
  const row = paymentRowForRadio(radio);
  if (!row) return false;
  const text = normalizedText(row.innerText || row.textContent || "");
  return Boolean(text.match(/\bending\s+in\s+\d{4}\b/i) && paymentRowVisible(row));
}

function findPaymentRadio() {
  return [...document.querySelectorAll("input[type='radio'][name='ppw-instrumentRowSelection']")]
    .find(paymentRadioVisible);
}

function paymentRowText(radio) {
  const label = radio?.closest?.("label");
  const labelledText = label?.innerText || label?.textContent || "";
  const root = paymentRowForRadio(radio);
  return [labelledText, root?.innerText || root?.textContent || "", radio?.value || ""].join(" ");
}

function paymentRadioLocalText(radio) {
  if (!radio) return "";
  const pieces = [
    radio.getAttribute?.("aria-label") || "",
    radio.getAttribute?.("title") || "",
    radio.value || "",
  ];
  const label = radio.closest?.("label");
  if (label) pieces.push(label.innerText || label.textContent || "");
  let node = radio.parentElement;
  for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
    const text = normalizedText(node.innerText || node.textContent || "");
    const endings = text.match(/\bending\s+in\s+\d{4}\b/gi) || [];
    if (endings.length <= 1) pieces.push(text);
    if (endings.length === 1) break;
  }
  return normalizedText(pieces.join(" "));
}

function paymentTextDigits(text) {
  const value = String(text || "");
  const directMatch = value.match(/(?:ending\s+in|card|visa|mastercard|amex|american\s+express|discover)[^\d]{0,40}(\d{4})\b/i);
  return directMatch?.[1] || "";
}

function cardDigitsForPaymentRadio(radio) {
  const localDigits = paymentTextDigits(paymentRadioLocalText(radio));
  if (localDigits) return localDigits;

  const root = paymentRowForRadio(radio);
  const dataNumber = root?.querySelector?.("[data-number]")?.getAttribute("data-number");
  const text = paymentRowText(radio);
  const endingMatch = text.match(/ending\s+in\s+(\d{4})/i);
  return (dataNumber || endingMatch?.[1] || "").replace(/\D/g, "").slice(-4);
}

function findCheckoutPaymentPanel() {
  return [...document.querySelectorAll(
    [
      "#checkout-paymentOptionPanel",
      "#selected-payment-methods-list-container",
      "#paymentOptionList",
      "#payment-information",
      "[id*='paymentOption']",
      "[id*='selected-payment']",
      "[data-csa-c-slot-id*='payselect']",
      "[data-testid*='payment']",
    ].join(", "),
  )].find((element) => visible(element));
}

function checkoutSelectedPaymentText() {
  const visiblePaymentSummaries = [...document.querySelectorAll("h2, h3, a, span, div")]
    .filter((element) => {
      if (!visible(element) || element.closest?.("#nutricity-panel") || element.closest?.(".a-popover, .a-popover-preload")) return false;
      const text = normalizedText(elementReadableText(element));
      return /\bpaying\s+with\b/.test(text) || /\bending\s+in\s+\d{4}\b/.test(text);
    })
    .map((element) => ({
      element,
      text: elementReadableText(element).replace(/\s+/g, " ").trim(),
    }))
    .filter((item) => item.text.length <= 220 || /\bpaying\s+with\b/i.test(item.text));
  const visiblePaymentSummary = visiblePaymentSummaries.sort((left, right) => left.text.length - right.text.length)[0];
  if (visiblePaymentSummary) {
    return visiblePaymentSummary.text;
  }

  const visibleSelectedRows = [...document.querySelectorAll(
    "#selected-payment-methods-list-container *, #payment-information *, [id*='selected-payment'] *",
  )]
    .filter((element) => {
      if (!visible(element) || element.closest?.("#nutricity-panel") || element.closest?.(".a-popover, .a-popover-preload")) return false;
      const text = normalizedText(elementReadableText(element));
      return /\b(?:visa|mastercard|american\s+express|amex|discover|card)\b.*\b\d{4}\b/.test(text);
    })
    .map((element) => elementReadableText(element).replace(/\s+/g, " ").trim())
    .filter((text) => text.length <= 220);
  if (visibleSelectedRows.length) return visibleSelectedRows.sort((left, right) => left.length - right.length)[0];

  const heading = document.querySelector(
    [
      "#selected-payment-methods-list-container h2",
      "#payment-option-text-default",
      "[id^='payment-option-text'][data-testid]",
      ".selected-payment-method-no-art-description-heading",
    ].join(", "),
  );
  if (heading && visible(heading)) {
    const text = elementReadableText(heading).replace(/\s+/g, " ").trim();
    if (/paying\s+with|ending\s+in\s+\d{4}|(?:visa|mastercard|american express|amex|discover|card)[^\d]{0,80}\d{4}/i.test(text)) return text;
  }

  const panel = findCheckoutPaymentPanel();
  if (panel) {
    const text = elementReadableText(panel).replace(/\s+/g, " ").trim();
    if (text.length <= 350 && /paying\s+with|ending\s+in\s+\d{4}|(?:visa|mastercard|american express|amex|discover|card)[^\d]{0,80}\d{4}/i.test(text)) return text;
  }
  return "";
}

function checkoutSelectedCardDigits() {
  const text = checkoutSelectedPaymentText();
  const preferredPattern = text.match(/(?:ending\s+in|visa|mastercard|american\s+express|amex|discover|card|paying\s+with)[^\d]{0,80}(\d{4})\b/i);
  if (preferredPattern) return preferredPattern[1];
  return "";
}

function checkoutPaymentConfirmed(preferences = []) {
  const placeOrder = findPlaceOrderButton();
  const text = checkoutSelectedPaymentText();
  const selectedDigits = checkoutSelectedCardDigits();
  if (preferences.length) return Boolean(selectedDigits && preferences.includes(selectedDigits));
  if (placeOrder && !placeOrder.disabled) return true;
  if (!text) return false;
  return /(?:payment method|paying with|ending in|visa|mastercard|american express|amex|discover|card)/i.test(text);
}

async function waitForPreferredCheckoutPayment(preferences = [], timeout = 8000) {
  return waitUntil(() => {
    const selectedDigits = checkoutSelectedCardDigits();
    if (selectedDigits && (!preferences.length || preferences.includes(selectedDigits))) return selectedDigits;
    if (!preferences.length && checkoutPaymentConfirmed(preferences)) return true;
    return false;
  }, timeout, 400);
}

function findPaymentRadioForPreferences(preferences = []) {
  const allRadios = [...document.querySelectorAll("input[type='radio'][name='ppw-instrumentRowSelection']")]
    .filter((radio) => radio && !radio.disabled);
  const radios = allRadios.filter(paymentRadioVisible);
  const searchRadios = radios.length ? radios : allRadios;
  if (!searchRadios.length) return null;
  for (const preferred of preferences) {
    const radio = searchRadios.find((candidate) => {
      const localText = paymentRadioLocalText(candidate);
      return cardDigitsForPaymentRadio(candidate) === preferred
        || localText.includes(`ending in ${preferred}`)
        || new RegExp(`\\b${preferred}\\b`).test(localText);
    });
    if (radio) return radio;
  }
  return radios.find((radio) => radio.checked) || radios[0];
}

function paymentRadioIsSelected(radio) {
  if (!radio) return false;
  if (radio.checked) return true;
  const row = paymentRowForRadio(radio);
  const text = normalizedText(row?.innerText || row?.textContent || "");
  return /\bselected\b/i.test(text) && /\bending\s+in\s+\d{4}\b/i.test(text);
}

async function clickPaymentRadio(radio) {
  const row = paymentRowForRadio(radio);
  const rowText = normalizedText(row?.innerText || row?.textContent || "");
  const preferredDigits = cardDigitsForPaymentRadio(radio);
  const textTargets = preferredDigits
    ? [...row?.querySelectorAll?.("span, div, label, input, button, a") || []].filter((element) => {
      const text = normalizedText(element.innerText || element.textContent || element.getAttribute?.("aria-label") || "");
      return text.includes(preferredDigits) || text.match(new RegExp(`ending\\s+in\\s+${preferredDigits}`, "i"));
    })
    : [];
  const targets = [
    radio.closest?.("label"),
    row?.querySelector?.("label"),
    ...textTargets,
    row?.querySelector?.(".pmts-instrument-box, .a-box-inner, .a-radio, [role='radio']"),
    row,
    radio,
  ].filter(Boolean);

  for (const target of targets) {
    const targetText = normalizedText(target.innerText || target.textContent || target.getAttribute?.("aria-label") || "");
    if (preferredDigits && target !== radio && targetText && !targetText.includes(preferredDigits) && !rowText.includes(preferredDigits)) {
      continue;
    }
    try {
      await clickElement(target, "Payment method row");
      await sleep(500);
      if (paymentRadioIsSelected(radio)) return true;
    } catch (err) {
      // Try the next candidate; Amazon often hides the real radio and binds the row instead.
    }
  }

  try {
    radio.checked = true;
    radio.dispatchEvent(new Event("input", { bubbles: true }));
    radio.dispatchEvent(new Event("change", { bubbles: true }));
    radio.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    await sleep(800);
  } catch (err) {
    // Ignore and let the caller decide whether manual checkout is needed.
  }
  return paymentRadioIsSelected(radio);
}

function findPaymentSelection(preferences = []) {
  const radio = findPaymentRadioForPreferences(preferences);
  if (!radio) return null;

  const paymentRoot = paymentRowForRadio(radio)?.closest?.(
    "form, [data-testid*='pay'], [data-csa-c-slot-id*='payselect'], [data-pmts-component-id], .pmts-portal-component, body",
  ) || document;
  const exactContinue = [...document.querySelectorAll(
    [
      "input[data-csa-c-slot-id*='continue-payselect']",
      "button[data-csa-c-slot-id*='continue-payselect']",
      "input[data-testid='bottom-continue-button'][data-csa-c-slot-id*='payselect']",
      "input[data-testid='secondary-continue-button'][data-csa-c-slot-id*='payselect']",
      "button[data-testid='bottom-continue-button'][data-csa-c-slot-id*='payselect']",
      "button[data-testid='secondary-continue-button'][data-csa-c-slot-id*='payselect']",
      "input[name='ppw-widgetEvent:SetPaymentPlanSelectContinueEvent']",
      "input[name='ppw-widgetEvent:SetPaymentPlanContinueEvent']",
      "input[aria-labelledby*='continue']",
    ].join(", "),
  )]
    .find((element) => visible(element) && !element.disabled);
  if (exactContinue) return { radio, continueButton: exactContinue };

  const continueButton = [...paymentRoot.querySelectorAll("input[type='submit'], input[type='button'], button, span.a-button")].find((element) => {
    const text = normalizedText(element.value || element.innerText || element.textContent);
    return visible(element) && !element.disabled && (
      text.includes("use this payment method") ||
      text.includes("use this card") ||
      text === "continue" ||
      text.includes("continue")
    );
  });
  return radio && continueButton ? { radio, continueButton } : null;
}

function findChangePaymentButton() {
  return [...document.querySelectorAll(
    [
      "a[data-csa-c-slot-id='checkout-change-payselect']",
      "a[data-topage='payselect']",
      "a[href*='/checkout/'][href*='/pay']",
      "a[href*='ref_=chk_spc_chg_payselect']",
      "button",
      "a",
    ].join(", "),
  )].find((element) => {
    const href = String(element.getAttribute?.("href") || element.href || "").toLowerCase();
    const text = normalizedText(element.getAttribute?.("aria-label") || element.innerText || element.textContent);
    return visible(element) && !element.disabled && (
      element.getAttribute?.("data-csa-c-slot-id") === "checkout-change-payselect" ||
      element.getAttribute?.("data-topage") === "payselect" ||
      href.includes("/pay") && href.includes("checkout") ||
      text.includes("change payment method")
    );
  });
}

function findAddNewDeliveryAddressLink() {
  return [...document.querySelectorAll(
    [
      "#add-new-address-popover-link",
      "a[data-csa-c-slot-id='add-new-address-non-mobile-tango-sasp']",
      "a",
      "button",
      "span.a-button",
    ].join(", "),
  )].find((element) => {
    const text = normalizedText(element.getAttribute?.("aria-label") || element.innerText || element.textContent);
    return visible(element) && !element.disabled && text.includes("add a new delivery address");
  });
}

function findPlaceOrderButton() {
  const selectors = [
    "input#placeOrder",
    "input[name='placeYourOrder1']",
    "input[data-testid='SPC_selectPlaceOrder']",
    "input[data-csa-c-slot-id='checkout-place-your-order-button']",
    "input.place-your-order-button",
    "input[title='Place your order']",
    "input[value='Place your order']",
    "button",
    "span.a-button",
  ].join(", ");
  return [...document.querySelectorAll(selectors)].find((element) => {
    const labelledBy = element.getAttribute?.("aria-labelledby");
    const labelText = labelledBy ? document.getElementById(labelledBy)?.textContent : "";
    const text = normalizedText(element.value || element.title || element.innerText || element.textContent || labelText);
    return visible(element) && !element.disabled && (
      element.matches?.("input#placeOrder, input[name='placeYourOrder1'], input[data-testid='SPC_selectPlaceOrder'], input[data-csa-c-slot-id='checkout-place-your-order-button'], input.place-your-order-button") ||
      text.includes("place your order")
    );
  });
}

function checkoutQuantityFromPage() {
  const text = (document.body.innerText || document.body.textContent || "").replace(/\s+/g, " ");
  const deleteStepperMatch = text.match(/(?:minimum quantity reached,\s*delete item|delete item)\s+(\d+)\s+\1\s+increase item quantity/i);
  if (deleteStepperMatch) return Number(deleteStepperMatch[1]);
  const quantityMatch = text.match(/\bquantity\s*:?\s*(\d+)\b/i);
  return quantityMatch ? Number(quantityMatch[1]) : 0;
}

function checkoutIncreaseQuantityButton() {
  return [...document.querySelectorAll("button, input[type='button'], input[type='submit'], a, span.a-button")]
    .find((element) => {
      const label = normalizedText(element.getAttribute?.("aria-label") || element.value || element.title || element.innerText || element.textContent);
      return visible(element) && !element.disabled && label.includes("increase item quantity");
    });
}

function expectedSubscribeCheckoutQuantity(activeJob) {
  if (!activeJob?.subscribeAndSave) return 0;
  const pricedQuantities = Object.values(activeJob.pricing || {})
    .map((item) => Number(item.quantity || 0))
    .filter((quantity) => quantity > 0);
  if (pricedQuantities.length) return Math.max(...pricedQuantities);
  const activeItem = activeJob.job?.items?.[Number(activeJob.itemIndex || 0)];
  return Number(activeItem?.quantity || 0);
}

async function ensureSubscribeCheckoutQuantity(activeJob) {
  const expected = expectedSubscribeCheckoutQuantity(activeJob);
  if (expected <= 1) return true;
  let current = checkoutQuantityFromPage();
  if (!current || current >= expected) return true;
  showPanel("Nutricity checkout", `Checkout shows Subscribe & Save quantity ${current}; increasing to ${expected}.`, null, null);
  for (let index = current; index < expected; index += 1) {
    const increase = checkoutIncreaseQuantityButton();
    if (!increase) break;
    await clickElement(increase, "Increase checkout item quantity");
    await sleep(1200);
    current = checkoutQuantityFromPage() || current + 1;
    if (current >= expected) break;
  }
  current = checkoutQuantityFromPage() || current;
  if (current >= expected) {
    showPanel("Nutricity checkout", `Verified Subscribe & Save checkout quantity ${current}.`, null, null);
    return true;
  }
  await pauseForManualCheckout(activeJob, `Checkout still shows Subscribe & Save quantity ${current || "unknown"} instead of ${expected}.`);
  return false;
}

function findBusinessContinueCheckoutButton() {
  return [...document.querySelectorAll(
    "a[name='checkout-byg-ptc-button'], a[href*='/checkout/entry/cart/amazon_business'], a[href*='proceedToCheckout=1'], button, input[type='submit'], input[type='button'], span.a-button",
  )].find((element) => {
    const href = String(element.getAttribute?.("href") || element.href || "").toLowerCase();
    const text = normalizedText(element.value || element.innerText || element.textContent);
    return visible(element) && !element.disabled && (
      element.getAttribute?.("name") === "checkout-byg-ptc-button" ||
      href.includes("/checkout/entry/cart/amazon_business") ||
      (href.includes("proceedtocheckout=1") && text.includes("continue to checkout"))
    );
  });
}

async function handleBusinessCheckoutInterstitial() {
  const continueCheckout = findBusinessContinueCheckoutButton();
  if (!continueCheckout) return false;
  showPanel("Nutricity checkout", "Continuing through Amazon Business checkout.", null, null);
  await clickElement(continueCheckout, "Amazon Business continue to checkout button");
  await sleep(1500);
  return true;
}

async function handlePaymentSelection(activeJob) {
  try {
    const state = await getExtensionState();
    const cardPreferences = cardPreferenceList(state.cardLast4Preference);
    let payment = findPaymentSelection(cardPreferences);
    if (!payment) {
      if (!findPaymentRadio()) return false;
      payment = await waitUntil(() => findPaymentSelection(cardPreferences), 5000);
      if (!payment) {
        await pauseForManualCheckout(activeJob, "Amazon is asking for a payment method, but I could not find the payment Continue button.");
        return true;
      }
    }
    const selectedDigits = cardDigitsForPaymentRadio(payment.radio);
    showPanel("Nutricity checkout", selectedDigits ? `Selecting card ending in ${selectedDigits}.` : "Selecting Amazon payment method.", null, null);
    if (!paymentRadioIsSelected(payment.radio)) {
      await clickPaymentRadio(payment.radio);
      await waitUntil(() => paymentRadioIsSelected(payment.radio), 3000, 250);
    }
    if (cardPreferences.length && selectedDigits && !cardPreferences.includes(selectedDigits)) {
      await pauseForManualCheckout(activeJob, `Could not find preferred card ending in ${cardPreferences.join(" or ")}.`);
      return true;
    }
    if (cardPreferences.length && !paymentRadioIsSelected(payment.radio)) {
      await pauseForManualCheckout(activeJob, `Could not select preferred card ending in ${cardPreferences.join(" or ")}.`);
      return true;
    }
    await clickElement(payment.continueButton, "Use this payment method button");
    showPanel("Nutricity checkout", "Payment method selected. Waiting for checkout.", null, null);
    await waitUntil(
      () => checkoutPaymentConfirmed(cardPreferences)
        || (!cardPreferences.length && findPlaceOrderButton())
        || !findPaymentRadio(),
      12000,
      400,
    );
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
    const confirmedDigits = checkoutSelectedCardDigits();
    if (confirmedDigits) {
      showPanel("Nutricity checkout", `Verified checkout card ending in ${confirmedDigits}.`, null, null);
    }
    return true;
  } catch (error) {
    await pauseForManualCheckout(activeJob, `Payment selection got stuck: ${error.message || error}`);
    return true;
  }
}

async function openPaymentSelectionIfAvailable() {
  const changePayment = await waitUntil(findChangePaymentButton, 6000, 400);
  if (!changePayment) return false;
  showPanel("Nutricity checkout", "Opening payment method selection.", null, null);
  await clickElement(changePayment, "Change payment method button");
  await sleep(2000);
  return true;
}

async function ensurePreferredCheckoutPayment(activeJob) {
  const state = await getExtensionState();
  const cardPreferences = cardPreferenceList(state.cardLast4Preference);
  if (!cardPreferences.length) {
    if (checkoutPaymentConfirmed(cardPreferences)) {
      showPanel("Nutricity checkout", "Verified checkout payment method.", null, null);
    }
    return true;
  }
  const paymentPanel = findCheckoutPaymentPanel();
  const selectedDigits = checkoutSelectedCardDigits();
  if (!paymentPanel && !selectedDigits && !findPlaceOrderButton() && !findChangePaymentButton()) return true;

  if (selectedDigits && cardPreferences.includes(selectedDigits)) {
    showPanel("Nutricity checkout", `Verified checkout card ending in ${selectedDigits}.`, null, null);
    return true;
  }

  const settledDigits = await waitForPreferredCheckoutPayment(cardPreferences, 5000);
  if (settledDigits && settledDigits !== true) {
    showPanel("Nutricity checkout", `Verified checkout card ending in ${settledDigits}.`, null, null);
    return true;
  }

  const expected = cardPreferences.join(" or ");
  if (selectedDigits) {
    showPanel("Nutricity checkout", `Checkout shows card ending in ${selectedDigits}; switching to ${expected}.`, null, null);
  } else {
    showPanel("Nutricity checkout", `Could not verify checkout card; opening payment selection for ${expected}.`, null, null);
  }

  if (await waitUntil(findPaymentRadio, 10000, 400)) {
    await handlePaymentSelection(activeJob);
    if (activeJob.paused) return false;
    await waitUntil(() => checkoutPaymentConfirmed(cardPreferences), 15000, 400);
    const confirmedDigits = checkoutSelectedCardDigits();
    if (confirmedDigits && cardPreferences.includes(confirmedDigits)) {
      showPanel("Nutricity checkout", `Verified checkout card ending in ${confirmedDigits}.`, null, null);
      return true;
    }
    await pauseForManualCheckout(
      activeJob,
      confirmedDigits
        ? `Amazon still shows card ending in ${confirmedDigits} after payment selection; expected ${expected}.`
        : `Amazon did not confirm the selected card ending in ${expected}.`,
    );
    return false;
  }

  if (!await openPaymentSelectionIfAvailable()) {
    const lateDigits = await waitForPreferredCheckoutPayment(cardPreferences, 8000);
    if (lateDigits && lateDigits !== true) {
      showPanel("Nutricity checkout", `Verified checkout card ending in ${lateDigits}.`, null, null);
      return true;
    }
    await pauseForManualCheckout(activeJob, selectedDigits
      ? `Checkout shows card ending in ${selectedDigits}, but I could not find the Change payment method link to switch to ${expected}.`
      : `Could not verify the checkout card, and I could not find the Change payment method link to select ${expected}.`);
    return false;
  }
  if (await waitUntil(findPaymentRadio, 10000, 400)) {
    await handlePaymentSelection(activeJob);
    if (activeJob.paused) return false;
    await waitUntil(() => checkoutPaymentConfirmed(cardPreferences), 15000, 400);
    const confirmedDigits = checkoutSelectedCardDigits();
    if (confirmedDigits && cardPreferences.includes(confirmedDigits)) {
      showPanel("Nutricity checkout", `Verified checkout card ending in ${confirmedDigits}.`, null, null);
      return true;
    }
    await pauseForManualCheckout(
      activeJob,
      confirmedDigits
        ? `Amazon still shows card ending in ${confirmedDigits} after payment selection; expected ${expected}.`
        : `Amazon did not confirm the selected card ending in ${expected}.`,
    );
    return false;
  }
  await pauseForManualCheckout(activeJob, `Opened payment selection, but Amazon did not show card choices for ${expected}.`);
  return false;
}

async function openAddressEditorIfAvailable(activeJob) {
  const directEditor = findAddressNameInput();
  if (directEditor) return directEditor;

  let editAddress = await waitUntil(findEditAddressTrigger, 6000, 400);
  if (!editAddress) {
    const changeAddress = findChangeDeliveryAddressButton();
    if (changeAddress) {
      showPanel("Nutricity checkout", "Opening delivery address selection.", null, null);
      activeJob.stage = "editing_address";
      activeJob.editAddressClickedAt = Date.now();
      await setActiveJob(activeJob);
      await clickElement(changeAddress, "Change delivery address link");
      await sleep(2000);
      editAddress = await waitUntil(findEditAddressTrigger, 10000, 400);
      if (!editAddress && findAddressNameInput()) return findAddressNameInput();
    }
  }

  if (!editAddress) return null;
  await selectAddressRadioForElement(editAddress);
  showPanel("Nutricity checkout", "Opening Amazon address editor.", null, null);
  activeJob.stage = "editing_address";
  activeJob.editAddressClickedAt = Date.now();
  await setActiveJob(activeJob);
  await clickElement(editAddress, "Edit address link");
  await waitForElement([
    "#address-ui-widgets-enterAddressFullName",
    "input[name='address-ui-widgets-enterAddressFullName']",
    "input[aria-label='Full name']",
    "input[name*='FullName']",
    "input[id*='FullName']",
  ], 8000);
  return findAddressNameInput();
}

async function openNewDeliveryAddressFormIfAvailable(activeJob) {
  const directEditor = findAddressNameInput();
  if (directEditor) return directEditor;

  let addNewAddress = findAddNewDeliveryAddressLink();
  if (!addNewAddress) {
    const changeAddress = findChangeDeliveryAddressButton();
    if (changeAddress) {
      showPanel("Nutricity checkout", "Opening delivery address selection.", null, null);
      activeJob.stage = "editing_address";
      activeJob.editAddressClickedAt = Date.now();
      await setActiveJob(activeJob);
      await clickElement(changeAddress, "Change delivery address link");
      await sleep(2000);
      addNewAddress = await waitUntil(findAddNewDeliveryAddressLink, 10000, 400);
    }
  }
  if (!addNewAddress) return null;

  showPanel("Nutricity checkout", "Opening new delivery address form.", null, null);
  activeJob.stage = "editing_address";
  activeJob.editAddressClickedAt = Date.now();
  await setActiveJob(activeJob);
  await clickElement(addNewAddress, "Add a new delivery address link");
  await waitForElement([
    "#address-ui-widgets-enterAddressFullName",
    "input[name='address-ui-widgets-enterAddressFullName']",
    "#address-ui-widgets-enterAddressPhoneNumber",
    "#address-ui-widgets-enterAddressLine1",
  ], 10000);
  return findAddressNameInput();
}

function manualNextStage(activeJob, requestedStage = "") {
  if (requestedStage) return requestedStage;
  const stage = String(activeJob?.stage || "");
  if (stage === "clear_cart") return "product";
  if (stage === "product") return "add_clicked";
  if (stage === "add_clicked") return "navigate_next";
  if (stage === "subscribe_checkout") return "checkout";
  if (stage === "cart") return "checkout";
  if (stage === "editing_address") return "checkout";
  if (stage === "complete_pending") return "find_order_id";
  return stage || "product";
}

async function continueAfterManualStep(activeJob, nextStage = "") {
  const latest = await getActiveJob();
  const next = { ...(latest || activeJob), paused: false, pausedStage: null };
  const targetStage = manualNextStage(next, nextStage);
  if (targetStage === "navigate_next") {
    showPanel("Nutricity fulfilment", "Manual step done. Moving to the next item.", null, null);
    await navigateToNext(next);
    setTimeout(runSafely, 250);
    return;
  }
  if (targetStage === "product") {
    next.itemIndex = Number(next.itemIndex || 0);
    next.cartCleared = true;
  }
  if (targetStage === "add_clicked") {
    next.addClickedAt = Date.now();
    markItemAdded(next);
  }
  next.stage = targetStage;
  await setActiveJob(next);
  showPanel("Nutricity fulfilment", `Manual step done. Continuing ${targetStage}.`, null, null);
  setTimeout(runSafely, 250);
}

async function pauseForManualCheckout(activeJob, message, nextStage = "checkout") {
  activeJob.pausedStage = activeJob.stage || "checkout";
  activeJob.stage = activeJob.pausedStage;
  activeJob.paused = true;
  await setActiveJob(activeJob);
  showPanel(
    "Nutricity checkout needs attention",
    `${message} Make the needed Amazon checkout change, then click Resume to retry this step.`,
    "I did it manually, continue",
    () => continueAfterManualStep(activeJob, nextStage),
  );
}

async function saveEditedAddress(activeJob, checkoutRecipient) {
  showPanel("Nutricity checkout", "Editing Amazon address name.", null, null);
  const filled = await fillFullName(checkoutRecipient);
  if (!filled) return false;

  showPanel("Nutricity checkout", "Saving Amazon address.", null, null);
  await sleep(1000);
  const useAddress = await waitUntil(findUseAddressButton, 8000) || findButtonByText(["use this address", "save address", "continue"]);
  if (!useAddress) {
    await pauseForManualCheckout(activeJob, "Could not find the Use this address button.");
    return false;
  }
  await clickUseAddressButton(useAddress);
  await waitUntil(
    () => checkoutRecipientConfirmed(checkoutRecipient) || findPlaceOrderButton() || findPaymentSelection() || !findAddressNameInput(),
    9000,
    250,
  );
  if (checkoutRecipientConfirmed(checkoutRecipient)) {
    return markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Verified edited delivery address. Continuing checkout.");
  }
  if (findPlaceOrderButton() && checkoutShowsRecipient(checkoutRecipient)) {
    return markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Checkout address panel shows the edited recipient. Continuing checkout.");
  }
  await sleep(1000);

  const recipientAddressControl = await waitUntil(() => !findAddressNameInput() && recipientAddressSelectionControl(checkoutRecipient), 10000, 300);
  if (recipientAddressControl) {
    showPanel("Nutricity checkout", "Selecting the recipient delivery address.", null, null);
    await clickElement(recipientAddressControl, "Recipient address row");
  }

  const deliverToThisAddress = await waitUntil(findDeliverToThisAddressButton, 5000, 300);
  if (deliverToThisAddress) {
    if (!recipientAddressControl && !checkoutShowsRecipient(checkoutRecipient)) {
      await pauseForManualCheckout(activeJob, `Could not find the edited address row for "${checkoutRecipient}" after saving.`);
      return false;
    }
    showPanel("Nutricity checkout", "Selecting edited delivery address.", null, null);
    await clickElement(deliverToThisAddress, "Deliver to this address button");
    await sleep(1200);
    if (checkoutRecipientConfirmed(checkoutRecipient)) {
      return markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Verified edited delivery address. Continuing checkout.");
    }
  }

  showPanel("Nutricity checkout", "Waiting for checkout to update.", null, null);
  await waitUntil(
    () =>
      checkoutLimitPurchaseIssue(activeJob) ||
      checkoutRecipientConfirmed(checkoutRecipient) ||
      findPaymentSelection() ||
      findPlaceOrderButton() ||
      !findAddressNameInput(),
    5000,
    250,
  );
  if (await handleCheckoutLimitPurchase(activeJob)) return true;
  if (checkoutRecipientConfirmed(checkoutRecipient)) {
    return markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Verified edited delivery address. Continuing checkout.");
  }
  activeJob.stage = "checkout";
  activeJob.editAddressClickedAt = null;
  activeJob.addressEditedRecipient = checkoutRecipient;
  activeJob.addressEditedAt = Date.now();
  await setActiveJob(activeJob);
  await pauseForManualCheckout(activeJob, `Amazon did not confirm delivery address "${checkoutRecipient}" after saving.`);
  return false;
}

async function saveNewDeliveryAddress(activeJob, checkoutRecipient) {
  if (!findAddressNameInput() && !await openNewDeliveryAddressFormIfAvailable(activeJob)) {
    await pauseForManualCheckout(activeJob, "Could not find the Add a new delivery address link.");
    return false;
  }

  showPanel("Nutricity checkout", "Adding Amazon delivery address.", null, null);
  const filled = await fillNewDeliveryAddress(checkoutRecipient);
  if (!filled) {
    await pauseForManualCheckout(activeJob, "Could not fill the new delivery address form.");
    return false;
  }

  showPanel("Nutricity checkout", "Saving new Amazon address.", null, null);
  await sleep(1000);
  const useAddress = await waitUntil(findUseAddressButton, 8000) || findButtonByText(["use this address", "save address", "continue"]);
  if (!useAddress) {
    await pauseForManualCheckout(activeJob, "Could not find the Use this address button.");
    return false;
  }
  await clickUseAddressButton(useAddress);
  await sleep(3000);

  const deliverToThisAddress = await waitUntil(findDeliverToThisAddressButton, 5000, 300);
  if (deliverToThisAddress) {
    showPanel("Nutricity checkout", "Selecting new delivery address.", null, null);
    await clickElement(deliverToThisAddress, "Deliver to this address button");
    await sleep(1200);
    if (checkoutRecipientConfirmed(checkoutRecipient)) {
      await markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Verified new delivery address. Continuing checkout.");
      activeJob.addressMode = "new";
      await setActiveJob(activeJob);
      return true;
    }
  }

  await waitUntil(
    () => checkoutRecipientConfirmed(checkoutRecipient) || findPaymentSelection() || findPlaceOrderButton() || !findAddressNameInput(),
    5000,
    250,
  );
  if (checkoutRecipientConfirmed(checkoutRecipient)) {
    await markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, "Verified new delivery address. Continuing checkout.");
    activeJob.addressMode = "new";
    await setActiveJob(activeJob);
    return true;
  }
  activeJob.stage = "checkout";
  activeJob.editAddressClickedAt = null;
  activeJob.addressEditedRecipient = checkoutRecipient;
  activeJob.addressEditedAt = Date.now();
  activeJob.addressMode = "new";
  await setActiveJob(activeJob);
  return true;
}

async function verifyCheckoutDeliveryRecipient(activeJob, checkoutRecipient) {
  const deliveredTo = checkoutDeliveryRecipientText();
  if (!deliveredTo) return true;
  if (checkoutDeliveryRecipientMatches(checkoutRecipient)) {
    activeJob.addressVerifiedRecipient = checkoutRecipient;
    activeJob.addressVerifiedAt = Date.now();
    activeJob.addressVerifyAttempts = 0;
    await setActiveJob(activeJob);
    return true;
  }

  const attempts = Number(activeJob.addressVerifyAttempts || 0) + 1;
  activeJob.addressVerifyAttempts = attempts;
  activeJob.addressVerifiedRecipient = "";
  await setActiveJob(activeJob);
  if (attempts > 2) {
    await pauseForManualCheckout(
      activeJob,
      `Delivery name still shows "${deliveredTo}" instead of "${checkoutRecipient}".`,
    );
    return false;
  }

  const changeAddress = findChangeDeliveryAddressButton();
  if (!changeAddress) {
    await pauseForManualCheckout(
      activeJob,
      `Delivery name shows "${deliveredTo}" instead of "${checkoutRecipient}", and I could not find the Change delivery address link.`,
    );
    return false;
  }
  showPanel("Nutricity checkout", `Delivery name shows ${deliveredTo}. Reopening address edit.`, null, null);
  activeJob.stage = "editing_address";
  activeJob.editAddressClickedAt = Date.now();
  await setActiveJob(activeJob);
  await clickElement(changeAddress, "Change delivery address link");
  return false;
}

async function handleCheckoutLimitPurchase(activeJob) {
  const issue = checkoutLimitPurchaseIssue(activeJob);
  if (!issue) return false;
  const item = issue.item;
  const asin = item?.asin || "";
  const requestedQuantity = Number(item?.quantity || 0) || null;
  const availableQuantity = Number.isFinite(Number(issue.currentQuantity))
    ? Number(issue.currentQuantity)
    : 0;
  const message = asin
    ? `${issue.message} ASIN ${asin}${issue.title ? ` (${issue.title})` : ""}.${requestedQuantity ? ` Customer ordered ${requestedQuantity}, Amazon checkout allows ${availableQuantity}.` : ""}`
    : `${issue.message}${issue.title ? ` ${issue.title}.` : ""}`;

  if (item && (activeJob.job?.items || []).length > 1 && await shouldFulfilAvailableMixedAsin(activeJob)) {
    showPanel("Limit purchase", message, null, null);
    const result = await send({
      type: "MARK_LINE_MISSING",
      message,
      missingAsin: asin,
      missingLineId: itemPrimaryLineId(item),
      failureCode: "partial_quantity",
      requestedQuantity,
      fulfilledQuantity: availableQuantity,
      availableQuantity,
    });
    if (!result?.ok) {
      await pauseForManualCheckout(activeJob, `${message} I could not report this line to the app.`);
      return true;
    }
    removeMissingItemFromActiveJob(activeJob, item, item);
    activeJob.stage = "checkout";
    await setActiveJob(activeJob);
    if (issue.removeButton) {
      await clickElement(issue.removeButton, "Remove limited purchase item");
      await sleep(1800);
    }
    const continueButton = await waitUntil(findUseAddressButton, 3000, 300)
      || findButtonByText(["continue"]);
    if (continueButton) {
      await clickElement(continueButton, "Continue after removing limited purchase item");
      await sleep(2500);
    }
    showPanel("Split fulfilment", `${message} Remaining item(s) will continue.`, null, null);
    return true;
  }

  showPanel("Limit purchase", message, null, null);
  await send({
    type: "FAIL_JOB",
    message,
    missingAsin: asin,
    missingLineId: item ? itemPrimaryLineId(item) : null,
    failureCode: "partial_quantity",
    requestedQuantity,
    fulfilledQuantity: availableQuantity,
    availableQuantity,
  });
  showPanel("Missing ASINs", `${message} Order moved to Missing ASINs.`, null, null);
  return true;
}

async function handleCheckout(activeJob) {
  await waitForElement([
    "#placeOrder",
    "input.place-your-order-button",
    "#checkout-javaItemSelectPanel",
    "[data-checkout-view-modal]",
    "#checkout-primary-continue-button-id",
    "input[aria-label='Full name']",
    "input[type='radio'][name='addressID']",
    "input[type='radio'][aria-label*='Nutricity' i]",
    "input[type='radio'][aria-label*='United States' i]",
    "#ab-select-address-continue-button-bottom",
    "input[data-testid='ab-select-address-continue-button-bottom']",
    "input[type='radio'][name='ppw-instrumentRowSelection']",
    "input[data-csa-c-slot-id*='continue-payselect']",
    "a[name='checkout-byg-ptc-button']",
    "a[href*='/checkout/entry/cart/amazon_business']",
    "a[href*='proceedToCheckout=1']",
  ], 18000);
  if (await handleBusinessCheckoutInterstitial()) return;
  if (await handleCheckoutLimitPurchase(activeJob)) return;
  const checkoutRecipient = recipientName(activeJob);
  const extensionState = await getExtensionState();
  const shouldEditExistingAddress = extensionState.editExistingAddress !== false;
  showPanel("Nutricity checkout", `Using recipient name: ${checkoutRecipient}`, null, null);
  const readyPlaceOrder = findPlaceOrderButton();
  if (
    readyPlaceOrder &&
    !readyPlaceOrder.disabled &&
    !findAddressNameInput() &&
    checkoutRecipientConfirmed(checkoutRecipient) &&
    checkoutPaymentConfirmed(cardPreferenceList(extensionState.cardLast4Preference))
  ) {
    activeJob.stage = "checkout";
    activeJob.paused = false;
    activeJob.pausedStage = null;
    activeJob.editAddressClickedAt = null;
    activeJob.addressEditedRecipient = checkoutRecipient;
    activeJob.addressEditedAt = Date.now();
    activeJob.addressVerifiedRecipient = checkoutRecipient;
    activeJob.addressVerifiedAt = Date.now();
    await setActiveJob(activeJob);
    showPanel("Nutricity checkout", "Checkout is ready. Placing the order.", null, null);
  }
  if (activeJob.stage === "editing_address") {
    if (!findAddressNameInput() && checkoutRecipientConfirmed(checkoutRecipient)) {
      await markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, `Delivery address already shows ${checkoutRecipient}. Continuing checkout.`);
    } else
    if (shouldEditExistingAddress && !findAddressNameInput()) {
      await openAddressEditorIfAvailable(activeJob);
    } else if (!shouldEditExistingAddress && !findAddressNameInput()) {
      await openNewDeliveryAddressFormIfAvailable(activeJob);
    }
    if (checkoutRecipientConfirmed(checkoutRecipient)) {
      await markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, `Delivery address shows ${checkoutRecipient}. Continuing checkout.`);
    } else if (shouldEditExistingAddress ? await saveEditedAddress(activeJob, checkoutRecipient) : await saveNewDeliveryAddress(activeJob, checkoutRecipient)) {
      // Continue in this same pass so checkout can place the order without waiting for the next interval.
    } else if (Date.now() - Number(activeJob.editAddressClickedAt || 0) > 45000) {
      activeJob.stage = "checkout";
      activeJob.editAddressClickedAt = null;
      await setActiveJob(activeJob);
    } else {
      showPanel("Nutricity checkout", "Waiting for Amazon address editor.", null, null);
      return;
    }
  }
  const continueCheckout = findBusinessContinueCheckoutButton() || findButtonByText(["continue to checkout"]);
  if (continueCheckout) {
    await clickElement(continueCheckout, "Continue to checkout button");
    return;
  }

  let handledPayment = false;
  if (findPaymentRadio()) {
    handledPayment = await handlePaymentSelection(activeJob);
    if (handledPayment) {
      showPanel("Nutricity checkout", "Payment confirmed. Changing address after payment.", null, null);
    }
    if (activeJob.paused) return;
  }

  const addressAlreadyConfirmed = checkoutRecipientConfirmed(checkoutRecipient);
  if (addressAlreadyConfirmed) {
    await markCheckoutRecipientConfirmed(activeJob, checkoutRecipient, `Verified delivery address for ${checkoutRecipient}.`);
  }
  const addressEditIsFresh = addressAlreadyConfirmed || activeJob.addressEditedRecipient === checkoutRecipient && Date.now() - Number(activeJob.addressEditedAt || 0) < 30000;
  if (!addressEditIsFresh) {
    if (shouldEditExistingAddress) {
      const addressRow = nutricityAddressRow();
      if (addressRow) {
        addressRow.scrollIntoView({ block: "center", behavior: "smooth" });
        await sleep(250);
      }
      const addressEditor = await openAddressEditorIfAvailable(activeJob);
      if (addressEditor) {
        if (await saveEditedAddress(activeJob, checkoutRecipient)) {
          // Continue below to place the order immediately when Amazon has returned to checkout.
        } else {
          return;
        }
      } else {
        await pauseForManualCheckout(activeJob, "Could not find the Change delivery address or Edit address link for the Nutricity address.");
        return;
      }
    } else {
      const addressEditor = await openNewDeliveryAddressFormIfAvailable(activeJob);
      if (!addressEditor) {
        await pauseForManualCheckout(activeJob, "Could not find the Add a new delivery address link.");
        return;
      }
      if (!await saveNewDeliveryAddress(activeJob, checkoutRecipient)) return;
    }
  } else {
    showPanel("Nutricity checkout", "Recipient address edit saved. Continuing checkout.", null, null);
  }

  if (!await verifyCheckoutDeliveryRecipient(activeJob, checkoutRecipient)) return;

  if (!handledPayment && !checkoutRecipientConfirmed(checkoutRecipient) && !findPlaceOrderButton() && await fillFullName(checkoutRecipient)) {
    await sleep(1200);
    const useAddress = await waitUntil(findUseAddressButton, 8000) || findButtonByText(["use this address", "save address", "deliver to this address", "continue"]);
    if (useAddress) {
      await sleep(1000);
      await clickUseAddressButton(useAddress);
      await sleep(3000);
      await waitUntil(() => checkoutRecipientConfirmed(checkoutRecipient) || findPaymentSelection() || findPlaceOrderButton(), 10000);
    } else {
      await pauseForManualCheckout(activeJob, "Could not find the Use this address button.");
      return;
    }
  }

  if (!handledPayment && findPaymentRadio() && await handlePaymentSelection(activeJob)) {
    handledPayment = true;
    // Continue below to place the order if Amazon exposed the final button.
  }
  if (activeJob.paused) return;

  if (!await verifyCheckoutDeliveryRecipient(activeJob, checkoutRecipient)) return;
  const deliverToThisAddress = findDeliverToThisAddressButton();
  if (deliverToThisAddress && !findPaymentRadio() && !findPlaceOrderButton() && !findChangePaymentButton()) {
    showPanel("Nutricity checkout", "Delivery address is selected. Continuing to payment review.", null, null);
    await clickElement(deliverToThisAddress, "Deliver to this address button");
    return;
  }
  if (!await ensurePreferredCheckoutPayment(activeJob)) return;
  if (!await ensureSubscribeCheckoutQuantity(activeJob)) return;

  const placeOrder = await waitUntil(findPlaceOrderButton, 20000, 500)
    || await waitForElement([
      "input#placeOrder:not([disabled])",
      "input[name='placeYourOrder1']:not([disabled])",
      "input[data-testid='SPC_selectPlaceOrder']:not([disabled])",
      "input[data-csa-c-slot-id='checkout-place-your-order-button']:not([disabled])",
      "input.place-your-order-button:not([disabled])",
    ], 5000)
    || findButtonByText(["place your order"]);
  if (placeOrder && !placeOrder.disabled) {
    if (!checkoutDeliveryRecipientMatches(checkoutRecipient)) {
      const deliveredTo = checkoutDeliveryRecipientText() || "unknown recipient";
      await pauseForManualCheckout(
        activeJob,
        `Final checkout still shows delivery to "${deliveredTo}" instead of "${checkoutRecipient}".`,
      );
      return;
    }
    const finalCardPreferences = cardPreferenceList((await getExtensionState()).cardLast4Preference);
    const finalDigits = checkoutSelectedCardDigits();
    if (finalCardPreferences.length && (!finalDigits || !finalCardPreferences.includes(finalDigits))) {
      await pauseForManualCheckout(
        activeJob,
        finalDigits
          ? `Final checkout still shows card ending in ${finalDigits}; expected ${finalCardPreferences.join(" or ")}.`
          : `Final checkout did not show the preferred card ending in ${finalCardPreferences.join(" or ")}.`,
      );
      return;
    }
    const duplicateCheck = await send({ type: "CHECK_EXISTING_AMAZON_ORDER" });
    if (!duplicateCheck?.ok) {
      activeJob.paused = true;
      activeJob.pausedStage = "checkout";
      await setActiveJob(activeJob);
      showPanel(
        "Duplicate check failed",
        duplicateCheck?.message || "Could not confirm whether an Amazon order already exists in the app. Fulfilment is paused before placing the order.",
        "Retry",
        () => continueAfterManualStep(activeJob, "checkout"),
      );
      return;
    }
    if (duplicateCheck?.duplicate) {
      const orders = (duplicateCheck.orders || []).map((item) => item.amazon_order_id).filter(Boolean).join(", ");
      showPanel(
        "Amazon order already exists",
        `${orders || "An Amazon order"} is already saved in the app. Open the extension popup to review it, copy the number, or clear it after confirming the Amazon order was cancelled.`,
        null,
        null,
      );
      return;
    }
    const rememberedOrder = await findRememberedDuplicateOrder(activeJob);
    if (rememberedOrder) {
      showPanel(
        "Amazon order already found",
        `Order history already shows ${rememberedOrder.amazon_order_id} for ${activeJob.job.recipient_name}. Reporting that order instead of placing again.`,
        null,
        null,
      );
      await reportAmazonOrders(activeJob, [rememberedOrder]);
      return;
    }
    showPanel("Final step", "Clicking Place your order now.", null, null);
    if (!await protectBeforeAmazonSubmit(activeJob, "checkout")) return;
    await clickElement(placeOrder, "Place your order button");
  } else {
    await pauseForManualCheckout(activeJob, "Could not find the payment or Place your order control.", "complete_pending");
  }
}

function extractOrderId() {
  const text = document.body.innerText || "";
  const patterns = [
    /order(?:\s*#|\s*number|\s*id)?\s*[:#]?\s*([0-9]{3}-[0-9]{7}-[0-9]{7})/i,
    /\b([0-9]{3}-[0-9]{7}-[0-9]{7})\b/,
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[1];
  }
  return "";
}

function confirmationSaysPlaced() {
  const text = (document.body.innerText || "").replace(/\s+/g, " ").toLowerCase();
  return text.includes("has been placed") || text.includes("your order") && text.includes("has been placed");
}

function recentOrdersLink() {
  return [...document.querySelectorAll("a")].find((link) => {
    const text = (link.innerText || link.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
    const href = link.getAttribute("href") || "";
    return visible(link) && (text.includes("review or edit your recent orders") || href.includes("order-history"));
  });
}

function orderHistoryUrl() {
  return "https://www.amazon.com/gp/your-account/order-history?ref_=chk_spc_place_order_recovery";
}

function isOrderHistoryPage() {
  return /\/(?:gp\/your-account\/order-history|gp\/css\/order-history)/i.test(location.pathname)
    || Boolean(document.querySelector("#yourOrderHistorySection, #yoOrdersTabination"));
}

function isOrderDetailsPage() {
  return /\/(?:your-orders\/order-details|gp\/your-account\/order-details)/i.test(location.pathname)
    || Boolean(new URLSearchParams(location.search).get("orderID") && document.querySelector("#orderDetails"));
}

function submittedStage(activeJob) {
  return ["complete_pending", "find_order_id", "reporting_complete"].includes(String(activeJob?.stage || ""));
}

function submittedOrPausedStage(activeJob) {
  return submittedStage(activeJob) || ["complete_pending", "find_order_id", "reporting_complete"].includes(String(activeJob?.pausedStage || ""));
}

function amazonOrderSubmitErrorPage() {
  const text = normalizedText(document.body?.innerText || document.body?.textContent || "");
  return /\/checkout\/.*\/place-order/i.test(location.pathname)
    && (text.includes("something went wrong") || text.includes("please go back and try again"));
}

function amazonDuplicateOrderPage() {
  const text = normalizedText(document.body?.innerText || document.body?.textContent || "");
  return /\/checkout\/.*\/duplicateOrder/i.test(location.pathname)
    || (text.includes("this is a pending order") && text.includes("do you want to place the same order again"));
}

async function protectBeforeAmazonSubmit(activeJob, retryStage = "checkout") {
  const result = await send({ type: "MARK_ORDER_SUBMITTED" });
  if (!result?.ok) {
    activeJob.paused = true;
    activeJob.pausedStage = retryStage;
    await setActiveJob(activeJob);
    showPanel(
      "Nutricity fulfilment paused",
      result?.message || "Could not protect this order before clicking Amazon Place your order. Fulfilment is paused to prevent a duplicate order.",
      "Retry",
      () => continueAfterManualStep(activeJob, retryStage),
    );
    return false;
  }
  activeJob.amazonSubmittedAt = activeJob.amazonSubmittedAt || Date.now();
  activeJob.stage = "complete_pending";
  activeJob.paused = false;
  activeJob.pausedStage = null;
  await setActiveJob(activeJob);
  return true;
}

async function handleAmazonDuplicateOrderPage(activeJob) {
  if (activeJob.amazonDuplicateOrderConfirmed) {
    await pauseForManualCheckout(
      activeJob,
      "Amazon is still showing the duplicate pending-order screen after it was already confirmed once.",
      "complete_pending",
    );
    return;
  }
  const duplicatePageIsAfterCheckoutSubmit =
    activeJob.stage === "complete_pending" ||
    activeJob.stage === "checkout" ||
    activeJob.pausedStage === "complete_pending" ||
    activeJob.pausedStage === "checkout" ||
    checkoutWasStarted(activeJob);
  if (!duplicatePageIsAfterCheckoutSubmit) {
    activeJob.paused = true;
    activeJob.pausedStage = activeJob.stage || "checkout";
    await setActiveJob(activeJob);
    showPanel(
      "Nutricity fulfilment paused",
      "Amazon showed the duplicate pending-order screen before the final order stage. Review it manually before continuing.",
      "I did it manually, continue",
      () => continueAfterManualStep(activeJob, "complete_pending"),
    );
    return;
  }
  activeJob.paused = false;
  activeJob.pausedStage = null;
  const duplicateCheck = await send({ type: "CHECK_EXISTING_AMAZON_ORDER" });
  if (duplicateCheck?.duplicate) {
    const orders = (duplicateCheck.orders || []).map((item) => item.amazon_order_id).filter(Boolean).join(", ");
    showPanel(
      "Amazon order already exists",
      `${orders || "An Amazon order"} is already saved in the app. Open the extension popup to review or clear it before continuing.`,
      null,
      null,
    );
    return;
  }
  const rememberedOrder = await findRememberedDuplicateOrder(activeJob);
  if (rememberedOrder) {
    showPanel(
      "Amazon order already found",
      `Order history already shows ${rememberedOrder.amazon_order_id} for ${activeJob.job.recipient_name}. Reporting that order instead of confirming the duplicate-order page.`,
      null,
      null,
    );
    await reportAmazonOrders(activeJob, [rememberedOrder]);
    return;
  }
  const placeOrder = findButtonByText(["place your order"]);
  if (!placeOrder || placeOrder.disabled) {
    await pauseForManualCheckout(activeJob, "Amazon duplicate pending-order screen did not show a usable Place your order button.", "complete_pending");
    return;
  }
  showPanel("Final step", "Amazon asked for duplicate-order confirmation. Clicking Place your order once.", null, null);
  if (!await protectBeforeAmazonSubmit(activeJob, "complete_pending")) return;
  activeJob.amazonDuplicateOrderConfirmed = true;
  activeJob.stage = "complete_pending";
  await setActiveJob(activeJob);
  await clickElement(placeOrder, "duplicate-order Place your order button");
}

function orderDetailsUrl(orderId) {
  return `https://www.amazon.com/your-orders/order-details?orderID=${encodeURIComponent(orderId)}`;
}

function amazonSignedInAccountName() {
  const candidates = [
    "#nav-link-accountList-nav-line-1",
    "#nav-link-accountList .nav-line-1",
    "span.nav-line-1",
  ];
  for (const selector of candidates) {
    const element = [...document.querySelectorAll(selector)].find((node) => visible(node) && /hello,/i.test(node.textContent || ""));
    const text = (element?.textContent || "").replace(/\s+/g, " ").trim();
    const match = text.match(/^hello,\s*(.+)$/i);
    if (match?.[1]) return match[1].trim();
  }
  return "";
}

function extractRecentOrderId(activeJob) {
  return extractRecentOrders(activeJob)[0]?.amazon_order_id || "";
}

function orderCardOrderId(card) {
  const headerText = (card.querySelector("#orderCardHeader")?.innerText || card.innerText || card.textContent || "").replace(/\s+/g, " ");
  const match = headerText.match(/\b\d{3}-\d{7}-\d{7}\b/);
  return match ? match[0] : "";
}

function orderCardAsins(card) {
  return orderCardItems(card).map((item) => item.asin);
}

function asinFromAmazonHref(href = "") {
  const match = String(href || "").match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
  return match ? match[1].toUpperCase() : "";
}

function orderCardItems(card) {
  const quantitiesByAsin = {};
  const itemRows = [...card.querySelectorAll("#itemDetail, .itemDetails")].filter((row) => row.querySelector("a[href*='/dp/'], a[href*='/gp/product/']"));
  if (!itemRows.length) {
    for (const link of card.querySelectorAll("a[href*='/dp/'], a[href*='/gp/product/']")) {
      const asin = asinFromAmazonHref(link.href || link.getAttribute("href") || "");
      if (asin && !quantitiesByAsin[asin]) quantitiesByAsin[asin] = 1;
    }
    return Object.entries(quantitiesByAsin).map(([asin, quantity]) => ({ asin, quantity }));
  }
  const rows = itemRows;
  for (const row of rows) {
    const link = row.matches?.("a[href*='/dp/'], a[href*='/gp/product/']")
      ? row
      : row.querySelector("a[href*='/dp/'], a[href*='/gp/product/']");
    const asin = asinFromAmazonHref(link?.href || link?.getAttribute?.("href") || "");
    if (!asin) continue;
    const quantityText = row.matches?.("a[href*='/dp/'], a[href*='/gp/product/']")
      ? ""
      : (row.querySelector(".itemQuantity")?.textContent || "");
    const quantity = Math.max(1, Math.round(Number((quantityText || "").match(/\d+/)?.[0] || 1)));
    quantitiesByAsin[asin] = (quantitiesByAsin[asin] || 0) + quantity;
  }
  return Object.entries(quantitiesByAsin).map(([asin, quantity]) => ({ asin, quantity }));
}

function quantityFromText(text = "") {
  const match = String(text || "").match(/\b(?:qty|quantity)\s*:?\s*(\d+)\b/i);
  return Math.max(1, Math.round(Number(match?.[1] || 1)));
}

function orderDetailsPageOrderId() {
  const fromUrl = String(new URLSearchParams(location.search).get("orderID") || "").trim();
  if (/^\d{3}-\d{7}-\d{7}$/.test(fromUrl)) return fromUrl;
  const text = (document.querySelector("#orderDetails")?.innerText || document.body?.innerText || "").replace(/\s+/g, " ");
  return text.match(/\b\d{3}-\d{7}-\d{7}\b/)?.[0] || "";
}

function orderDetailsPageRoot() {
  return document.querySelector("#orderDetails") || document.body;
}

function orderDetailsPageRecipient() {
  const text = (orderDetailsPageRoot()?.innerText || "").replace(/\s+/g, " ").trim();
  const refMatch = text.match(/\bNutricity\s+NC\d+(?:\s+[A-Za-z0-9]+){0,3}/i);
  if (refMatch?.[0]) return refMatch[0].replace(/\s+/g, " ").trim();
  const shipMatch = text.match(/\bShip to\s+(.+?)\s+\d{2,}/i);
  return shipMatch?.[1]?.replace(/\s+/g, " ").trim() || "";
}

function orderDetailsPageStatus() {
  const root = orderDetailsPageRoot();
  const statuses = [...root.querySelectorAll("#shipment-top-row, [id*='shipment'] .a-size-medium, .a-size-medium .a-text-bold, .a-size-medium")]
    .map((node) => (node.textContent || "").replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .filter((text) => !/order details|order summary|invoice|payment method/i.test(text));
  return statuses.find((text) => /arriv|deliver|ship|cancel/i.test(text)) || statuses[0] || "";
}

function orderDetailsPageDate() {
  const text = (orderDetailsPageRoot()?.innerText || "").replace(/\s+/g, " ").trim();
  return text.match(/Order placed\s+([A-Z][a-z]+ \d{1,2}, \d{4})/)?.[1] || "";
}

function orderDetailsPageItems() {
  const root = orderDetailsPageRoot();
  const quantitiesByAsin = {};
  const purchasedLinks = [...root.querySelectorAll("a[href*='/dp/'], a[href*='/gp/product/']")]
    .filter((link) => {
      const href = String(link.href || link.getAttribute("href") || "");
      return asinFromAmazonHref(href) && /ppx_hzod|ppx_yo_dt|fed_asin_title/i.test(href);
    });
  for (const link of purchasedLinks) {
    const asin = asinFromAmazonHref(link.href || link.getAttribute("href") || "");
    if (!asin) continue;
    const row = link.closest(".a-row.a-spacing-top-base, .a-row, .a-section, li, div");
    const quantity = quantityFromText(row?.innerText || row?.textContent || "");
    quantitiesByAsin[asin] = Math.max(Number(quantitiesByAsin[asin] || 0), quantity);
  }
  return Object.entries(quantitiesByAsin).map(([asin, quantity]) => ({ asin, quantity }));
}

function orderDetailsPageDetails() {
  const orderId = orderDetailsPageOrderId();
  if (!orderId) return null;
  const items = orderDetailsPageItems();
  return {
    amazon_order_id: orderId,
    amazon_order_url: orderDetailsUrl(orderId),
    recipient: orderDetailsPageRecipient(),
    order_date: orderDetailsPageDate(),
    status: orderDetailsPageStatus(),
    asins: items.map((item) => item.asin),
    items,
    cancelled: /cancelled/i.test(orderDetailsPageStatus()),
    captured_at: Date.now(),
  };
}

function orderCardRecipient(card) {
  const selectors = [
    ".shipToTriggerTextTruncate .a-truncate-full",
    ".shipToTriggerTextTruncate",
    "[id^='a-popover-PreloadedContent_'] .a-text-bold",
  ];
  for (const selector of selectors) {
    const text = [...card.querySelectorAll(selector)]
      .map((node) => (node.textContent || "").replace(/\s+/g, " ").trim())
      .find(Boolean);
    if (text) return text;
  }
  return "";
}

function orderCardDate(card) {
  const headerText = (card.querySelector("#orderCardHeader")?.innerText || "").replace(/\s+/g, " ").trim();
  const match = headerText.match(/Order placed\s+([A-Z][a-z]+ \d{1,2}, \d{4})/);
  return match?.[1] || "";
}

function orderCardStatus(card) {
  const statuses = [...card.querySelectorAll("#orderCardDeliveryBox .a-size-medium .a-text-bold, #orderCardDeliveryBox .a-size-medium")]
    .map((node) => (node.textContent || "").replace(/\s+/g, " ").trim())
    .filter(Boolean);
  return statuses[0] || "";
}

function isCancelledOrderCard(card) {
  return /^cancelled$/i.test(orderCardStatus(card)) || /\bCancelled\b/.test(orderCardStatus(card));
}

function extractOrderHistoryOrders() {
  const cards = [...document.querySelectorAll("#yourOrderHistorySection #orderCard, .order-card")]
    .filter(visible);
  const candidates = cards.length ? cards : [...document.querySelectorAll("#orderCard, .order-card")].filter(visible);
  const seen = new Set();
  const orders = [];
  for (const card of candidates) {
    const orderId = orderCardOrderId(card);
    if (!orderId || seen.has(orderId) || isCancelledOrderCard(card)) continue;
    seen.add(orderId);
    orders.push({
      amazon_order_id: orderId,
      amazon_order_url: orderDetailsUrl(orderId),
      recipient: orderCardRecipient(card),
      order_date: orderCardDate(card),
      status: orderCardStatus(card),
      asins: orderCardAsins(card),
      items: orderCardItems(card),
      captured_at: Date.now(),
    });
    if (orders.length >= 10) break;
  }
  return orders;
}

function visibleOrderHistoryCards() {
  const cards = [...document.querySelectorAll("#yourOrderHistorySection #orderCard, .order-card")].filter(visible);
  return cards.length ? cards : [...document.querySelectorAll("#orderCard, .order-card")].filter(visible);
}

function orderHistoryCardDetails(card) {
  const orderId = orderCardOrderId(card);
  if (!orderId) return null;
  return {
    amazon_order_id: orderId,
    amazon_order_url: orderDetailsUrl(orderId),
    recipient: orderCardRecipient(card),
    order_date: orderCardDate(card),
    status: orderCardStatus(card),
    asins: orderCardAsins(card),
    items: orderCardItems(card),
    cancelled: isCancelledOrderCard(card),
    captured_at: Date.now(),
  };
}

function orderHistoryAnnotationContainer(card) {
  if (card?.dataset?.nutricityAnnotationHost === "true") return card;
  return card.querySelector("#orderCardHeader .a-box-inner") || card.querySelector("#orderCardHeader") || card;
}

function orderDetailsAnnotationHost() {
  const root = orderDetailsPageRoot();
  let anchor = root.querySelector(".nutricity-order-details-anchor");
  if (!anchor) {
    anchor = document.createElement("div");
    anchor.className = "nutricity-order-details-anchor";
    const detailsBox = root.querySelector("[data-component='shippingAddress']")?.closest(".a-box-inner")
      || root.querySelector("[data-component='chargeSummary']")?.closest(".a-box-inner");
    const header = [...root.querySelectorAll(".a-section, .a-row, .a-box")]
      .find((node) => {
        const text = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
        return /\bOrder placed\b/i.test(text) && /\bOrder #\b/i.test(text);
      });
    const target = detailsBox || header || root.firstElementChild;
    if (target?.parentElement) {
      target.parentElement.insertBefore(anchor, detailsBox ? target : target.nextSibling);
    } else {
      root.insertBefore(anchor, root.firstChild);
    }
  }
  anchor.dataset.nutricityAnnotationHost = "true";
  anchor.dataset.nutricityOrderDetailsHost = "true";
  return anchor;
}

function renderOrderHistoryAnnotation(card, result) {
  const existing = card.querySelector(".nutricity-order-history-annotation");
  if (existing) existing.remove();
  if (!result) return;
  const orders = result.match?.orders || [];
  const suggestions = result.suggestions || [];
  const conflicts = result.conflicts || [];
  const cancelled = result.cancelled === true;
  if (cancelled && !orders.length) return;
  if (!orders.length && !suggestions.length && !conflicts.length && !result.unmatched) return;
  const syncedConfirmation = orderHistorySyncedConfirmations.get(result.orderId);
  const detailsClass = card?.dataset?.nutricityOrderDetailsHost === "true" ? " is-order-details" : "";
  if (syncedConfirmation && Date.now() - Number(syncedConfirmation.syncedAt || 0) < 30000) {
    const marker = document.createElement("div");
    marker.className = `nutricity-order-history-annotation is-synced${detailsClass}`;
    const label = document.createElement("span");
    label.className = "nutricity-order-history-label";
    label.textContent = "Synced";
    const text = document.createElement("span");
    text.className = "nutricity-order-history-links";
    text.textContent = syncedConfirmation.message || `Amazon ${result.orderId} synced`;
    marker.append(label, text);
    orderHistoryAnnotationContainer(card).appendChild(marker);
    return;
  }
  const syncStartedAt = orderHistorySyncInProgress.get(result.orderId);
  let syncInProgress = false;
  if (syncStartedAt) {
    syncInProgress = Date.now() - Number(syncStartedAt) < 120000;
    if (!syncInProgress) orderHistorySyncInProgress.delete(result.orderId);
  }
  const marker = document.createElement("div");
  marker.className = `nutricity-order-history-annotation ${cancelled && orders.length ? "is-cancelled-sync" : conflicts.length ? "is-conflict" : orders.length ? "is-match" : suggestions.length ? "is-suggestion" : "is-miss"}${detailsClass}`;
  const label = document.createElement("span");
  label.className = "nutricity-order-history-label";
  label.textContent = cancelled && orders.length ? "Cancelled warning" : conflicts.length ? "Warning" : orders.length ? "Odoo order" : suggestions.length ? "Odoo order found" : "Not found in app";
  marker.appendChild(label);
  if (conflicts.length) {
    const warning = document.createElement("span");
    warning.className = "nutricity-order-history-warning";
    const first = conflicts[0];
    warning.textContent = `${first.odoo_order_name || "Odoo order"} ${first.asin || "ASIN"} already has Amazon ${first.existing_amazon_order_id}`;
    marker.appendChild(warning);
  }
  if (orders.length) {
    const links = document.createElement("span");
    links.className = "nutricity-order-history-links";
    if (cancelled) {
      links.appendChild(document.createTextNode("Cancelled here but synced to Odoo order ID: "));
    }
    orders.slice(0, 4).forEach((order, index) => {
      if (index) links.appendChild(document.createTextNode(", "));
      const link = document.createElement("a");
      link.href = order.odoo_order_url || "#";
      link.target = "_blank";
      link.rel = "noreferrer";
      link.textContent = order.odoo_order_name || `Odoo ${order.odoo_order_id}`;
      links.appendChild(link);
    });
    if (orders.length > 4) {
      links.appendChild(document.createTextNode(` +${orders.length - 4}`));
    }
    marker.appendChild(links);
    appendOrderHistoryQuantitySummary(marker, orders);
  } else if (suggestions.length) {
    const links = document.createElement("span");
    links.className = "nutricity-order-history-links";
    suggestions.slice(0, 3).forEach((order, index) => {
      if (index) links.appendChild(document.createTextNode(", "));
      const link = document.createElement("a");
      link.href = order.odoo_order_url || "#";
      link.target = "_blank";
      link.rel = "noreferrer";
      link.textContent = order.odoo_order_name || `Odoo ${order.odoo_order_id}`;
      links.appendChild(link);
    });
    const existingIds = [...new Set(suggestions.map((order) => order.current_amazon_order_id).filter(Boolean))];
    if (existingIds.length) {
      links.appendChild(document.createTextNode(` currently ${existingIds.slice(0, 2).join(", ")}`));
    }
    marker.appendChild(links);
    appendOrderHistoryQuantitySummary(marker, suggestions);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "nutricity-order-history-sync";
    if (syncInProgress) {
      button.classList.add("is-syncing");
      button.disabled = true;
      button.textContent = "Syncing...";
    } else {
      button.textContent = "Sync Amazon ID";
    }
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (orderHistorySyncInProgress.has(result.orderId)) return;
      orderHistorySyncInProgress.set(result.orderId, Date.now());
      button.disabled = true;
      button.classList.add("is-syncing");
      button.textContent = "Syncing...";
      let synced = null;
      try {
        synced = await syncSuggestedAmazonHistoryOrder(result);
      } catch (error) {
        synced = { ok: false, message: error?.message || String(error || "Could not sync this Amazon order.") };
      }
      if (synced?.ok && Number(synced.matched || 0) > 0) {
        orderHistorySyncInProgress.delete(result.orderId);
        button.classList.remove("is-syncing");
        button.classList.add("is-synced");
        button.disabled = true;
        button.textContent = "Synced";
        orderHistorySyncedConfirmations.set(result.orderId, {
          syncedAt: Date.now(),
          message: synced.message || `Synced ${result.orderId}`,
        });
        orderHistoryLookupCache.delete(result.orderId);
        const annotation = button.closest(".nutricity-order-history-annotation");
        if (annotation) annotation.classList.add("is-synced");
      } else {
        orderHistorySyncInProgress.delete(result.orderId);
        button.classList.remove("is-syncing");
        button.disabled = false;
        button.textContent = "Sync failed";
        button.title = synced?.message || "Could not sync this Amazon order.";
      }
    });
    marker.appendChild(button);
  } else if (!result.cancelled) {
    const link = document.createElement("a");
    link.className = "nutricity-order-history-not-found";
    link.href = result.notFoundUrl || "#";
    link.target = "_blank";
    link.rel = "noreferrer";
    link.textContent = result.orderId;
    marker.appendChild(link);
  }
  const container = orderHistoryAnnotationContainer(card);
  container.appendChild(marker);
}

function compactQuantity(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number)) return "0";
  return Number.isInteger(number) ? String(number) : String(Math.round(number * 100) / 100);
}

function appendOrderHistoryQuantitySummary(marker, orders = []) {
  const checks = [];
  for (const order of orders || []) {
    for (const check of order.quantity_checks || []) {
      checks.push({
        orderName: order.odoo_order_name || "",
        asin: check.asin || "",
        expected: Number(check.expected || 0),
        actual: Number(check.actual || 0),
        matches: check.matches === true,
      });
    }
  }
  if (!checks.length) return;
  const summary = document.createElement("span");
  const mismatches = checks.filter((check) => !check.matches);
  summary.className = `nutricity-order-history-quantity ${mismatches.length ? "is-warning" : "is-match"}`;
  if (mismatches.length) {
    summary.textContent = `Qty warning: ${mismatches
      .slice(0, 3)
      .map((check) => `${check.asin} expected ${compactQuantity(check.expected)}, Amazon ${compactQuantity(check.actual)}`)
      .join("; ")}`;
  } else {
    summary.textContent = `Qty matches: ${checks
      .slice(0, 4)
      .map((check) => `${check.asin} x${compactQuantity(check.actual)}`)
      .join(", ")}`;
  }
  marker.appendChild(summary);
}

async function syncSuggestedAmazonHistoryOrder(result) {
  const suggestions = result.suggestions || [];
  const orderNames = [...new Set(suggestions.map((order) => order.odoo_order_name).filter(Boolean))];
  if (!result.orderId || !orderNames.length) return { ok: false, message: "No Odoo order suggestion is available." };
  const amazonAsins = new Set((result.asins || []).map((asin) => String(asin || "").toUpperCase()).filter(Boolean));
  const matchingLineIds = [
    ...new Set(
      suggestions.flatMap((order) =>
        (order.lines || [])
          .filter((line) => !amazonAsins.size || amazonAsins.has(String(line.asin || "").toUpperCase()))
          .map((line) => Number(line.id || 0))
          .filter(Boolean),
      ),
    ),
  ];
  if (amazonAsins.size && !matchingLineIds.length) {
    return { ok: false, message: "No matching Odoo line ASIN was found for this Amazon order card." };
  }
  return send({
    type: "SYNC_AMAZON_HISTORY_ORDER",
    order: {
      amazon_order_id: result.orderId,
      amazon_order_url: orderDetailsUrl(result.orderId),
      recipient: result.recipient || "",
      source_text: result.recipient || orderNames.join(" "),
      order_names: orderNames,
      line_ids: matchingLineIds,
      store_id: suggestions.length === 1 ? suggestions[0].store_id : null,
      replace_existing: true,
    },
  });
}

async function annotateAmazonOrderHistory() {
  if (!extensionContextAlive || !/amazon\.com$/i.test(location.hostname) || (!isOrderHistoryPage() && !isOrderDetailsPage())) return;
  const pairs = [];
  const unknown = [];
  const seen = new Set();
  if (isOrderDetailsPage()) {
    const details = orderDetailsPageDetails();
    if (details?.amazon_order_id) {
      seen.add(details.amazon_order_id);
      pairs.push({ card: orderDetailsAnnotationHost(), details });
    }
  }
  if (isOrderHistoryPage()) {
    for (const card of visibleOrderHistoryCards()) {
      const details = orderHistoryCardDetails(card);
      if (!details || seen.has(details.amazon_order_id)) continue;
      seen.add(details.amazon_order_id);
      pairs.push({ card, details });
    }
  }
  for (const { card, details } of pairs) {
    const cached = orderHistoryLookupCache.get(details.amazon_order_id);
    if (cached && Date.now() - Number(cached.cachedAt || 0) < 2 * 60 * 1000) {
      renderOrderHistoryAnnotation(card, cached);
    } else {
      unknown.push(details);
    }
  }
  if (!unknown.length || orderHistoryAnnotationInFlight) return;
  orderHistoryAnnotationInFlight = true;
  try {
    const result = await send({ type: "LOOKUP_AMAZON_HISTORY_ORDERS", orders: unknown });
    if (!result?.ok) return;
    const matches = result.matches || {};
    const suggestions = result.suggestions || {};
    const conflicts = result.conflicts || {};
    const unmatched = new Set(result.unmatched || []);
    for (const details of unknown) {
      const match = matches[details.amazon_order_id] || null;
      const cached = {
        orderId: details.amazon_order_id,
        recipient: details.recipient,
        match,
        suggestions: suggestions[details.amazon_order_id] || [],
        conflicts: conflicts[details.amazon_order_id] || [],
        unmatched: unmatched.has(details.amazon_order_id),
        asins: details.asins || [],
        items: details.items || [],
        cancelled: details.cancelled,
        notFoundUrl: result.not_found_url || "",
        cachedAt: Date.now(),
      };
      orderHistoryLookupCache.set(details.amazon_order_id, cached);
    }
    for (const { card, details } of pairs) {
      renderOrderHistoryAnnotation(card, orderHistoryLookupCache.get(details.amazon_order_id));
    }
  } finally {
    orderHistoryAnnotationInFlight = false;
  }
}

function scheduleOrderHistoryAnnotation(delay = 350) {
  if (orderHistoryAnnotationScheduled) return;
  orderHistoryAnnotationScheduled = true;
  setTimeout(() => {
    orderHistoryAnnotationScheduled = false;
    annotateAmazonOrderHistory().catch(() => {});
  }, delay);
}

function activeJobOrderNames(activeJob) {
  return (activeJob.job?.order_names || []).map((name) => String(name || "").trim()).filter(Boolean);
}

function activeJobAsins(activeJob) {
  const asins = [];
  for (const item of activeJob.job?.items || []) {
    const requested = String(item.asin || "").toUpperCase();
    const purchased = String(activeJob.pricing?.[requested]?.purchased_asin || "").toUpperCase();
    if (requested) asins.push(requested);
    if (purchased) asins.push(purchased);
  }
  return [...new Set(asins)];
}

function recentOrderMatchesActiveJob(order, activeJob) {
  const haystack = `${order.recipient || ""} ${order.status || ""}`.toLowerCase();
  const names = activeJobOrderNames(activeJob).map((name) => name.toLowerCase());
  const recipient = String(activeJob.job?.recipient_name || "").toLowerCase();
  const nameMatches = names.some((name) => name && haystack.includes(name)) || (recipient && haystack.includes(recipient));
  if (!nameMatches) return false;
  const cachedAsins = new Set((order.asins || []).map((asin) => String(asin || "").toUpperCase()).filter(Boolean));
  const jobAsins = activeJobAsins(activeJob);
  if (!cachedAsins.size || !jobAsins.length) return true;
  if (jobAsins.some((asin) => cachedAsins.has(asin))) return true;
  const activeItemCount = Array.isArray(activeJob.job?.items) ? activeJob.job.items.length : 0;
  return submittedStage(activeJob) && activeItemCount <= 1;
}

async function findRememberedDuplicateOrder(activeJob) {
  const result = await send({ type: "GET_RECENT_AMAZON_ORDERS" });
  if (!result?.ok) return null;
  const orders = (result.orders || []).filter((order) => recentOrderMatchesActiveJob(order, activeJob));
  return orders[0] || null;
}

function extractRecentOrders(activeJob) {
  const recipient = String(activeJob.job.recipient_name || "").toLowerCase();
  const names = activeJobOrderNames(activeJob).map((name) => name.toLowerCase());
  const historyOrders = extractOrderHistoryOrders();
  const historyMatches = historyOrders.filter((order) => recentOrderMatchesActiveJob(order, activeJob));
  if (historyMatches.length) return historyMatches;
  if (isOrderHistoryPage()) return [];
  const cards = [
    ...document.querySelectorAll("#orderCardHeader, .order-card, [id*='orderCard'], .order, .a-box-group, .a-box"),
  ]
    .filter(visible)
    .sort((a, b) => (a.innerText || a.textContent || "").length - (b.innerText || b.textContent || "").length);
  const candidates = cards.length ? cards : [...document.querySelectorAll("body")];
  const seen = new Set();
  const orders = [];
  for (const card of candidates) {
    if (isCancelledOrderCard(card)) continue;
    const text = (card.innerText || card.textContent || "").replace(/\s+/g, " ");
    const lower = text.toLowerCase();
    const matchesRecipient = recipient && lower.includes(recipient);
    const matchesOrderName = names.some((name) => name && lower.includes(name));
    const orderMatch = text.match(/\b\d{3}-\d{7}-\d{7}\b/);
    if (orderMatch && (matchesRecipient || matchesOrderName || candidates.length === 1)) {
      const orderId = orderMatch[0];
      if (seen.has(orderId)) continue;
      seen.add(orderId);
      orders.push({
        amazon_order_id: orderId,
        amazon_order_url: orderDetailsUrl(orderId),
        recipient: orderCardRecipient(card),
        order_date: orderCardDate(card),
        status: orderCardStatus(card),
        asins: orderCardAsins(card),
      });
    }
  }
  return orders;
}

async function handleCompletion(activeJob) {
  await waitForElement(["body"], 8000);
  if (isOrderHistoryPage()) {
    await handleOrderHistory(activeJob);
    return;
  }
  const orderId = extractOrderId();
  if (orderId) {
    await reportAmazonOrder(activeJob, orderId);
    return;
  }
  if (/\/cart|\/dp\/|\/gp\/product/i.test(location.pathname)) {
    showPanel("Nutricity fulfilment", "Amazon submit already started. Opening order history to capture the order number.", null, null);
    activeJob.stage = "find_order_id";
    await setActiveJob(activeJob);
    location.href = orderHistoryUrl();
    return;
  }
  if (amazonOrderSubmitErrorPage()) {
    showPanel("Nutricity fulfilment", "Amazon showed an error after order submit. Opening recent orders to verify whether the order was placed.", null, null);
    activeJob.stage = "find_order_id";
    await setActiveJob(activeJob);
    location.href = orderHistoryUrl();
    return;
  }
  if (!confirmationSaysPlaced()) return;
  const link = recentOrdersLink();
  if (link) {
    showPanel("Nutricity fulfilment", "Order placed. Opening recent orders to capture the Amazon order number.", null, null);
    activeJob.stage = "find_order_id";
    await setActiveJob(activeJob);
    await clickElement(link, "Review recent orders link");
    return;
  }
  showPanel("Nutricity fulfilment", "Order placed. Opening order history to capture the Amazon order number.", null, null);
  activeJob.stage = "find_order_id";
  await setActiveJob(activeJob);
  location.href = orderHistoryUrl();
}

async function handleOrderHistory(activeJob) {
  if (!isOrderHistoryPage()) {
    showPanel("Nutricity fulfilment", "Opening order history to capture the Amazon order number.", null, null);
    activeJob.stage = "find_order_id";
    await setActiveJob(activeJob);
    location.href = orderHistoryUrl();
    return;
  }
  await waitForElement(["#orderCardHeader", ".order-card", "[id*='orderCard']", "body"], 12000);
  const historyOrders = extractOrderHistoryOrders();
  if (historyOrders.length) {
    await send({ type: "REMEMBER_RECENT_AMAZON_ORDERS", orders: historyOrders });
  }
  const orders = extractRecentOrders(activeJob);
  const rememberedOrder = orders.length ? null : await findRememberedDuplicateOrder(activeJob);
  if (!orders.length && !rememberedOrder) {
    showPanel("Nutricity fulfilment", `Looking for recent Amazon order for ${activeJob.job.recipient_name}.`, null, null);
    return;
  }
  await reportAmazonOrders(activeJob, orders.length ? orders : [rememberedOrder]);
}

async function reportAmazonOrder(activeJob, orderId) {
  return reportAmazonOrders(activeJob, [{ amazon_order_id: orderId, amazon_order_url: orderDetailsUrl(orderId), asins: [] }]);
}

function buildOrderMappings(activeJob, orders) {
  if (!Array.isArray(orders) || orders.length < 2) return [];
  const items = activeJob.job?.items || [];
  const mappings = [];
  for (const item of items) {
    const requestedAsin = String(item.asin || "").toUpperCase();
    const purchasedAsin = String(activeJob.pricing?.[requestedAsin]?.purchased_asin || "").toUpperCase();
    const itemAsins = [requestedAsin, purchasedAsin].filter(Boolean);
    const order = orders.find((candidate) => itemAsins.some((asin) => (candidate.asins || []).includes(asin)));
    if (!order) continue;
    mappings.push({
      asin: requestedAsin,
      line_ids: item.line_ids || [],
      amazon_order_id: order.amazon_order_id,
      amazon_order_url: order.amazon_order_url || orderDetailsUrl(order.amazon_order_id),
    });
  }
  return mappings;
}

async function reportAmazonOrders(activeJob, orders) {
  const uniqueOrders = [];
  const seen = new Set();
  for (const order of orders || []) {
    const orderId = String(order.amazon_order_id || "").trim();
    if (!orderId || seen.has(orderId)) continue;
    seen.add(orderId);
    uniqueOrders.push({
      amazon_order_id: orderId,
      amazon_order_url: order.amazon_order_url || orderDetailsUrl(orderId),
      asins: (order.asins || []).map((asin) => String(asin || "").toUpperCase()).filter(Boolean),
    });
  }
  const orderId = uniqueOrders[0]?.amazon_order_id || "";
  const orderLabel = uniqueOrders.map((order) => order.amazon_order_id).join(", ");
  const orderMappings = buildOrderMappings(activeJob, uniqueOrders);
  showPanel("Nutricity fulfilment", `Found Amazon order ${orderLabel || orderId}. Reporting back to the app.`, null, null);
  activeJob.stage = "reporting_complete";
  activeJob.reportedOrderId = orderLabel || orderId;
  activeJob.reportAttemptedAt = Date.now();
  await setActiveJob(activeJob);
  let result = null;
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    result = await send({
      type: "COMPLETE_JOB",
      orderId,
      orderUrl: uniqueOrders[0]?.amazon_order_url || orderDetailsUrl(orderId),
      orderMappings,
      amazonAccountName: amazonSignedInAccountName(),
    });
    if (result?.ok) break;
    const message = normalizedText(result?.message || "");
    const transient = /internal server error|pool|timeout|failed to fetch|network|temporarily/.test(message);
    if (!transient || attempt === 4) break;
    showPanel("Nutricity fulfilment", `The app was busy reporting ${orderId}. Retrying ${attempt + 1}/4.`, null, null);
    await sleep(1500 * attempt);
  }
  if (!result?.ok) {
    const message = result?.message || "Could not report Amazon order back to the app.";
    activeJob.paused = true;
    activeJob.pausedStage = "reporting_complete";
    activeJob.reportError = message;
    await setActiveJob(activeJob);
    showPanel(
      "Nutricity reporting needs attention",
      `${message} Amazon order ${orderLabel || orderId} was found, but the app did not confirm completion.`,
      "Retry reporting",
      () => continueAfterManualStep(activeJob, "reporting_complete"),
    );
    return false;
  }
  showPanel("Nutricity fulfilment", result.message || `Reported Amazon order ${orderId}.`, null, null);
  return true;
}

async function run() {
  if (!extensionContextAlive) return;
  const activeJob = await getActiveJob();
  if (!activeJob?.job || !/amazon\.com$/i.test(location.hostname)) return;
  if (amazonDuplicateOrderPage()) {
    try {
      return await handleAmazonDuplicateOrderPage(activeJob);
    } catch (error) {
      showPanel("Nutricity fulfilment error", error.message || String(error), null, null);
      return;
    }
  }
  if (activeJob.paused && submittedOrPausedStage(activeJob)) {
    activeJob.stage = activeJob.pausedStage || activeJob.stage || "find_order_id";
    activeJob.paused = false;
    activeJob.pausedStage = null;
    await setActiveJob(activeJob);
  }
  if (activeJob.paused) {
    showPanel(
      "Nutricity fulfilment paused",
      "Fulfilment is paused. Click Resume to retry this step, or continue if you completed it manually.",
      "I did it manually, continue",
      () => continueAfterManualStep(activeJob),
    );
    return;
  }
  try {
    if (submittedStage(activeJob)) {
      if (activeJob.stage === "reporting_complete") {
        if (activeJob.reportedOrderId) {
          await reportAmazonOrder(activeJob, activeJob.reportedOrderId);
        } else {
          showPanel("Nutricity fulfilment", "Reporting Amazon order back to the app.", null, null);
        }
      } else if (activeJob.stage === "complete_pending") {
        await handleCompletion(activeJob);
      } else {
        activeJob.stage = "find_order_id";
        await setActiveJob(activeJob);
        await handleOrderHistory(activeJob);
      }
    } else if (/\/checkout/i.test(location.pathname) && await handleCheckoutLimitPurchase(activeJob)) return;
    else if (activeJob.stage === "cleanup_after_failure") {
      await handleFailureCleanup(activeJob);
    } else if (activeJob.stage === "reporting_complete") {
      if (activeJob.reportedOrderId) {
        await reportAmazonOrder(activeJob, activeJob.reportedOrderId);
      } else {
        showPanel("Nutricity fulfilment", "Reporting Amazon order back to the app.", null, null);
      }
    } else if (activeJob.stage === "duplicate_order") {
      const orders = (activeJob.duplicateOrder?.orders || []).map((item) => item.amazon_order_id).filter(Boolean).join(", ");
      showPanel(
        "Amazon order already exists",
        `${orders || "An Amazon order"} is already saved in the app. Open the extension popup to review or clear it before continuing.`,
        null,
        null,
      );
    } else if (activeJob.stage === "complete_pending") {
      await handleCompletion(activeJob);
    } else if (activeJob.stage === "subscribe_checkout") {
      await handleSubscribeCheckout(activeJob);
    } else if (activeJob.stage === "add_clicked") {
      await handleAddClicked(activeJob);
    } else if (activeJob.stage === "find_order_id") {
      activeJob.stage = "find_order_id";
      await setActiveJob(activeJob);
      await handleOrderHistory(activeJob);
    } else if (/\/cart/i.test(location.pathname)) {
      if (!["clear_cart", "cleanup_after_failure"].includes(activeJob.stage)) {
        activeJob.stage = "cart";
      }
      await setActiveJob(activeJob);
      await handleCart(activeJob);
    } else if (/\/checkout/i.test(location.pathname)) {
      if (activeJob.stage !== "editing_address") {
        activeJob.stage = "checkout";
      }
      await setActiveJob(activeJob);
      await handleCheckout(activeJob);
    } else {
      activeJob.stage = "product";
      await setActiveJob(activeJob);
      await handleProduct(activeJob);
    }
  } catch (error) {
    showPanel("Nutricity fulfilment error", error.message, null, null);
    const item = activeJob.job.items?.[activeJob.itemIndex];
    const purchaseItem = item ? selectedVariantItem(activeJob, item) : item;
    const shouldMarkItemMissing = Boolean(error.failureCode || error.missingAsin);
    if (!shouldMarkItemMissing) {
      activeJob.pausedStage = activeJob.stage || "product";
      activeJob.paused = true;
      await setActiveJob(activeJob);
      showPanel(
        "Nutricity fulfilment needs attention",
        `${error.message} Complete the stuck Amazon step manually, then continue.`,
        "I did it manually, continue",
        () => continueAfterManualStep(activeJob),
      );
      return;
    }
    if (await continueAfterPartialMissing(activeJob, item, purchaseItem, error.message, error.failureCode || "unavailable", {
      requestedQuantity: error.requestedQuantity ?? null,
      fulfilledQuantity: error.fulfilledQuantity ?? null,
      availableQuantity: error.availableQuantity ?? null,
    })) {
      return;
    }
    let failResult = null;
    try {
      failResult = await send({
        type: "FAIL_JOB",
        message: error.message,
        missingAsin: error.missingAsin || item?.asin || purchaseItem?.asin || "",
        missingLineId: item ? itemPrimaryLineId(item) : null,
        failureCode: error.failureCode || "",
        requestedQuantity: error.requestedQuantity ?? null,
        fulfilledQuantity: error.fulfilledQuantity ?? null,
        availableQuantity: error.availableQuantity ?? null,
      });
    } catch (reportError) {
      await pauseAfterMissingAsinReportFailure(activeJob, reportError.message || "Could not send the Missing ASIN report to the app.");
      return;
    }
    if (!failResult?.ok) {
      await pauseAfterMissingAsinReportFailure(activeJob, failResult?.message || "The app did not confirm the Missing ASIN report.");
      return;
    }
    const reason = error.message || "No reason supplied.";
    const nextMessage = failResult.next_job_started && failResult.next_group_key
      ? `Reason: ${reason} Order moved to Missing ASINs. Starting next order ${failResult.next_group_key}.`
      : `Reason: ${reason} Order moved to Missing ASINs.`;
    showPanel("Missing ASINs", nextMessage, null, null);
  }
}

async function runSafely() {
  if (window.__nutricityRunning) {
    if (Date.now() - Number(window.__nutricityRunningAt || 0) < 25000) return;
    console.warn("Nutricity fulfilment: recovering from a stale content-script run.");
  }
  window.__nutricityRunning = true;
  window.__nutricityRunningAt = Date.now();
  try {
    await run();
  } finally {
    window.__nutricityRunning = false;
    window.__nutricityRunningAt = 0;
  }
}

runSafely();
scheduleOrderHistoryAnnotation(250);
setInterval(runSafely, 5000);
setInterval(() => scheduleOrderHistoryAnnotation(0), 3000);
window.addEventListener("pageshow", () => {
  setTimeout(runSafely, 250);
  scheduleOrderHistoryAnnotation(250);
});
window.addEventListener("focus", () => {
  setTimeout(runSafely, 250);
  scheduleOrderHistoryAnnotation(250);
});
window.addEventListener("hashchange", () => scheduleOrderHistoryAnnotation(500));
window.addEventListener("popstate", () => scheduleOrderHistoryAnnotation(500));
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) {
    setTimeout(runSafely, 250);
    scheduleOrderHistoryAnnotation(250);
  }
});
if (document.body) {
  const observer = new MutationObserver(() => scheduleOrderHistoryAnnotation(500));
  observer.observe(document.body, { childList: true, subtree: true });
}
